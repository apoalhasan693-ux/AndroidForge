package com.rafiq6.study

// ============================================================
// المساعد الذكي — إدارة التراكم الذكية (Smart Backlog Redistribution)
//
// هذا الملف لا يضيف أي منطق جدولة جديد. "الذكاء" في التوزيع (الأولويات، عدم التكديس، احترام
// الامتحانات والحد اليومي...) كله موجود مسبقًا في SmartEngine.planEvacuateDay (SmartSchedule.kt)
// — نفس المحرك المستخدم في "إخلاء اليوم من التراكمات" بمركز التحكم. الملف هنا طبقة رفيعة فوقه:
// 1) AssistantIntentParser: نص حر ← هل الطالب يطلب ترحيل تراكم اليوم؟
// 2) AssistantMessageBuilder: SmartPlan (ناتج المحرك نفسه) ← نص رد مفهوم بالصياغة المطلوبة.
// الترحيل الفعلي يمر عبر MainVm.previewEvacuate/applySmartPlan الموجودتين أصلاً (نفس السجل
// والتراجع والتحقق النهائي)، فلا تكرار لمنطق الجدولة أو الحفظ هنا إطلاقًا.
// ============================================================

object AssistantIntentParser {
    /** توحيد الهمزات والتشكيل وصيغ العامية (مثل گ العراقية) لمطابقة أوسع بلا حساسية للإملاء. */
    internal fun normalize(raw: String): String {
        var s = raw.trim()
        s = s.replace(Regex("[\u064B-\u0652]"), "")      // إزالة التشكيل
        s = s.replace(Regex("[إأآ]"), "ا")
        s = s.replace('ى', 'ي')
        s = s.replace('گ', 'ق')                            // "ما أگدر" ← "ما أقدر"
        s = s.replace('ة', 'ه')
        s = s.replace(Regex("\\s+"), " ")
        return s
    }

    /**
     * يكتشف نية "رحّل/وزّع تراكم اليوم" من نص حر. يغطي الأمثلة الأربعة المطلوبة حرفيًا:
     * "اليوم عندي تراكم"، "ما أگدر أكمل جدول اليوم"، "رحّل تراكم اليوم"، "وزّع مهامي المتبقية
     * على الأيام القادمة" — بالإضافة لصيغ قريبة منها، عبر مطابقة كلمات مفتاحية بدل عبارات حرفية
     * فقط، لأن طلب الطالب نفسه يقول: "يفهم التطبيق أن الطالب يريد إعادة الجدولة" لا عبارة ثابتة.
     */
    fun isBacklogRedistributionRequest(raw: String): Boolean {
        val s = normalize(raw)
        if (s.isBlank()) return false
        if ("تراكم" in s) return true
        val wantsAction = listOf("رحل", "وزع", "اعد توزيع", "اعد جدول", "نظم").any { it in s }
        val aboutToday = listOf("جدول", "محاضر", "مهام", "اليوم", "متبقي", "متبقيه").any { it in s }
        if (wantsAction && aboutToday) return true
        val cantFinish = listOf(
            "ما اقدر اكمل", "ما اگدر اكمل", "ما اكدر اكمل", "ما اكمل",
            "ما خلصت اليوم", "ما سويت اليوم", "ما خلصت الجدول", "ما كملت اليوم"
        ).any { it in s }
        return cantFinish
    }
}

/** تفصيل يوم واحد استقبل تراكمًا — لعرضه بوضوح بدل سرد المهام فقط. */
data class BacklogDayBreakdown(val date: String, val dayName: String, val count: Int, val extraMinutes: Int)

object AssistantMessageBuilder {
    fun perDayBreakdown(plan: SmartPlan): List<BacklogDayBreakdown> =
        plan.moves.groupBy { it.toDate }.map { (date, moves) ->
            BacklogDayBreakdown(
                date = date, dayName = moves.first().toDayName, count = moves.size,
                extraMinutes = plan.addedMinByDate[date] ?: moves.sumOf { it.durationMin }
            )
        }.sortedBy { it.date }

    /**
     * رسالة المساعد بالصياغة المطلوبة بالضبط في طلب الميزة، مع تفصيل الأيام تحتها:
     * عدد المحاضرات المرحّلة، الأيام المستقبِلة، عدد المحاضرات لكل يوم، والوقت الإضافي لكل يوم.
     */
    fun describe(plan: SmartPlan): String {
        if (plan.moves.isEmpty()) return "ما عندك تراكم اليوم ✅ جدولك منظّم وكامل."
        val sb = StringBuilder()
        sb.append("تم اكتشاف ${plan.movedTasks} محاضرة متراكمة اليوم. سأعيد توزيعها على الأيام القادمة حتى لا يتكدس جدولك.\n")
        perDayBreakdown(plan).forEach { d -> sb.append("\n📅 ${d.dayName} (${d.date}): ${d.count} محاضرة — +${d.extraMinutes} دقيقة") }
        if (plan.violations.isNotEmpty()) {
            sb.append("\n\n⚠ تنبيهات:")
            plan.violations.forEach { sb.append("\n• $it") }
        }
        return sb.toString()
    }
}

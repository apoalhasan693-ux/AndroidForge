package com.rafiq6.study

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class SmartAssistantTest {

    // ---------- AssistantIntentParser: الأمثلة الأربعة المطلوبة حرفيًا في طلب الميزة ----------

    @Test fun detectsExactRequiredPhrase_today_i_have_backlog() {
        assertTrue(AssistantIntentParser.isBacklogRedistributionRequest("اليوم عندي تراكم"))
    }

    @Test fun detectsExactRequiredPhrase_cant_finish_today_dialect() {
        // الصيغة الدارجة بالضبط من طلب الميزة، بما فيها حرف الگ العراقي.
        assertTrue(AssistantIntentParser.isBacklogRedistributionRequest("ما أگدر أكمل جدول اليوم"))
    }

    @Test fun detectsExactRequiredPhrase_postpone_today_backlog() {
        assertTrue(AssistantIntentParser.isBacklogRedistributionRequest("رحّل تراكم اليوم"))
    }

    @Test fun detectsExactRequiredPhrase_distribute_remaining_tasks() {
        assertTrue(AssistantIntentParser.isBacklogRedistributionRequest("وزّع مهامي المتبقية على الأيام القادمة"))
    }

    // ---------- صيغ قريبة طبيعية (ليست حرفية) يجب أن تُفهم أيضًا ----------

    @Test fun detectsNaturalVariant_standardArabicCantFinish() {
        assertTrue(AssistantIntentParser.isBacklogRedistributionRequest("ما أقدر أكمل جدولي اليوم"))
    }

    @Test fun detectsNaturalVariant_withoutDiacritics() {
        assertTrue(AssistantIntentParser.isBacklogRedistributionRequest("عندي تراكم كبير اليوم ما أعرف شلون أسويه"))
    }

    @Test fun detectsNaturalVariant_reorganizeSchedule() {
        assertTrue(AssistantIntentParser.isBacklogRedistributionRequest("أعد توزيع جدولي رجاءً"))
    }

    // ---------- أمثلة سلبية: نص لا علاقة له بالتراكم يجب ألا يُفعّل الميزة ----------

    @Test fun ignoresUnrelatedText() {
        assertFalse(AssistantIntentParser.isBacklogRedistributionRequest("كم الساعة الحين؟"))
        assertFalse(AssistantIntentParser.isBacklogRedistributionRequest("شلونك اليوم؟"))
        assertFalse(AssistantIntentParser.isBacklogRedistributionRequest("متى امتحان الفيزياء؟"))
    }

    @Test fun ignoresBlankText() {
        assertFalse(AssistantIntentParser.isBacklogRedistributionRequest(""))
        assertFalse(AssistantIntentParser.isBacklogRedistributionRequest("   "))
    }

    // ---------- AssistantMessageBuilder: الرد مبني من SmartPlan حقيقي (محرك SmartEngine نفسه) ----------

    private val cap = StudyCaps(dailyCapMin = 360, maxScanDays = 42)
    private val engine = SmartEngine(cap)
    private val today = LocalDate.of(2026, 11, 1)

    private fun t(id: String, date: LocalDate, type: String = TaskTypes.OLD, dur: Int = 60) = TaskEntity(
        id = id, scheduleId = "s", sourceId = id, date = date.toString(),
        dayName = ScheduleParser.weekday(date), subject = "فيزياء", type = type, title = "محاضرة $id",
        lectureNo = 1, durationMin = dur, startMin = null, endMin = null
    )

    @Test fun describeIncludesExactRequiredOpeningSentence() {
        val tasks = (1..5).map { t("o$it", today, dur = 40) }
        val plan = engine.planEvacuateDay("s", today, tasks, emptySet(), emptyMap(), null)
        val msg = AssistantMessageBuilder.describe(plan)
        // الصياغة من طلب الميزة حرفيًا: "تم اكتشاف 5 محاضرات متراكمة اليوم. سأعيد توزيعها على الأيام
        // القادمة حتى لا يتكدس جدولك."
        assertTrue(msg.contains("تم اكتشاف 5"))
        assertTrue(msg.contains("سأعيد توزيعها على الأيام القادمة"))
    }

    @Test fun describeShowsNoBacklogMessageWhenScheduleIsClean() {
        val tasks = listOf(t("n1", today, TaskTypes.NEW, 60))
        val plan = engine.planEvacuateDay("s", today, tasks, emptySet(), emptyMap(), null)
        val msg = AssistantMessageBuilder.describe(plan)
        assertTrue(msg.contains("ما عندك تراكم اليوم"))
    }

    @Test fun perDayBreakdownNeverStacksEverythingOnOneDay() {
        // تسع محاضرات قديمة (40 دقيقة لكل واحدة) على يوم واحد، والحد اليومي 360 — يجب أن تتوزع
        // على أكثر من يوم واحد، لا أن تتكدس كلها غدًا (شرط "عدم تكديس جميع المحاضرات في اليوم التالي").
        val tasks = (1..9).map { t("o$it", today, dur = 40) }
        val plan = engine.planEvacuateDay("s", today, tasks, emptySet(), emptyMap(), null)
        val breakdown = AssistantMessageBuilder.perDayBreakdown(plan)
        assertTrue("يجب أن تتوزع على أكثر من يوم واحد", breakdown.size > 1)
        breakdown.forEach { d -> assertTrue("لا يتجاوز الحد اليومي في ${d.date}", d.extraMinutes <= cap.dailyCapMin) }
    }

    @Test fun perDayBreakdownCountsAndMinutesMatchMoves() {
        val tasks = (1..4).map { t("o$it", today, dur = 50) }
        val plan = engine.planEvacuateDay("s", today, tasks, emptySet(), emptyMap(), null)
        val breakdown = AssistantMessageBuilder.perDayBreakdown(plan)
        assertEquals(plan.movedTasks, breakdown.sumOf { it.count })
        assertEquals(plan.totalMovedMin, breakdown.sumOf { it.extraMinutes })
    }

    @Test fun describeNeverTouchesCompletedOrExamTasks() {
        val done = t("o1", today, dur = 40)
        val exam = t("e1", today, TaskTypes.DAILY_EXAM, 30).copy(fixed = true)
        val backlog = t("o2", today, dur = 40)
        val plan = engine.planEvacuateDay("s", today, listOf(done, exam, backlog), setOf("o1"), emptyMap(), null)
        assertTrue(plan.moves.none { it.taskId == "o1" })
        assertTrue(plan.moves.none { it.taskId == "e1" })
        assertTrue(plan.moves.any { it.taskId == "o2" })
    }
}

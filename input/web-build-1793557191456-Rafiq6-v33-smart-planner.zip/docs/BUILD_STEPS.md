# خطوات بناء Rafiq6

## باستخدام Android Studio

1. ثبّت JDK 17 أو أحدث.
2. ثبّت Android Studio مع Android SDK 34.
3. افتح مجلد المشروع `Rafiq6` في Android Studio.
4. انتظر مزامنة Gradle.
5. شغّل:
   - `Build > Build Bundle(s) / APK(s) > Build APK(s)`
6. للاختبارات:
   - `Build > Run Unit Tests`
   - أو من Terminal:
     `./gradlew :app:testDebugUnitTest`

## باستخدام سطر الأوامر

إذا كان Gradle Wrapper متوفرًا لديك:

```bash
./gradlew :app:assembleDebug :app:testDebugUnitTest
```

أو إذا كان Gradle 8.10.2 مثبتًا عالميًا:

```bash
gradle --no-daemon :app:assembleDebug :app:testDebugUnitTest
```

## باستخدام GitHub Actions

الملف `.github/workflows/build.yml` موجود مسبقًا ويشغّل:

```bash
gradle --no-daemon :app:assembleDebug :app:testDebugUnitTest
```

ثم يرفع APK وتقارير الاختبارات كـ Artifacts.

## مخرجات البناء

- APK debug:
  `app/build/outputs/apk/debug/app-debug.apk`

## ملاحظات

- المشروع لا يحتوي Gradle Wrapper مرفقًا في ZIP الحالي؛ Android Studio أو GitHub Actions يمكنهما توفير Gradle.
- لا تدّعِ نجاح البناء إلا بعد تشغيله فعليًا.

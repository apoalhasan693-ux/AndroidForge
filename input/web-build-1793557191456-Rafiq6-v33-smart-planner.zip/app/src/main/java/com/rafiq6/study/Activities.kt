package com.rafiq6.study

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "activities")
data class ActivityEntity(
    @PrimaryKey val id: String,
    val date: String,
    val kind: String,          // قراءة | ألعاب | مهارة
    val title: String,
    val durationMin: Int,
    val startMin: Int?,
    var done: Boolean = false,
    val postponedFrom: String? = null
)

// جدولة آمنة: فجوة بعد آخر مهمة ثابتة في اليوم، لا تلامس امتحاناً أبداً
object ActivityPlanner {
    fun suggestSlot(tasks: List<TaskEntity>, existing: List<ActivityEntity>, durMin: Int): Int? {
        val dayEnd = tasks.mapNotNull { it.endMin }.maxOrNull() ?: (18 * 60 + 15)
        var cursor = maxOf(dayEnd + 15, 20 * 60)
        val busy = tasks.mapNotNull { t -> t.startMin?.let { it..(t.endMin ?: it + t.durationMin) } } +
                existing.mapNotNull { a -> a.startMin?.let { it..it + a.durationMin } }
        val limit = 21 * 60 + 30 // لا يتجاوز 9:30 مساءً (النوم)
        while (cursor + durMin <= limit) {
            if (busy.none { cursor < it.last && cursor + durMin > it.first }) return cursor
            cursor += 15
        }
        return null // اليوم ممتلئ -> التأجيل للغد
    }
}

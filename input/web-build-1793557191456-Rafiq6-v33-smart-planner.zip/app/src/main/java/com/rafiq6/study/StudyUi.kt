package com.rafiq6.study

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.time.LocalDate
import java.util.Date
import java.util.UUID

@Composable
fun PdfBankScreen(vm: MainVm) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val docs by vm.bankDocuments.collectAsState()
    val allQuestions by vm.bankQuestions.collectAsState()
    var message by remember { mutableStateOf("") }
    var manageDoc by remember { mutableStateOf<PdfDocumentEntity?>(null) }
    var subjectFilter by remember { mutableStateOf("") }
    var topicFilter by remember { mutableStateOf("") }
    var editingQuestion by remember { mutableStateOf<QuestionEntity?>(null) }
    var editorTarget by remember { mutableStateOf<Pair<PdfDocumentEntity, Int>?>(null) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            if (!PdfPermissionHelper.retain(ctx, uri)) {
                message = "لم يستطع التطبيق الاحتفاظ بصلاحية الوصول الدائم إلى الملف. اختر الملف مرة أخرى من منتقي الملفات الرسمي."
                return@launch
            }
            val result = vm.importPdf(ctx, uri)
            message = result.error ?: "تم استيراد «${result.document?.displayName ?: "الملف"}». ${result.warning ?: ""}"
        }
    }

    val currentDoc = manageDoc
    if (currentDoc != null) {
        PdfDocumentManager(vm, currentDoc, onBack = { manageDoc = null },
            onAddQuestion = { page -> editorTarget = currentDoc to page },
            onEditQuestion = { q -> editingQuestion = q })
        return
    }

    val questions = allQuestions.filter {
        (subjectFilter.isBlank() || it.subject.contains(subjectFilter, true)) &&
        (topicFilter.isBlank() || it.topic.contains(topicFilter, true))
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("بنك أسئلة PDF", style = MaterialTheme.typography.headlineSmall)
        Text("الملفات تُقرأ محليًا على جهازك فقط، بدون OCR وبدون رفع إلى الإنترنت. إذا لم يستطع التطبيق استخراج النص، افتح الصفحة كصورة وأدخل السؤال يدويًا.")
        Button(onClick = { importLauncher.launch(arrayOf("application/pdf")) }, modifier = Modifier.fillMaxWidth()) { Text("اختيار ملف PDF من الجهاز") }
        if (message.isNotBlank()) Text(message, color = if (message.startsWith("تعذر") || message.startsWith("فشل") || message.contains("رفض")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)

        Text("الملفات المستوردة (${docs.size})", style = MaterialTheme.typography.titleMedium)
        if (docs.isEmpty()) Text("لم تستورد أي ملف بعد.")
        docs.forEach { d ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(d.displayName, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Visible)
                Text("عدد الصفحات: ${d.pageCount} · النص القابل للاستخراج: ${if (d.textAvailable) "متاح" else "غير متاح"}", style = MaterialTheme.typography.bodySmall)
                d.importWarning?.let { Text("⚠ $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { manageDoc = d }) { Text("إدارة الصفحات والأسئلة") }
                    TextButton(onClick = { vm.openPdfPage(d, 1) }) { Text("عرض PDF") }
                    TextButton(onClick = { vm.deletePdfDocument(d.id) }) { Text("حذف") }
                }
            } }
        }

        Text("الأسئلة (${questions.size})", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(value = subjectFilter, onValueChange = { subjectFilter = it }, label = { Text("تصفية المادة") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = topicFilter, onValueChange = { topicFilter = it }, label = { Text("تصفية الموضوع") }, modifier = Modifier.fillMaxWidth())
        if (questions.isEmpty()) Text("لا توجد أسئلة مطابقة. أضف سؤالًا من صفحة PDF دون افتراض أن النص كله أسئلة.")
        questions.take(80).forEach { q ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(q.question, maxLines = 4, overflow = TextOverflow.Visible, style = MaterialTheme.typography.titleSmall)
                Text("${q.subject} · ${q.topic} · ${q.documentName} · صفحة ${q.pageNumber}", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { docs.firstOrNull { it.id == q.documentId }?.let { vm.openPdfPage(it, q.pageNumber) } }) { Text("الصفحة الأصلية") }
                    TextButton(onClick = { editingQuestion = q }) { Text("تعديل") }
                    TextButton(onClick = { vm.deleteQuestion(q.id) }) { Text("حذف") }
                }
            } }
        }
    }

    val target = editorTarget
    if (target != null) QuestionEditorDialog(
        initial = null, document = target.first, pageNumber = target.second,
        onDismiss = { editorTarget = null },
        onSave = { q -> vm.saveQuestion(q); editorTarget = null }
    )
    val editing = editingQuestion
    if (editing != null) docs.firstOrNull { it.id == editing.documentId }?.let { doc ->
        QuestionEditorDialog(initial = editing, document = doc, pageNumber = editing.pageNumber,
            onDismiss = { editingQuestion = null }, onSave = { q -> vm.saveQuestion(q); editingQuestion = null })
    }
}

@Composable
private fun PdfDocumentManager(vm: MainVm, doc: PdfDocumentEntity, onBack: () -> Unit,
                               onAddQuestion: (Int) -> Unit, onEditQuestion: (QuestionEntity) -> Unit) {
    val ctx = LocalContext.current
    val pages by remember(doc.id) { vm.db.bank().pagesFor(doc.id) }.collectAsState(initial = emptyList())
    val questions by vm.bankQuestions.collectAsState()
    val docQuestions = questions.filter { it.documentId == doc.id }.sortedBy { it.pageNumber }
    var pageTextOpen by remember { mutableStateOf<Int?>(null) }
    var addPage by remember { mutableStateOf<Int?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(doc.displayName, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("رجوع") }
        }
        Text("استعرض الصفحات نصيًا إن أمكن، أو افتحها كصورة. لا يُفترض أن كل فقرة سؤال؛ أدخل ما تحتاجه فقط.")
        LazyColumn(Modifier.fillMaxWidth().height(360.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items((1..doc.pageCount).toList(), key = { it }) { page ->
                val text = pages.firstOrNull { it.pageNumber == page }?.text.orEmpty()
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("الصفحة $page", style = MaterialTheme.typography.titleSmall)
                    if (text.isNotBlank()) Text(if (pageTextOpen == page) text.take(3000) else text.take(260), style = MaterialTheme.typography.bodySmall, maxLines = if (pageTextOpen == page) Int.MAX_VALUE else 6, overflow = TextOverflow.Visible)
                    else Text("لا يوجد نص قابل للاستخراج في هذه الصفحة.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { vm.openPdfPage(doc, page) }) { Text("عرض الصفحة") }
                        TextButton(onClick = { addPage = page }) { Text("إضافة سؤال") }
                        if (text.isNotBlank()) TextButton(onClick = { pageTextOpen = if (pageTextOpen == page) null else page }) { Text(if (pageTextOpen == page) "طي النص" else "عرض النص") }
                    }
                } }
            }
        }
        Text("أسئلة هذا الملف (${docQuestions.size})", style = MaterialTheme.typography.titleMedium)
        docQuestions.forEach { q ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) {
                Text("صفحة ${q.pageNumber}: ${q.question}", maxLines = 3, overflow = TextOverflow.Visible)
                Row {
                    TextButton(onClick = { vm.openPdfPage(doc, q.pageNumber) }) { Text("الأصل") }
                    TextButton(onClick = { onEditQuestion(q) }) { Text("تعديل") }
                    TextButton(onClick = { vm.deleteQuestion(q.id) }) { Text("حذف") }
                }
            } }
        }
    }
    val add = addPage
    if (add != null) QuestionEditorDialog(initial = null, document = doc, pageNumber = add,
        onDismiss = { addPage = null }, onSave = { vm.saveQuestion(it); addPage = null })
}

@Composable
private fun QuestionEditorDialog(initial: QuestionEntity?, document: PdfDocumentEntity, pageNumber: Int,
                                 onDismiss: () -> Unit, onSave: (QuestionEntity) -> Unit) {
    var page by remember { mutableStateOf(pageNumber.toString()) }
    var subject by remember { mutableStateOf(initial?.subject ?: "") }
    var topic by remember { mutableStateOf(initial?.topic ?: "") }
    var question by remember { mutableStateOf(initial?.question ?: "") }
    var answer by remember { mutableStateOf(initial?.correctAnswer ?: "") }
    var error by remember { mutableStateOf("") }

    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (initial == null) "إضافة سؤال يدويًا" else "تعديل سؤال") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("المصدر: ${document.displayName}")
            OutlinedTextField(value = page, onValueChange = { page = it.filter(Char::isDigit).take(4) }, label = { Text("رقم الصفحة") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("المادة") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = topic, onValueChange = { topic = it }, label = { Text("الموضوع") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = question, onValueChange = { question = it }, label = { Text("السؤال") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            OutlinedTextField(value = answer, onValueChange = { answer = it }, label = { Text("الإجابة الصحيحة إن كانت متوفرة (اختياري)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Text("لا يُنشئ التطبيق إجابة تلقائيًا. اترك الحقل فارغًا إذا لم تكن الإجابة موثقة.")
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { TextButton(onClick = {
            val p = page.toIntOrNull()
            error = when {
                p == null || p < 1 || p > document.pageCount -> "رقم الصفحة يجب أن يكون بين 1 و${document.pageCount}."
                subject.isBlank() -> "المادة مطلوبة."
                question.isBlank() -> "السؤال مطلوب."
                else -> ""
            }
            if (error.isBlank()) onSave((initial ?: QuestionEntity(
                id = UUID.randomUUID().toString(), documentId = document.id, documentName = document.displayName,
                pageNumber = p!!, subject = "", topic = "", question = ""
            )).copy(pageNumber = p!!, subject = subject.trim(), topic = topic.trim(),
                question = question.trim(), correctAnswer = answer.trim().ifBlank { null }))
        }) { Text("حفظ السؤال") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun PdfViewerScreen(vm: MainVm, request: OpenPdfRequest, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val bitmap by vm.pdfViewerBitmap.collectAsState()
    val pdfError by vm.pdfViewerError.collectAsState()
    var scale by remember(request) { mutableStateOf(1f) }
    var offset by remember(request) { mutableStateOf(Offset.Zero) }
    LaunchedEffect(request) { vm.renderPdfPage(ctx, request) }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("رجوع") }
            Text("${request.document.displayName} — صفحة ${request.pageNumber} من ${request.document.pageCount}", maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
        }
        if (pdfError != null) {
            Text(pdfError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            Text("أعد استيراد ملف PDF من بنك الأسئلة أو تحقق من وجود الملف الأصلي.", style = MaterialTheme.typography.bodySmall)
        } else if (bitmap == null) {
            CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
            Text("جارٍ تجهيز الصفحة…", style = MaterialTheme.typography.bodySmall)
        } else {
            Text("استخدم إصبعين للتكبير والتحريك.", style = MaterialTheme.typography.bodySmall)
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = "صفحة PDF رقم ${request.pageNumber}",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().pointerInput(request) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 4f)
                        offset = if (scale > 1f) offset + pan else Offset.Zero
                    }
                }.graphicsLayer {
                    scaleX = scale; scaleY = scale
                    translationX = offset.x; translationY = offset.y
                }
            )
        }
    }
}

@Composable
fun SelfQuizScreen(vm: MainVm) {
    val scope = rememberCoroutineScope()
    val questions by vm.bankQuestions.collectAsState()
    val attempts by vm.bankAttempts.collectAsState()
    var subject by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var count by remember { mutableStateOf(10) }
    var message by remember { mutableStateOf("") }
    var active by remember { mutableStateOf<ActiveQuiz?>(null) }

    val activeQuiz = active
    if (activeQuiz != null) {
        QuizRunner(vm, activeQuiz, onMessage = { message = it }, onFinish = { active = null })
        return
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("اختبر نفسي", style = MaterialTheme.typography.headlineSmall)
        Text("يعرض سؤالًا واحدًا في كل مرة. لا يولّد التطبيق أسئلة وهمية؛ إن لم توجد أسئلة مناسبة سيخبرك بذلك بوضوح.")
        OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("المادة (اختياري)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = topic, onValueChange = { topic = it }, label = { Text("الموضوع (اختياري)") }, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("عدد الأسئلة: $count"); Slider(value = count.toFloat(), onValueChange = { count = it.toInt() }, valueRange = 1f..50f)
        }
        Button(onClick = { scope.launch {
            val (quiz, error) = vm.startQuiz(subject.ifBlank { null }, topic.ifBlank { null }, count)
            active = quiz; message = error
        } }, modifier = Modifier.fillMaxWidth()) { Text("بدء اختبار جديد") }
        OutlinedButton(onClick = { scope.launch {
            val (quiz, error) = vm.resumeQuiz(); active = quiz; message = error
        } }, modifier = Modifier.fillMaxWidth()) { Text("استئناف اختبار غير مكتمل") }
        if (message.isNotBlank()) Text(message, color = if (message.startsWith("لا") || message.startsWith("الاختبار")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)

        Text("السجل", style = MaterialTheme.typography.titleMedium)
        if (attempts.isEmpty()) Text("لا توجد محاولات بعد.")
        attempts.take(30).forEach { a ->
            Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${a.subject ?: "كل المواد"}${a.topic?.let { " · $it" } ?: ""}", style = MaterialTheme.typography.titleSmall)
                    Text("${a.correct} صحيحة من ${a.total} · ${if (a.status == QuizStatus.DONE) "مكتمل" else "غير مكتمل"}", style = MaterialTheme.typography.bodySmall)
                }
                Text("${if (a.total == 0) 0 else 100 * a.correct / a.total}%", style = MaterialTheme.typography.titleMedium)
            } }
        }
    }
}

@Composable
private fun QuizRunner(vm: MainVm, initialQuiz: ActiveQuiz, onMessage: (String) -> Unit, onFinish: () -> Unit) {
    val scope = rememberCoroutineScope()
    var quiz by remember(initialQuiz.attempt.id) { mutableStateOf(initialQuiz) }
    var index by remember(initialQuiz.attempt.id) { mutableStateOf(initialQuiz.attempt.answered.coerceIn(0, initialQuiz.questions.lastIndex.coerceAtLeast(0))) }
    var userAnswer by remember { mutableStateOf("") }
    var revealed by remember { mutableStateOf(false) }
    val q = quiz.questions.getOrNull(index)

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("اختبار ذاتي — ${index + 1} من ${quiz.questions.size}", style = MaterialTheme.typography.headlineSmall)
        LinearProgressIndicator(progress = { index.toFloat() / quiz.questions.size.coerceAtLeast(1) }, modifier = Modifier.fillMaxWidth().height(8.dp))
        if (q == null) { Text("انتهت الأسئلة."); onFinish(); return@Column }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${q.subject} · ${q.topic} · ${q.documentName} صفحة ${q.pageNumber}", style = MaterialTheme.typography.bodySmall)
            Text(q.question, style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(value = userAnswer, onValueChange = { userAnswer = it }, label = { Text("اكتب محاولة الإجابة قبل كشف الإجابة") }, modifier = Modifier.fillMaxWidth(), minLines = 3, enabled = !revealed)
            if (!revealed) Button(onClick = {
                if (userAnswer.isBlank()) onMessage("اكتب محاولة إجابة أولًا.") else revealed = true
            }, modifier = Modifier.fillMaxWidth()) { Text("إظهار الإجابة وتقييم نفسي") }
            if (revealed) {
                Text("الإجابة المحفوظة: ${q.correctAnswer ?: "غير متوفرة في البنك"}", style = MaterialTheme.typography.titleMedium)
                if (q.correctAnswer == null) Text("لا توجد إجابة موثقة؛ راجع المصدر بنفسك ثم قيّم المحاولة بصراحة.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { scope.launch {
                        val (next, error) = vm.answerQuizQuestion(quiz, index, userAnswer, true)
                        if (next == null) { onMessage(error); onFinish() } else { quiz = next; index++; userAnswer = ""; revealed = false }
                    } }, modifier = Modifier.weight(1f)) { Text("كانت صحيحة ✓") }
                    OutlinedButton(onClick = { scope.launch {
                        val (next, error) = vm.answerQuizQuestion(quiz, index, userAnswer, false)
                        if (next == null) { onMessage(error); onFinish() } else { quiz = next; index++; userAnswer = ""; revealed = false }
                    } }, modifier = Modifier.weight(1f)) { Text("كانت خاطئة ✗") }
                }
            }
        } }
        OutlinedButton(onClick = { vm.finishQuiz(quiz.attempt.id); onMessage("تم حفظ التقدم؛ تقدر ترجع لاحقًا ولا تفقد النتائج."); onFinish() }) { Text("إنهاء والعودة لاحقًا") }
    }
}

@Composable
fun DueReviewsCard(vm: MainVm) {
    val questions by vm.bankQuestions.collectAsState()
    val today = LocalDate.now().toString()
    val due = questions.filter { it.nextReviewAt != null && it.nextReviewAt <= today }.sortedBy { it.nextReviewAt }
    if (due.isEmpty()) return
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("مراجعات مستحقة اليوم (${due.size})", style = MaterialTheme.typography.titleMedium)
        due.take(5).forEach { q -> Text("• ${q.subject} · ${q.topic}: ${q.question.take(90)}", maxLines = 2, overflow = TextOverflow.Visible, style = MaterialTheme.typography.bodySmall) }
        if (due.size > 5) Text("و${due.size - 5} أخرى من صفحة الإتقان.", style = MaterialTheme.typography.bodySmall)
    } }
}

private fun Long.toShortDateText(): String = DateFormat.getDateInstance(DateFormat.SHORT).format(Date(this))

@Composable
fun MasteryScreen(vm: MainVm, tasks: List<UiTask>) {
    val scope = rememberCoroutineScope()
    val questions by vm.bankQuestions.collectAsState()
    val answers by vm.bankAnswers.collectAsState()
    val docs by vm.bankDocuments.collectAsState()
    var showEvidence by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<QuestionEntity?>(null) }
    var editingDate by remember { mutableStateOf<QuestionEntity?>(null) }
    var retest by remember { mutableStateOf<ActiveQuiz?>(null) }
    var message by remember { mutableStateOf("") }

    val activeRetest = retest
    if (activeRetest != null) {
        QuizRunner(vm, activeRetest, onMessage = { message = it }, onFinish = { retest = null })
        return
    }
    if (showEvidence) { EvidenceScreen(onBack = { showEvidence = false }); return }

    val mastery = MasteryCalculator.calculate(tasks, answers)
    val today = LocalDate.now().toString()
    val due = questions.filter { it.nextReviewAt != null && it.nextReviewAt <= today }
    val errors = questions.filter { it.errorCount > 0 }.sortedWith(compareByDescending<QuestionEntity> { it.errorCount }.thenBy { it.nextReviewAt })

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("مؤشر الإتقان", style = MaterialTheme.typography.headlineSmall)
        MasteryCard("إنجاز مهام الجدول", mastery.schedulePct, mastery.scheduleBase, "مهمة") { !mastery.enoughSchedule }
        MasteryCard("نتائج الاختبارات", mastery.quizPct, mastery.quizBase, "إجابة") { !mastery.enoughQuiz }
        MasteryCard("الاحتفاظ بعد المرور الزمني", mastery.retentionPct, mastery.retentionBase, "مراجعة لاحقة") { !mastery.enoughRetention }
        Text("لا تعتبر مشاهدة المحاضرة وحدها دليل إتقان؛ المؤشر يعتمد على الإنجاز والإجابة والمراجعة اللاحقة فقط.")
        OutlinedButton(onClick = { showEvidence = true }, modifier = Modifier.fillMaxWidth()) { Text("الأدلة العلمية وحدود التطبيق") }

        Text("مراجعات مستحقة (${due.size})", style = MaterialTheme.typography.titleMedium)
        due.take(20).forEach { q -> ReviewRow(q, docs, onOpen = { d -> vm.openPdfPage(d, q.pageNumber) }, onEdit = { editing = q }, onDate = { editingDate = q }) }
        if (due.isEmpty()) Text("لا توجد مراجعات مستحقة اليوم.")

        Text("سجل الأخطاء (${errors.size})", style = MaterialTheme.typography.titleMedium)
        errors.take(50).forEach { q ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("${q.subject} · ${q.topic}", style = MaterialTheme.typography.titleSmall)
                Text(q.question, maxLines = 3, overflow = TextOverflow.Visible)
                val lastAnswer = answers.filter { it.questionId == q.id }.maxByOrNull { it.answeredAt }
                val lastWrong = answers.lastOrNull { it.questionId == q.id && !it.isCorrect }
                Text("إجابة الطالب: ${lastWrong?.userAnswer ?: "—"}", style = MaterialTheme.typography.bodySmall)
                Text("الإجابة الصحيحة: ${q.correctAnswer ?: "غير موثقة"}", style = MaterialTheme.typography.bodySmall)
                Text("عدد مرات الخطأ: ${q.errorCount} · آخر نتيجة: ${q.lastResult ?: "—"} · تاريخ آخر محاولة: ${lastAnswer?.answeredAt?.toShortDateText() ?: "—"} · المراجعة التالية: ${q.nextReviewAt ?: "مكتملة مؤقتًا"}", style = MaterialTheme.typography.bodySmall)
                Text("المصدر: ${q.documentName} · صفحة ${q.pageNumber}", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { docs.firstOrNull { it.id == q.documentId }?.let { vm.openPdfPage(it, q.pageNumber) } }) { Text("المصدر") }
                    TextButton(onClick = { scope.launch { val (quiz, error) = vm.startQuiz(q.subject, q.topic, 1); retest = quiz; message = error } }) { Text("إعادة الاختبار") }
                    TextButton(onClick = { editing = q }) { Text("تعديل") }
                    TextButton(onClick = { vm.deleteQuestion(q.id) }) { Text("حذف") }
                }
            } }
        }
        if (errors.isEmpty()) Text("لا توجد أخطاء مسجلة. عند الإجابة الخاطئة ستُضاف الأسئلة هنا تلقائيًا.")
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error)
    }

    val edit = editing
    if (edit != null) docs.firstOrNull { it.id == edit.documentId }?.let { doc ->
        QuestionEditorDialog(initial = edit, document = doc, pageNumber = edit.pageNumber,
            onDismiss = { editing = null }, onSave = { vm.saveQuestion(it); editing = null })
    }
    val dateEdit = editingDate
    if (dateEdit != null) ReviewDateDialog(initial = dateEdit, onDismiss = { editingDate = null }, onSave = { vm.saveQuestion(it); editingDate = null })
}

@Composable
private fun MasteryCard(title: String, pct: Int, base: Int, baseName: String, insufficient: () -> Boolean) {
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text("$pct%")
        }
        LinearProgressIndicator(progress = { pct / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp))
        Text(if (insufficient()) "البيانات غير كافية بعد." else "يستند إلى $base $baseName.", style = MaterialTheme.typography.bodySmall)
    } }
}

@Composable
private fun ReviewRow(q: QuestionEntity, docs: List<PdfDocumentEntity>, onOpen: (PdfDocumentEntity) -> Unit, onEdit: () -> Unit, onDate: () -> Unit) {
    Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("${q.subject} · ${q.topic}: ${q.question.take(90)}", maxLines = 2, overflow = TextOverflow.Visible)
            Text("المراجعة: ${q.nextReviewAt}", style = MaterialTheme.typography.bodySmall)
        }
        docs.firstOrNull { it.id == q.documentId }?.let { TextButton(onClick = { onOpen(it) }) { Text("الأصل") } }
        TextButton(onClick = onDate) { Text("الموعد") }
        TextButton(onClick = onEdit) { Text("تعديل") }
    } }
}

@Composable
private fun ReviewDateDialog(initial: QuestionEntity, onDismiss: () -> Unit, onSave: (QuestionEntity) -> Unit) {
    var date by remember { mutableStateOf(initial.nextReviewAt ?: "") }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("تعديل موعد المراجعة") },
        text = { Column {
            Text("اترك الحقل فارغًا لاعتبار السؤال مكتملًا مؤقتًا.")
            OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("YYYY-MM-DD") }, modifier = Modifier.fillMaxWidth())
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        } },
        confirmButton = { TextButton(onClick = {
            val parsed = if (date.isBlank()) null else try { LocalDate.parse(date.trim()) } catch (e: Exception) { null }
            if (date.isNotBlank() && parsed == null) error = "صيغة التاريخ غير صالحة."
            else onSave(initial.copy(nextReviewAt = parsed?.toString()))
        }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun EvidenceScreen(onBack: () -> Unit) {
    val uriHandler = LocalUriHandler.current
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("الأدلة العلمية", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = onBack) { Text("رجوع") }
        }
        Text("المصادر التالية تدعم بصورة عامة فائدة الاسترجاع النشط والتوزيع المتباعد للمراجعة:")
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
            Text("Dunlosky et al. (2013) — Improving Students’ Learning With Effective Learning Techniques")
            Text("https://doi.org/10.1177/1529100612453266", color = MaterialTheme.colorScheme.primary)
            TextButton(onClick = { uriHandler.openUri("https://doi.org/10.1177/1529100612453266") }) { Text("فتح الرابط") }
        } }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
            Text("Karpicke & Roediger (2008) — The Critical Importance of Retrieval for Learning")
            Text("https://files.eric.ed.gov/fulltext/EJ1021069.pdf", color = MaterialTheme.colorScheme.primary)
            TextButton(onClick = { uriHandler.openUri("https://files.eric.ed.gov/fulltext/EJ1021069.pdf") }) { Text("فتح الرابط") }
        } }
        Text("الفرق بين الدراسات والتطبيق:", style = MaterialTheme.typography.titleMedium)
        Text("• الدراسات تناقش مبادئ عامة مثل الاسترجاع والتباعد، لكنها لا تعني أن فاصلًا واحدًا يناسب كل الطالب.")
        Text("• التطبيق ينفذ نموذجًا بسيطًا: خطأ يقريب المراجعة، صواب يباعدها تدريجيًا ثم يوقف التكرار عند مرحلة محددة.")
        Text("• المواعيد قابلة للتعديل داخل صفحة الإتقان، والمؤشر لا يُقدّم نفسه كتشخيص علمي أو وعدًا مضمونًا.")
        Text("• لا يُحتسب إتقال المحاضرة وحده؛ الإتقان هنا مبني على المهام المنجزة والإجابات والمراجعة اللاحقة.")
    }
}

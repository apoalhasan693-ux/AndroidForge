package com.rafiq6.study

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.ZoneId
import java.time.ZonedDateTime

@Entity(tableName = "schedules")
data class ScheduleEntity(
    @PrimaryKey val scheduleId: String,
    val name: String,
    val studentAlias: String? = null,
    val stage: String? = null,
    val country: String? = null,
    val timeZone: String = "Asia/Baghdad",
    val startDate: String? = null,
    val endDate: String? = null,
    val importedAt: Long = System.currentTimeMillis(),
    val active: Boolean = false,
    val contentHash: String? = null,   // بصمة المحتوى لمنع تكرار الاستيراد (null للجداول القديمة)
    // لقطة قيود «توزيع الأسبوع» (أيام الراحة وأيام كل مادة) وقت توليد/اعتماد هذا الجدول — JSON عبر WeekPlanSnapshot.
    // null = جدول بلا قيود أيام محفوظة (استيراد مباشر خارج المعالج، أو جدول قديم قبل هذا الحقل) فلا تُفرض أي قيود.
    val weekPlanJson: String? = null
)

@Entity(tableName = "schedule_tasks")
data class TaskEntity(
    @PrimaryKey val id: String,                 // scheduleId::sourceTaskId
    val scheduleId: String,
    val sourceId: String,
    val date: String,
    val dayName: String,
    val subject: String,
    val type: String,
    val title: String,
    val lectureNo: Int?,
    val durationMin: Int,
    val startMin: Int?,
    val endMin: Int?,
    val flexible: Boolean = false,
    val fixed: Boolean = false,
    val notify: Boolean = true,
    val note: String? = null,
    val originalDate: String? = null,
    val originalStartMin: Int? = null,
    val originalEndMin: Int? = null,
    val rescheduleReason: String? = null,
    val remindBeforeMin: Int = 15,
    val reviewItemId: String? = null   // الميزة 5: يربط مهمة المراجعة هذه بموضوع المراجعة (ReviewItemEntity) الذي أنشأها، إن وُجد
) {
    fun stableKey(): String = "$scheduleId::$sourceId"
}

@Entity(tableName = "progress")
data class ProgressEntity(
    @PrimaryKey val taskId: String,
    val done: Boolean = false,
    val doneAt: Long? = null,
    val actualMin: Int? = null
)

// الميزة 5: المراجعة الذكية حسب النسيان — موضوع مراجعة واحد أدخله المستخدم بنفسه (لا عناوين مختلقة).
// stage: الموضع الحالي في تسلسل الفترات (0 = لم تُجدول أي مراجعة بعد). active=false بعد إيقافه يدويًا من المستخدم.
@Entity(tableName = "review_items")
data class ReviewItemEntity(
    @PrimaryKey val id: String,
    val scheduleId: String,
    val subject: String,
    val title: String,
    val lectureNo: Int? = null,
    val studyDate: String,
    val notes: String? = null,
    val sourceTaskId: String? = null,
    val stage: Int = 0,
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reschedule_snapshots")
data class RescheduleSnapshotEntity(
    @PrimaryKey val id: String,
    val scheduleId: String,
    val createdAt: Long,
    val reason: String,
    val payload: String
)

// المخطّط الذكي: نوع اليوم المحدد من الطالب (مشغول/خفيف/بلا تراكمات/راحة…) وتجاوز اختياري للحد اليومي.
@Entity(
    tableName = "day_overrides",
    primaryKeys = ["scheduleId", "date"],
    indices = [Index("scheduleId"), Index("date")]
)
data class DayOverrideEntity(
    val scheduleId: String,
    val date: String,
    val kind: String,
    val capacityMin: Int? = null
)

data class UiTask(
    val task: TaskEntity,
    val progress: ProgressEntity? = null
) {
    val id: String get() = task.id
    val scheduleId: String get() = task.scheduleId
    val sourceId: String get() = task.sourceId
    val date: String get() = task.date
    val dayName: String get() = task.dayName
    val subject: String get() = task.subject
    val type: String get() = task.type
    val title: String get() = task.title
    val lectureNo: Int? get() = task.lectureNo
    val durationMin: Int get() = task.durationMin
    val startMin: Int? get() = task.startMin
    val endMin: Int? get() = task.endMin
    val flexible: Boolean get() = task.flexible
    val fixed: Boolean get() = task.fixed
    val notify: Boolean get() = task.notify
    val note: String? get() = task.note
    val originalDate: String? get() = task.originalDate
    val originalStartMin: Int? get() = task.originalStartMin
    val originalEndMin: Int? get() = task.originalEndMin
    val rescheduleReason: String? get() = task.rescheduleReason
    val remindBeforeMin: Int get() = task.remindBeforeMin
    val reviewItemId: String? get() = task.reviewItemId
    val done: Boolean get() = progress?.done ?: false
    val doneAt: Long? get() = progress?.doneAt
    val actualMin: Int? get() = progress?.actualMin
}

data class ScheduleBundle(
    val schedule: ScheduleEntity? = null,
    val tasks: List<UiTask> = emptyList()
)

object Subjects {
    val colors = mapOf(
        "فيزياء" to 0xFF2E6FB7, "كيمياء" to 0xFF7E57C2, "رياضيات" to 0xFFF4842B,
        "أحياء" to 0xFF43A047, "عربي" to 0xFFC9A227, "إنكليزي" to 0xFF4FC3F7,
        "التزام" to 0xFF795548
    )
    fun color(s: String) = colors[s] ?: 0xFF607D8B
    val BAGHDAD: ZoneId = ZoneId.of("Asia/Baghdad")
    fun now(): ZonedDateTime = ZonedDateTime.now(BAGHDAD)
    fun fmt12(min: Int): String {
        val h = min / 60; val m = min % 60
        val period = when { h < 12 -> "صباحاً"; h == 12 -> "ظهراً"; else -> "مساءً" }
        val h12 = if (h == 0 || h == 12) 12 else h % 12
        return "%d:%02d %s".format(h12, m, period)
    }
    fun toMin(hhmm: String): Int { val p = hhmm.split(":"); return p[0].toInt() * 60 + p[1].toInt() }
    fun fromMin(min: Int): String = "%02d:%02d".format(min / 60, min % 60)
}

object TaskTypes {
    const val NEW = "محاضرة جديدة"
    const val OLD = "محاضرة قديمة"
    const val DAILY_EXAM = "امتحان يومي"
    const val CUMULATIVE_EXAM = "امتحان تراكمي"
    const val QUIZ = "اختبار"
    const val HOMEWORK = "واجب"
    const val REVIEW = "مراجعة"
    const val PERSONAL = "نشاط شخصي"
    const val COMMITMENT = "التزام ثابت"
    const val COMPENSATION = "تعويض"
    const val EXAM = "امتحان"

    fun isAssessment(type: String): Boolean =
        type.contains("امتحان") || type.contains("اختبار")
}

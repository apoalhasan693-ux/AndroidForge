package com.rafiq6.study

import android.app.ActivityOptions
import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.telecom.TelecomManager

/** مستقبِل إدارة الجهاز. لا يطلب أي سياسة؛ يلزم فقط ليكون رفيق «مالك الجهاز» (Device Owner). */
class FocusAdminReceiver : DeviceAdminReceiver()

/**
 * القفل الحقيقي عبر Lock Task Mode الرسمي.
 * يعمل فقط إذا كان رفيق Device Owner (setLockTaskPackages تتطلب ذلك). على جهاز عادي لا تعمل
 * ولا نتظاهر بعكس ذلك: begin() تعيد false.
 */
object FocusLockdown {
    private const val RECEIVER_CLASS = "com.rafiq6.study.FocusAdminReceiver"

    private fun dpm(c: Context) = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    private fun admin(c: Context) = ComponentName(c, FocusAdminReceiver::class.java)

    fun isDeviceOwner(c: Context): Boolean =
        runCatching { dpm(c).isDeviceOwnerApp(c.packageName) }.getOrDefault(false)

    /** الأمر الرسمي لتعيين رفيق مالكًا للجهاز (يُنفَّذ مرة واحدة من حاسوب عبر adb). */
    fun setupCommand(c: Context): String =
        "adb shell dpm set-device-owner ${c.packageName}/$RECEIVER_CLASS"

    private fun dialerPackage(c: Context): String? = runCatching {
        (c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage
    }.getOrNull()

    /** التطبيقات المسموحة التي ما زال لها نشاط تشغيل (لم تُحذف/تُعطَّل بعد الحفظ). */
    fun launchable(c: Context, pkgs: List<String>): Pair<List<String>, List<String>> {
        val pm = c.packageManager
        val ok = pkgs.filter { runCatching { pm.getLaunchIntentForPackage(it) != null }.getOrDefault(false) }.toSet()
        return FocusSelection.sanitize(pkgs, ok)
    }

    /** يضبط قائمة Lock Task. true فقط إذا طُبّق فعلًا. */
    fun begin(c: Context, allowed: List<String>): Boolean {
        if (!isDeviceOwner(c)) return false
        return runCatching {
            val pkgs = FocusSelection.lockTaskPackages(c.packageName, allowed, dialerPackage(c))
            val d = dpm(c); val a = admin(c)
            d.setLockTaskPackages(a, pkgs.toTypedArray())
            if (android.os.Build.VERSION.SDK_INT >= 28)
                // نظرة عامة فقط (للتبديل بين التطبيقين). بلا Home/إشعارات/قائمة الطاقة.
                d.setLockTaskFeatures(a, DevicePolicyManager.LOCK_TASK_FEATURE_OVERVIEW)
            true
        }.getOrDefault(false)
    }

    /** فك التقييد: إفراغ القائمة ينهي Lock Task للمهام غير المسموحة. آمن عند الاستدعاء المتكرر. */
    fun release(c: Context) {
        if (!isDeviceOwner(c)) return
        runCatching {
            dpm(c).setLockTaskPackages(admin(c), emptyArray())
            if (android.os.Build.VERSION.SDK_INT >= 28)
                dpm(c).setLockTaskFeatures(admin(c), 0)
        }
    }

    /** يفتح تطبيقًا؛ داخل Lock Task إذا كان رفيق مالك الجهاز. */
    fun launch(c: Context, pkg: String, lockTask: Boolean): Boolean {
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        return runCatching {
            val opts = ActivityOptions.makeBasic()
            if (lockTask && isDeviceOwner(c)) opts.setLockTaskEnabled(true)
            c.startActivity(i, opts.toBundle()); true
        }.getOrDefault(false)
    }
}

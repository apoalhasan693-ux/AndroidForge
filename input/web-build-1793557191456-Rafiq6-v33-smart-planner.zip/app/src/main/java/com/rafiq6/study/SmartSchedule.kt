package com.rafiq6.study

import java.time.LocalDate
import java.time.temporal.ChronoUnit

// منطق نقي (بلا اعتماديات Android) للمخطّط الذكي المتكيّف: تصنيف، اكتشاف الفائتات، إخلاء اليوم، تأجيل، موازنة الحمل.

enum class TaskKind { NEW_LECTURE, BACKLOG_LECTURE, EXAM, REVISION, COMMITMENT, FLEXIBLE_TASK }
enum class TaskStatus { PENDING, COMPLETED, MISSED, DEFERRED }
enum class DayKind(val label: String) {
    NORMAL_DAY("عادي"), EXAM_DAY("امتحان"), BUSY_DAY("مشغول"),
    LIGHT_DAY("خفيف"), BACKLOG_FREE_DAY("بلا تراكمات"), REST_DAY("راحة")
}
enum class DeferMode { NEXT_DAY, NEAREST_FREE, PICK_DATE, AUTO_DISTRIBUTE }
enum class LoadLevel(val label: String, val argb: Long) {
    LIGHT("خفيف", 0xFF43A047), MEDIUM("متوسط", 0xFFF4842B),
    HIGH("مرتفع", 0xFFE53935), OVER("فوق الحد", 0xFF8E24AA)
}

object SmartKinds {
    fun of(type: String): TaskKind = when (type) {
        TaskTypes.NEW -> TaskKind.NEW_LECTURE
        TaskTypes.OLD, TaskTypes.COMPENSATION -> TaskKind.BACKLOG_LECTURE
        TaskTypes.DAILY_EXAM, TaskTypes.CUMULATIVE_EXAM, TaskTypes.QUIZ, TaskTypes.EXAM -> TaskKind.EXAM
        TaskTypes.REVIEW -> TaskKind.REVISION
        TaskTypes.COMMITMENT -> TaskKind.COMMITMENT
        else -> TaskKind.FLEXIBLE_TASK
    }

    /** امتحانات ثابتة ← التزامات ← جديد ← تراكمات ← مراجعات ← مرنة. */
    fun priority(t: TaskEntity): Int = when (of(t.type)) {
        TaskKind.EXAM -> if (t.fixed) 0 else 1
        TaskKind.COMMITMENT -> 2
        TaskKind.NEW_LECTURE -> 3
        TaskKind.BACKLOG_LECTURE -> 4
        TaskKind.REVISION -> 5
        TaskKind.FLEXIBLE_TASK -> 6
    }

    fun isBacklog(t: TaskEntity) = of(t.type) == TaskKind.BACKLOG_LECTURE
    fun isExam(t: TaskEntity) = of(t.type) == TaskKind.EXAM
    /** لا يُرحَّل أبدًا: ثابتة، امتحان، التزام. */
    fun isImmovable(t: TaskEntity) = t.fixed || isExam(t) || of(t.type) == TaskKind.COMMITMENT
}

/** الحالة مشتقّة لا مخزّنة: الإنجاز في progress، والفائت/المؤجل يُحسبان من التاريخ. */
object SmartStatus {
    fun of(t: TaskEntity, done: Boolean, today: LocalDate, nowMin: Int): TaskStatus {
        if (done) return TaskStatus.COMPLETED
        val d = LocalDate.parse(t.date)
        if (d.isBefore(today)) return TaskStatus.MISSED
        if (d == today) {
            val end = t.endMin
            if (end != null && nowMin >= end) return TaskStatus.MISSED
        }
        return if (!t.originalDate.isNullOrBlank() && t.originalDate != t.date) TaskStatus.DEFERRED
        else TaskStatus.PENDING
    }
}

data class StudyCaps(
    val dailyCapMin: Int = 360,
    val mediumPct: Int = 50,
    val highPct: Int = 85,
    val targetFillPct: Int = 85,
    val lightCapPct: Int = 50,
    val busyCapPct: Int = 25,
    val maxScanDays: Int = 42
)

data class Move(
    val taskId: String, val fromDate: String, val toDate: String, val toDayName: String,
    val durationMin: Int, val reason: String
)

/** خطة معاينة قبل التطبيق (اسمها SmartPlan لتفادي التعارض مع ReschedulePlan الخاص بالطلعة). */
data class SmartPlan(
    val scheduleId: String,
    val reason: String,
    val moves: List<Move>,
    val violations: List<String>,
    val addedMinByDate: Map<String, Int>
) {
    val movedTasks: Int get() = moves.size
    val totalMovedMin: Int get() = moves.sumOf { it.durationMin }
}

class SmartEngine(val caps: StudyCaps = StudyCaps()) {

    data class DayStats(
        val date: LocalDate, val dayName: String, val kind: DayKind,
        val capacityMin: Int, val usedMin: Int, val taskCount: Int,
        val timedWindows: List<Pair<Int, Int>>
    ) {
        val freeMin: Int get() = capacityMin - usedMin
    }

    fun levelOf(used: Int, cap: Int): LoadLevel = when {
        used > cap -> LoadLevel.OVER
        cap > 0 && used * 100 >= cap * caps.highPct -> LoadLevel.HIGH
        cap > 0 && used * 100 >= cap * caps.mediumPct -> LoadLevel.MEDIUM
        else -> LoadLevel.LIGHT
    }

    fun capFor(kind: DayKind, overrideCap: Int?): Int = when {
        overrideCap != null -> overrideCap
        kind == DayKind.REST_DAY -> 0
        kind == DayKind.LIGHT_DAY -> caps.dailyCapMin * caps.lightCapPct / 100
        kind == DayKind.BUSY_DAY -> caps.dailyCapMin * caps.busyCapPct / 100
        else -> caps.dailyCapMin
    }

    /** تعليق المستخدم أولًا، ثم الراحة من WeekPlanSnapshot، ثم الامتحان، ثم عادي. */
    fun effectiveKind(
        date: LocalDate, tasksOnDay: List<TaskEntity>,
        overrides: Map<String, DayOverrideEntity>, weekPlan: WeekPlanSnapshot?
    ): DayKind {
        overrides[date.toString()]?.let { o ->
            return runCatching { DayKind.valueOf(o.kind) }.getOrDefault(DayKind.NORMAL_DAY)
        }
        if (weekPlan != null && ScheduleParser.weekday(date) in weekPlan.restDays) return DayKind.REST_DAY
        if (tasksOnDay.any { SmartKinds.isExam(it) }) return DayKind.EXAM_DAY
        return DayKind.NORMAL_DAY
    }

    // ---------- اكتشاف الفائتات (لا إكمال تلقائي) ----------

    fun isMissedNow(t: TaskEntity, done: Boolean, today: LocalDate, nowMin: Int): Boolean {
        if (done || SmartKinds.isImmovable(t)) return false
        val d = LocalDate.parse(t.date)
        if (d.isAfter(today)) return false
        if (d == today) { val end = t.endMin ?: return false; return nowMin >= end }
        return true
    }

    fun detectMissed(tasks: List<TaskEntity>, doneSet: Set<String>, today: LocalDate, nowMin: Int): List<TaskEntity> =
        tasks.filter { isMissedNow(it, it.id in doneSet, today, nowMin) }
            .sortedWith(compareBy({ SmartKinds.priority(it) }, { it.date }, { it.sourceId }))

    fun dayStats(
        date: LocalDate, allTasks: List<TaskEntity>, doneSet: Set<String>,
        overrides: Map<String, DayOverrideEntity>, weekPlan: WeekPlanSnapshot?,
        simulated: Map<String, Int> = emptyMap(), movedOut: Set<String> = emptySet()
    ): DayStats {
        val key = date.toString()
        val onDay = allTasks.filter { it.date == key }
        val kind = effectiveKind(date, onDay, overrides, weekPlan)
        val active = onDay.filter { it.id !in doneSet && it.id !in movedOut }
        val used = active.sumOf { it.durationMin } + (simulated[key] ?: 0)
        val timed = active.filter { it.startMin != null && it.endMin != null }
            .map { it.startMin!! to it.endMin!! }
        return DayStats(date, ScheduleParser.weekday(date), kind,
            capFor(kind, overrides[key]?.capacityMin), used, active.size, timed)
    }

    /** تقييم حتمي (أوزان صحيحة): أكثر فراغًا، أقل ازدحامًا، أقرب للموعد الأصلي، بعيد عن ما قبل الامتحان مباشرة. */
    private fun scoreDay(task: TaskEntity, stats: DayStats, examDates: List<LocalDate>): Long {
        val freeBonus = stats.freeMin.toLong() * 10L
        val countPenalty = stats.taskCount.toLong() * 30L
        val daysShifted = ChronoUnit.DAYS.between(LocalDate.parse(task.date), stats.date).coerceAtLeast(0)
        val proximity = (caps.maxScanDays - daysShifted).coerceAtLeast(-1000L) * 4L
        val examNear = examDates.firstOrNull { !it.isBefore(stats.date) }
        val examPenalty = examNear?.let {
            val days = ChronoUnit.DAYS.between(stats.date, it)
            if (days in 0..2) (3L - days) * 25L else 0L
        } ?: 0L
        val headroom = if (stats.capacityMin > 0 &&
            (stats.usedMin + task.durationMin) * 100 <= stats.capacityMin * caps.targetFillPct) 20L else 0L
        return freeBonus - countPenalty + proximity - examPenalty + headroom
    }

    /**
     * يبحث ابتداءً من max(from+1, earliest) حتى maxScanDays يومًا ويختار الأعلى تقييمًا.
     * قيود صلبة: يوم راحة، يوم بلا تراكمات، أيام المادة المسموحة، الحد اليومي، عدم التداخل الزمني.
     */
    fun planMove(
        task: TaskEntity, from: LocalDate,
        allTasks: List<TaskEntity>, doneSet: Set<String>,
        overrides: Map<String, DayOverrideEntity>, weekPlan: WeekPlanSnapshot?,
        simulated: MutableMap<String, Int>, movedIds: MutableSet<String>,
        skipDates: Set<String> = emptySet(), preferred: LocalDate? = null,
        earliest: LocalDate? = null, reason: String
    ): Move? {
        if (SmartKinds.isImmovable(task) || task.id in movedIds) return null
        val examDates = allTasks.filter { SmartKinds.isExam(it) }.map { LocalDate.parse(it.date) }.sorted()
        val start = listOfNotNull(from.plusDays(1), earliest).maxOrNull()!!
        var best: LocalDate? = null
        var bestScore = Long.MIN_VALUE
        var cursor = start
        var scanned = 0
        while (scanned < caps.maxScanDays) {
            if (cursor.toString() !in skipDates) {
                val stats = dayStats(cursor, allTasks, doneSet, overrides, weekPlan, simulated, movedIds)
                val allowed = when {
                    stats.kind == DayKind.REST_DAY -> false
                    stats.kind == DayKind.BACKLOG_FREE_DAY && SmartKinds.isBacklog(task) -> false
                    weekPlan != null && !weekPlan.isUsable(stats.dayName, task.subject, task.type) -> false
                    else -> true
                }
                val clash = task.startMin != null && task.endMin != null &&
                    stats.timedWindows.any { task.startMin < it.second && it.first < task.endMin }
                if (allowed && stats.freeMin >= task.durationMin && !clash) {
                    var score = scoreDay(task, stats, examDates)
                    if (preferred != null && cursor == preferred) score += 100000L
                    if (score > bestScore) { bestScore = score; best = cursor }
                }
            }
            cursor = cursor.plusDays(1); scanned++
        }
        val target = best ?: return null
        simulated[target.toString()] = (simulated[target.toString()] ?: 0) + task.durationMin
        movedIds += task.id
        return Move(task.id, task.date, target.toString(), ScheduleParser.weekday(target), task.durationMin, reason)
    }

    fun planMissedRelocation(
        scheduleId: String, allTasks: List<TaskEntity>, doneSet: Set<String>,
        today: LocalDate, nowMin: Int,
        overrides: Map<String, DayOverrideEntity>, weekPlan: WeekPlanSnapshot?
    ): SmartPlan {
        val simulated = mutableMapOf<String, Int>()
        val movedIds = mutableSetOf<String>()
        val moves = mutableListOf<Move>()
        val violations = mutableListOf<String>()
        for (t in detectMissed(allTasks, doneSet, today, nowMin)) {
            val m = planMove(t, LocalDate.parse(t.date), allTasks, doneSet, overrides, weekPlan,
                simulated, movedIds, earliest = today.plusDays(1), reason = "محاضرة فائتة رُحّلت تلقائيًا")
            if (m == null) violations += "تعذّر إيجاد موعد مناسب لـ«${t.title}» خلال ${caps.maxScanDays} يومًا."
            else moves += m
        }
        return SmartPlan(scheduleId, "ترحيل المحاضرات الفائتة", moves, violations, simulated.toMap())
    }

    /** إخلاء اليوم من التراكمات فقط؛ الجديد والامتحانات والالتزامات والثابت يبقى. */
    fun planEvacuateDay(
        scheduleId: String, date: LocalDate,
        allTasks: List<TaskEntity>, doneSet: Set<String>,
        overrides: Map<String, DayOverrideEntity>, weekPlan: WeekPlanSnapshot?
    ): SmartPlan {
        val toMove = allTasks.filter {
            it.date == date.toString() && it.id !in doneSet && SmartKinds.isBacklog(it) && !it.fixed
        }
        val simulated = mutableMapOf<String, Int>()
        val movedIds = mutableSetOf<String>()
        val moves = mutableListOf<Move>()
        val violations = mutableListOf<String>()
        for (t in toMove.sortedWith(compareBy({ SmartKinds.priority(it) }, { it.sourceId }))) {
            val m = planMove(t, date, allTasks, doneSet, overrides, weekPlan, simulated, movedIds,
                skipDates = setOf(date.toString()), reason = "إخلاء يوم $date من التراكمات")
            if (m == null) violations += "«${t.title}» (${t.durationMin} د): لا مساحة في الأيام المسموحة خلال ${caps.maxScanDays} يومًا."
            else moves += m
        }
        return SmartPlan(scheduleId, "إخلاء اليوم من التراكمات", moves, violations, simulated.toMap())
    }

    fun planDefer(
        scheduleId: String, ids: List<String>, mode: DeferMode, explicitDate: LocalDate?,
        allTasks: List<TaskEntity>, doneSet: Set<String>,
        overrides: Map<String, DayOverrideEntity>, weekPlan: WeekPlanSnapshot?
    ): SmartPlan {
        val byId = allTasks.associateBy { it.id }
        val targets = ids.mapNotNull { byId[it] }
            .filter { !SmartKinds.isImmovable(it) && it.id !in doneSet }
            .sortedWith(compareBy({ SmartKinds.priority(it) }, { it.sourceId }))
        val simulated = mutableMapOf<String, Int>()
        val movedIds = mutableSetOf<String>()
        val moves = mutableListOf<Move>()
        val violations = mutableListOf<String>()
        for (t in targets) {
            val from = LocalDate.parse(t.date)
            val m: Move? = when (mode) {
                DeferMode.NEXT_DAY -> planMove(t, from, allTasks, doneSet, overrides, weekPlan,
                    simulated, movedIds, preferred = from.plusDays(1), reason = "تأجيل إلى اليوم التالي")
                DeferMode.NEAREST_FREE, DeferMode.AUTO_DISTRIBUTE -> planMove(t, from, allTasks, doneSet,
                    overrides, weekPlan, simulated, movedIds, reason = "تأجيل تلقائي")
                DeferMode.PICK_DATE -> when {
                    explicitDate == null -> { violations += "لم يُحدَّد تاريخ."; null }
                    !explicitDate.isAfter(from) -> { violations += "التاريخ المختار ليس بعد موعد المهمة الحالي."; null }
                    else -> planMove(t, from, allTasks, doneSet, overrides, weekPlan, simulated, movedIds,
                        preferred = explicitDate, earliest = explicitDate, reason = "تأجيل إلى $explicitDate")
                }
            }
            if (m != null) moves += m
            else if (mode != DeferMode.PICK_DATE)
                violations += "تعذّر تأجيل «${t.title}» — لا يوجد يوم مناسب خلال ${caps.maxScanDays} يومًا."
            else if (explicitDate != null && explicitDate.isAfter(from))
                violations += "تعذّر النقل إلى $explicitDate أو بعده: الأيام ممتلئة أو غير مسموحة."
        }
        return SmartPlan(scheduleId, "تأجيل مهام", moves, violations, simulated.toMap())
    }

    /** يتحقق من قيود الحالة الحالية: راحة، حد يومي، تداخل، أيام المادة. */
    fun validateResult(
        allTasks: List<TaskEntity>, doneSet: Set<String>,
        overrides: Map<String, DayOverrideEntity>, weekPlan: WeekPlanSnapshot?
    ): List<String> {
        val violations = mutableListOf<String>()
        for ((dateStr, list) in allTasks.groupBy { it.date }.toSortedMap()) {
            val d = LocalDate.parse(dateStr)
            val wd = ScheduleParser.weekday(d)
            val active = list.filter { it.id !in doneSet }
            val kind = effectiveKind(d, list, overrides, weekPlan)
            if (kind == DayKind.REST_DAY && active.isNotEmpty()) violations += "مهام مجدولة في يوم راحة ($dateStr)."
            val cap = capFor(kind, overrides[dateStr]?.capacityMin)
            val used = active.sumOf { it.durationMin }
            if (kind != DayKind.REST_DAY && used > cap) violations += "تجاوز الحد اليومي في $dateStr: $used/$cap دقيقة."
            val timed = active.filter { it.startMin != null && it.endMin != null }.sortedBy { it.startMin }
            for (i in timed.indices) for (j in i + 1 until timed.size) {
                val x = timed[i]; val y = timed[j]
                if (x.startMin!! < y.endMin!! && y.startMin!! < x.endMin!!)
                    violations += "تداخل زمني في $dateStr بين «${x.title}» و«${y.title}»."
            }
            if (weekPlan != null) for (t in active)
                if (!weekPlan.isUsable(wd, t.subject, t.type))
                    violations += "«${t.title}» مجدولة يوم $wd غير المسموح لمادتها ($dateStr)."
        }
        return violations
    }
}

data class DaySnapshot(
    val date: LocalDate, val dayName: String, val kind: DayKind, val level: LoadLevel,
    val newLectures: List<UiTask>, val backlog: List<UiTask>,
    val exams: List<UiTask>, val commitments: List<UiTask>, val others: List<UiTask>,
    val usedMin: Int, val capMin: Int, val doneCount: Int, val totalCount: Int
) {
    val remainingMin: Int get() = (capMin - usedMin).coerceAtLeast(0)
    val completionPct: Int get() = if (totalCount == 0) 100 else doneCount * 100 / totalCount
}

fun buildDaySnapshot(
    date: LocalDate, tasks: List<UiTask>,
    overrides: Map<String, DayOverrideEntity>, weekPlan: WeekPlanSnapshot?,
    caps: StudyCaps = StudyCaps()
): DaySnapshot {
    val key = date.toString()
    val onDay = tasks.filter { it.date == key }
    val engine = SmartEngine(caps)
    val kind = engine.effectiveKind(date, onDay.map { it.task }, overrides, weekPlan)
    fun sel(k: TaskKind) = onDay.filter { SmartKinds.of(it.type) == k }
    val used = onDay.filter { !it.done }.sumOf { it.durationMin }
    val cap = engine.capFor(kind, overrides[key]?.capacityMin)
    return DaySnapshot(
        date = date, dayName = ScheduleParser.weekday(date), kind = kind, level = engine.levelOf(used, cap),
        newLectures = sel(TaskKind.NEW_LECTURE), backlog = sel(TaskKind.BACKLOG_LECTURE),
        exams = sel(TaskKind.EXAM), commitments = sel(TaskKind.COMMITMENT),
        others = sel(TaskKind.REVISION) + sel(TaskKind.FLEXIBLE_TASK),
        usedMin = used, capMin = cap, doneCount = onDay.count { it.done }, totalCount = onDay.size
    )
}

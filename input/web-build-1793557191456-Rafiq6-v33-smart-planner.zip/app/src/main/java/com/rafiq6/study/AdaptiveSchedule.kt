package com.rafiq6.study

import java.time.LocalDate

// ============================================================
// الميزة 1: الجدول الذكي المتكيّف (Adaptive Schedule)
// يكتشف المهام التي فات موعدها ولم تُنجز، ويبني خطة لإعادة توزيعها
// على الأيام القادمة ضمن القيود المحفوظة مع الجدول (أيام الراحة،
// الأيام المسموحة لكل مادة، الحد اليومي)، دون المساس بالمهام المنجزة
// أو بالمحاضرات الجديدة المثبّتة بموعد محدد مسبقًا.
//
// هذا الملف منطق نقي (pure) لا يعتمد على Android، لذا يمكن اختباره
// مباشرة على JVM دون محاكي. التطبيق الفعلي على قاعدة البيانات يتم
// من MainVm (انظر Vm.kt: planAdaptiveSchedule / applyAdaptiveSchedule).
// ============================================================

/** مهمة متأخرة واحدة ضمن الخطة، مع وجهتها الجديدة إن وُجدت. */
data class AdaptiveMove(
    val task: UiTask,          // المهمة بحالتها الأصلية (قبل النقل)
    val toDate: String,
    val toStart: Int,
    val toEnd: Int
) {
    /** النسخة الجديدة من TaskEntity الجاهزة للحفظ، مع سجل بسبب النقل وموضعه الأصلي. */
    fun resolvedTask(): TaskEntity = task.task.copy(
        date = toDate,
        dayName = ScheduleParser.weekday(LocalDate.parse(toDate)),
        startMin = toStart,
        endMin = toEnd,
        originalDate = task.task.originalDate ?: task.task.date,
        originalStartMin = task.task.originalStartMin ?: task.task.startMin,
        originalEndMin = task.task.originalEndMin ?: task.task.endMin,
        rescheduleReason = "إعادة توزيع تلقائي لمهمة متأخرة (كانت بتاريخ ${task.task.date})"
    )
}

/** مهمة متأخرة تعذّر إيجاد مكان مناسب لها ضمن الأفق الزمني والقيود الحالية. */
data class AdaptiveUnplaced(val task: UiTask, val reason: String)

/** مجموع الدقائق المخطط ليوم واحد بعد تطبيق الخطة (تُستخدم في شاشة المعاينة). */
data class AdaptiveDayLoad(val date: String, val plannedMin: Int, val dailyGoalMin: Int) {
    val overGoal: Boolean get() = plannedMin > dailyGoalMin
}

data class AdaptivePlan(
    val today: LocalDate,
    val overdueTotal: Int,            // كل المهام المتأخرة المكتشفة (قبل الاستبعاد)
    val lockedCount: Int,             // متأخرة لكنها محاضرات/مهام ثابتة الموعد، لن تُنقل دون إذن صريح
    val moves: List<AdaptiveMove>,    // الخطة المقترحة للنقل
    val unplaced: List<AdaptiveUnplaced>,
    val dayLoads: List<AdaptiveDayLoad>,  // الأيام المتأثرة فقط، مرتبة
    val warnings: List<String>
) {
    val movedCount: Int get() = moves.size
    val affectedDates: List<String> get() = (moves.map { it.toDate } + moves.map { it.task.date }).distinct().sorted()
    val hasChanges: Boolean get() = moves.isNotEmpty()
    val hasDeficit: Boolean get() = unplaced.isNotEmpty()
    /** يمرّ خطة بتحقق نهائي صارم قبل الحفظ: لا يُسمح بتجاوز الحد اليومي، ولا بتكرار معرّف مهمة. */
    fun passesFinalValidation(settings: Settings): Boolean {
        if (dayLoads.any { it.plannedMin > settings.dailyGoalMin }) return false
        if (moves.map { it.task.id }.distinct().size != moves.size) return false
        return true
    }
}

object AdaptiveScheduleEngine {

    /** مهمة تُعتبر متأخرة إذا كان تاريخها قبل اليوم الحالي ولم تُنجز بعد. المهام المستقبلية ليست متأخرة أبدًا. */
    fun findOverdue(allTasks: List<UiTask>, today: LocalDate): List<UiTask> =
        allTasks.filter { t ->
            if (t.done) return@filter false
            val d = runCatching { LocalDate.parse(t.date) }.getOrNull() ?: return@filter false
            d.isBefore(today)
        }

    /**
     * يبني خطة إعادة توزيع آمنة. لا يكتب في قاعدة البيانات — فقط يحسب الخطة.
     *
     * horizonDays: عدد الأيام القادمة (من اليوم) التي يُسمح بالبحث فيها عن مكان شاغر.
     * allowLocked: عند true يسمح أيضًا بنقل المهام الثابتة/المحاضرات الجديدة ذات الموعد المحدد
     *              (تستخدم فقط بعد إذن صريح من المستخدم عبر واجهة المستخدم — الافتراضي false).
     */
    fun plan(
        allTasks: List<UiTask>,
        today: LocalDate,
        settings: Settings,
        weekConstraints: WeekPlanSnapshot?,
        horizonDays: Int = 21,
        allowLocked: Boolean = false
    ): AdaptivePlan {
        val overdue = findOverdue(allTasks, today)
        val locked = overdue.filter { it.fixed && !allowLocked }
        val movable = overdue.filter { !it.fixed || allowLocked }
            .sortedWith(compareBy(
                { priorityRank(it.type) },   // الامتحانات/الواجبات أولًا، ثم الجديد، ثم التراكم والمراجعة
                { it.date },
                { it.startMin ?: 9999 }
            ))

        val warnings = mutableListOf<String>()
        if (locked.isNotEmpty())
            warnings += "${locked.size} من المهام المتأخرة لها موعد ثابت (محاضرة جديدة أو التزام) ولن تُنقل دون إذن صريح."

        val placements = mutableMapOf<String, TaskEntity>()   // taskId -> موضعه الجديد
        val unplaced = mutableListOf<AdaptiveUnplaced>()

        for (uiTask in movable) {
            val placed = placeOverdueTask(uiTask.task, allTasks, placements, today, horizonDays, settings, weekConstraints)
            if (placed != null) placements[uiTask.id] = placed
            else unplaced += AdaptiveUnplaced(
                uiTask,
                "لا يتسع أي يوم ضمن ${horizonDays} يومًا القادمة لهذه المهمة ضمن الحد اليومي والأيام المسموحة لمادتها."
            )
        }

        if (unplaced.isNotEmpty())
            warnings += "تعذّر جدولة ${unplaced.size} مهمة ضمن الفترة الحالية — جرّب تمديد عدد الأيام أو رفع الحد اليومي من الإعدادات."

        val moves = movable.filter { it.id in placements }.map { uiTask ->
            val p = placements.getValue(uiTask.id)
            AdaptiveMove(uiTask, p.date, p.startMin ?: 0, p.endMin ?: (p.startMin ?: 0) + p.durationMin)
        }

        val affected = (moves.map { it.toDate } + moves.map { it.task.date }).distinct().sorted()
        val dayLoads = affected.map { date ->
            val base = allTasks.filter { it.task.id !in placements.keys && it.date == date }.sumOf { it.durationMin }
            val movedIn = placements.values.filter { it.date == date }.sumOf { it.durationMin }
            AdaptiveDayLoad(date, base + movedIn, settings.dailyGoalMin)
        }

        if (overdue.isEmpty()) warnings += "لا توجد مهام متأخرة حاليًا — جدولك محدّث."

        return AdaptivePlan(
            today = today,
            overdueTotal = overdue.size,
            lockedCount = locked.size,
            moves = moves,
            unplaced = unplaced,
            dayLoads = dayLoads,
            warnings = warnings.distinct()
        )
    }

    private fun priorityRank(type: String): Int = when {
        TaskTypes.isAssessment(type) -> 0
        type == TaskTypes.HOMEWORK -> 1
        type == TaskTypes.NEW -> 2
        type == TaskTypes.REVIEW -> 3
        else -> 4
    }

    private fun placeOverdueTask(
        candidate: TaskEntity,
        allTasks: List<UiTask>,
        placements: Map<String, TaskEntity>,
        today: LocalDate,
        horizonDays: Int,
        settings: Settings,
        weekConstraints: WeekPlanSnapshot?
    ): TaskEntity? {
        // نرشّح الأيام المسموحة (ليست راحة، ومسموحة لهذه المادة/النوع)، ثم نجرّب الأقل حملًا أولًا لتحقيق التوازن.
        val targets = (0 until horizonDays).map { today.plusDays(it.toLong()) }
            .filter { d ->
                val dayName = ScheduleParser.weekday(d)
                weekConstraints == null || weekConstraints.isUsable(dayName, candidate.subject, candidate.type)
            }
            .sortedBy { d -> dayLoad(d.toString(), allTasks, placements) }

        for (target in targets) {
            val slot = findSlot(candidate, allTasks, placements, target, settings) ?: continue
            return candidate.copy(date = target.toString(), startMin = slot, endMin = slot + candidate.durationMin)
        }
        return null
    }

    private fun dayLoad(date: String, allTasks: List<UiTask>, placements: Map<String, TaskEntity>): Int {
        val base = allTasks.filter { it.task.id !in placements.keys && it.date == date }.sumOf { it.durationMin }
        val moved = placements.values.filter { it.date == date }.sumOf { it.durationMin }
        return base + moved
    }

    private fun findSlot(
        candidate: TaskEntity,
        allTasks: List<UiTask>,
        placements: Map<String, TaskEntity>,
        target: LocalDate,
        settings: Settings
    ): Int? {
        val date = target.toString()
        if (dayLoad(date, allTasks, placements) + candidate.durationMin > settings.dailyGoalMin) return null

        val busyTasks = allTasks.map { it.task }.filter {
            it.date == date && it.id != candidate.id && it.id !in placements.keys
        } + placements.values.filter { it.date == date && it.id != candidate.id }
        val busy = busyTasks.mapNotNull { t ->
            val s = t.startMin ?: return@mapNotNull null
            val e = t.endMin ?: s + t.durationMin
            s..e
        }

        val windows = mutableListOf<Pair<Int, Int>>()
        if (settings.schoolStart > settings.wakeMin + candidate.durationMin)
            windows += settings.wakeMin to settings.schoolStart
        if (settings.sleepMin > settings.schoolEnd + candidate.durationMin)
            windows += settings.schoolEnd to settings.sleepMin

        for ((from, to) in windows) {
            var cursor = from.coerceAtLeast(if (TaskTypes.isAssessment(candidate.type)) 19 * 60 else from)
            val limit = to.coerceAtMost(settings.sleepMin)
            while (cursor + candidate.durationMin <= limit) {
                val clash = busy.any { cursor < it.last + settings.breakMin && cursor + candidate.durationMin > it.first }
                if (!clash) return cursor
                cursor += 15
            }
        }
        return null
    }
}

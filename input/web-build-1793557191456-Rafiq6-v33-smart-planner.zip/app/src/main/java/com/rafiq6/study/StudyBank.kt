package com.rafiq6.study

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfReader
import com.itextpdf.kernel.pdf.canvas.parser.PdfTextExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.util.UUID

@Entity(tableName = "pdf_documents")
data class PdfDocumentEntity(
    @PrimaryKey val id: String,
    val uri: String,
    val displayName: String,
    val pageCount: Int,
    val textAvailable: Boolean,
    val importWarning: String? = null,
    val importedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "pdf_page_texts", primaryKeys = ["documentId", "pageNumber"])
data class PdfPageTextEntity(
    val documentId: String,
    val pageNumber: Int,
    val text: String
)

@Entity(tableName = "questions")
data class QuestionEntity(
    @PrimaryKey val id: String,
    val documentId: String,
    val documentName: String,
    val pageNumber: Int,
    val subject: String,
    val topic: String,
    val question: String,
    val correctAnswer: String? = null,
    val errorCount: Int = 0,
    val reviewStage: Int = 0,
    val nextReviewAt: String? = null,
    val lastResult: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "quiz_attempts")
data class QuizAttemptEntity(
    @PrimaryKey val id: String,
    val subject: String?,
    val topic: String?,
    val total: Int,
    val answered: Int = 0,
    val correct: Int = 0,
    val status: String = QuizStatus.ACTIVE,
    val startedAt: Long = System.currentTimeMillis(),
    val finishedAt: Long? = null
)

@Entity(tableName = "attempt_answers")
data class AttemptAnswerEntity(
    @PrimaryKey val id: String,
    val attemptId: String,
    val questionId: String,
    val userAnswer: String,
    val isCorrect: Boolean,
    val answeredAt: Long = System.currentTimeMillis(),
    val previousStage: Int,
    val nextStage: Int,
    val nextReviewAt: String?
)

object QuizStatus { const val ACTIVE = "ACTIVE"; const val DONE = "DONE" }

data class QuizSelection(val questions: List<QuestionEntity>, val message: String = "") {
    val hasQuestions: Boolean get() = questions.isNotEmpty()
}

object QuizSelector {
    fun select(questions: List<QuestionEntity>, subject: String?, topic: String?, limit: Int): QuizSelection {
        val filtered = questions.filter { q ->
            (subject.isNullOrBlank() || q.subject.trim() == subject.trim()) &&
            (topic.isNullOrBlank() || q.topic.trim() == topic.trim()) &&
            q.question.isNotBlank()
        }
        if (filtered.isEmpty()) return QuizSelection(emptyList(), "لا توجد أسئلة مطابقة. أضف أسئلة من بنك الأسئلة أولًا.")
        val today = LocalDate.now().toString()
        val dueOrError = filtered.filter { q -> (q.nextReviewAt != null && q.nextReviewAt <= today) || q.errorCount > 0 }
        val rest = filtered.filter { it !in dueOrError }
        return QuizSelection((dueOrError + rest).distinct().take(limit.coerceAtLeast(1)))
    }
}

object ReviewScheduler {
    /** فواصل برمجية قابلة للتعديل، وليست ادعاءً بأنها الأفضل علميًا لكل الطلاب. */
    val intervalsDays = listOf(1, 3, 7, 14, 30)
    const val MAX_STAGE = 5

    fun nextAfter(correct: Boolean, stage: Int, from: LocalDate = LocalDate.now()): Pair<Int, String?> {
        val base = stage.coerceIn(0, MAX_STAGE)
        return if (!correct) {
            val next = (base - 1).coerceAtLeast(0)
            next to from.plusDays(1).toString()
        } else {
            val next = base + 1
            if (next >= MAX_STAGE) next to null
            else next to from.plusDays(intervalsDays.getOrElse(next - 1) { 30 }.toLong()).toString()
        }
    }
}

data class MasteryBreakdown(
    val schedulePct: Int, val scheduleBase: Int,
    val quizPct: Int, val quizBase: Int,
    val retentionPct: Int, val retentionBase: Int
) {
    val enoughSchedule: Boolean get() = scheduleBase > 0
    val enoughQuiz: Boolean get() = quizBase > 0
    val enoughRetention: Boolean get() = retentionBase > 0
}

object MasteryCalculator {
    fun schedule(tasks: List<UiTask>): Pair<Int, Int> {
        val total = tasks.size
        val done = tasks.count { it.done }
        return (if (total == 0) 0 else 100 * done / total) to total
    }

    fun quiz(answers: List<AttemptAnswerEntity>): Pair<Int, Int> {
        val base = answers.size
        val correct = answers.count { it.isCorrect }
        return (if (base == 0) 0 else 100 * correct / base) to base
    }

    fun retention(answers: List<AttemptAnswerEntity>): Pair<Int, Int> {
        val reviewed = answers.filter { it.previousStage > 0 }
        val base = reviewed.size
        val correct = reviewed.count { it.isCorrect }
        return (if (base == 0) 0 else 100 * correct / base) to base
    }

    fun calculate(tasks: List<UiTask>, answers: List<AttemptAnswerEntity>): MasteryBreakdown {
        val s = schedule(tasks); val q = quiz(answers); val r = retention(answers)
        return MasteryBreakdown(s.first, s.second, q.first, q.second, r.first, r.second)
    }
}


object QuestionStateUpdater {
    fun applyResult(q: QuestionEntity, correct: Boolean, now: LocalDate = LocalDate.now(), timestamp: Long = System.currentTimeMillis()): QuestionEntity {
        val (nextStage, nextAt) = ReviewScheduler.nextAfter(correct, q.reviewStage, now)
        return q.copy(
            errorCount = if (correct) q.errorCount else q.errorCount + 1,
            reviewStage = nextStage,
            nextReviewAt = nextAt,
            lastResult = if (correct) "صحيح" else "خاطئ",
            updatedAt = timestamp
        )
    }
}


object QuizAttemptPolicy {
    fun duplicateMessage(answers: List<AttemptAnswerEntity>, questionId: String): String? =
        if (answers.any { it.questionId == questionId }) "هذا السؤال مسجل في المحاولة الحالية بالفعل." else null
}

object QuizAttemptReconstruction {
    fun remainingOrder(answeredQuestions: List<QuestionEntity>, allQuestions: List<QuestionEntity>): List<QuestionEntity> {
        val answeredIds = answeredQuestions.map { it.id }.toSet()
        return (answeredQuestions + allQuestions.filter { it.id !in answeredIds }).distinctBy { it.id }
    }
}

object QuizResultRecorder {
    data class UpdatedAttempt(val attempt: QuizAttemptEntity, val finished: Boolean)

    fun update(attempt: QuizAttemptEntity, correct: Boolean, now: Long = System.currentTimeMillis()): UpdatedAttempt {
        val answered = attempt.answered + 1
        val finished = answered >= attempt.total
        return UpdatedAttempt(
            attempt.copy(
                answered = answered,
                correct = attempt.correct + if (correct) 1 else 0,
                status = if (finished) QuizStatus.DONE else QuizStatus.ACTIVE,
                finishedAt = if (finished) now else attempt.finishedAt
            ),
            finished
        )
    }
}

object PdfValidator {
    fun isPdf(header: ByteArray): Boolean = header.size >= 5 && header[0] == '%'.code.toByte() &&
        header[1] == 'P'.code.toByte() && header[2] == 'D'.code.toByte() &&
        header[3] == 'F'.code.toByte() && header[4] == '-'.code.toByte()
}

data class PdfImportResult(
    val document: PdfDocumentEntity?,
    val pages: List<PdfPageTextEntity>,
    val error: String? = null,
    val warning: String? = null
)

object PdfImportService {
    const val MAX_FILE_BYTES = 50L * 1024L * 1024L
    const val MAX_PAGES = 500

    suspend fun import(ctx: Context, uri: Uri): PdfImportResult = withContext(Dispatchers.IO) {
        try {
            val (resolvedName, sizeBytes) = queryMetadata(ctx, uri)
            val displayName = resolvedName?.ifBlank { null } ?: uri.lastPathSegment?.substringAfterLast('/')
                ?: "ملف PDF"
            if (sizeBytes != null && sizeBytes > MAX_FILE_BYTES)
                return@withContext PdfImportResult(null, emptyList(), error = "حجم الملف أكبر من 50MB؛ تم رفض الاستيراد حفاظًا على الذاكرة.")

            ctx.contentResolver.openInputStream(uri)?.use { input ->
                val header = ByteArray(5); val read = input.read(header, 0, 5)
                if (read < 5 || !PdfValidator.isPdf(header))
                    return@withContext PdfImportResult(null, emptyList(), error = "الملف ليس PDF صالحًا. تم رفضه دون تعديل أي بيانات.")
            } ?: return@withContext PdfImportResult(null, emptyList(), error = "تعذر فتح الملف.")

            val id = UUID.randomUUID().toString()
            val pageTexts = mutableListOf<String>()
            var warning: String? = null
            var pageCount = 0
            try {
                PdfDocument(PdfReader(ctx.contentResolver.openInputStream(uri))).use { pdf ->
                    pageCount = pdf.numberOfPages
                    if (pageCount <= 0) throw IllegalArgumentException("الملف لا يحتوي صفحات.")
                    if (pageCount > MAX_PAGES) warning = "الملف يتجاوز $MAX_PAGES صفحة؛ تم استخراج نص أول $MAX_PAGES صفحة فقط."
                    for (page in 1..minOf(pageCount, MAX_PAGES)) {
                        val text = try { PdfTextExtractor.getTextFromPage(pdf.getPage(page)) ?: "" }
                        catch (e: Exception) { "" }
                        pageTexts += text.trim()
                    }
                }
            } catch (e: Exception) {
                return@withContext PdfImportResult(null, emptyList(), error = "تعذر قراءة ملف PDF. قد يكون تالفًا أو محميًا: ${e.message ?: "خطأ غير معروف"}")
            }

            val nonBlank = pageTexts.count { it.isNotBlank() }
            val textAvailable = pageTexts.any { looksReadable(it) }
            val garbled = pageTexts.count { it.isNotBlank() && !looksReadable(it) }
            val hasArabic = pageTexts.any { text -> text.any { it in '\u0600'..'\u06FF' } }
            if (!textAvailable) warning = (warning?.plus("\n") ?: "") + "لم يُعثر على نص مقروء؛ يمكن عرض الصفحات كصور وإدخال الأسئلة يدويًا."
            else if (garbled * 2 >= nonBlank.coerceAtLeast(1)) warning = (warning?.plus("\n") ?: "") + "يبدو أن النص المستخرج مشوّه؛ لم يُستخدم تلقائيًا."
            if (hasArabic) warning = (warning?.plus("\n") ?: "") + "يحتوي النص على محارف عربية؛ قد يقلب الاستخراج ترتيب بعض الكلمات، فراجع الصفحة الأصلية قبل الاعتماد عليه."
            val doc = PdfDocumentEntity(id, uri.toString(), displayName, pageCount, textAvailable, warning)
            val pages = pageTexts.mapIndexed { idx, text -> PdfPageTextEntity(id, idx + 1, text) }
            PdfImportResult(doc, pages, warning = warning)
        } catch (e: Exception) {
            PdfImportResult(null, emptyList(), error = "فشل الاستيراد بأمان: ${e.message ?: "خطأ غير معروف"}")
        }
    }

    private fun queryMetadata(ctx: Context, uri: Uri): Pair<String?, Long?> {
        var name: String? = null; var size: Long? = null
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val nameIndex = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = c.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = c.getString(nameIndex)
                if (sizeIndex >= 0 && !c.isNull(sizeIndex)) size = c.getLong(sizeIndex)
            }
        }
        return name to size
    }

    private fun looksReadable(text: String): Boolean {
        if (text.isBlank()) return false
        val letters = text.count { it.isLetter() }
        val controls = text.count { it.isISOControl() && it != '\n' && it != '\t' && it != '\r' }
        return letters >= 20 && controls * 20 <= text.length
    }
}

object PdfPageRenderer {
    private const val MAX_CACHE_BYTES = 150L * 1024L * 1024L

    suspend fun render(ctx: Context, uriString: String, pageNumber: Int): Bitmap = withContext(Dispatchers.IO) {
        val uri = Uri.parse(uriString)
        val cache = cacheFile(ctx, uriString, pageNumber)
        cache.parentFile?.mkdirs()
        if (cache.exists()) {
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(cache.absolutePath, bounds)
            if (bounds.outWidth in 1..1800 && bounds.outHeight in 1..2400) {
                val cached = android.graphics.BitmapFactory.decodeFile(cache.absolutePath)
                if (cached != null) return@withContext cached
            }
            cache.delete()
        }
        renderFresh(ctx, uri, pageNumber, cache).also { trimCache(cache.parentFile ?: return@withContext it) }
    }

    fun cacheFile(ctx: Context, uriString: String, pageNumber: Int): File =
        File(ctx.cacheDir, "pdf_pages/${uriString.hashCode()}/page-$pageNumber.png")

    fun clearCacheFor(ctx: Context, uriString: String) {
        File(ctx.cacheDir, "pdf_pages/${uriString.hashCode()}").deleteRecursively()
    }

    private fun renderFresh(ctx: Context, uri: Uri, pageNumber: Int, cache: File): Bitmap {
        val pfd: ParcelFileDescriptor = ctx.contentResolver.openFileDescriptor(uri, "r")
            ?: throw SecurityException("تعذر فتح ملف PDF الأصلي؛ ربما حُذف الملف أو أُلغيت صلاحية الوصول.")
        pfd.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                if (pageNumber < 1 || pageNumber > renderer.pageCount)
                    throw IllegalArgumentException("رقم الصفحة خارج نطاق الملف.")
                val page = renderer.openPage(pageNumber - 1)
                try {
                    if (page.width <= 0 || page.height <= 0) throw IllegalStateException("أبعاد الصفحة غير صالحة.")
                    val scale = minOf(2.0f, 1600f / page.width.toFloat(), 2200f / page.height.toFloat()).coerceAtLeast(0.1f)
                    val width = (page.width * scale).toInt().coerceAtLeast(1)
                    val height = (page.height * scale).toInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    try {
                        bitmap.eraseColor(android.graphics.Color.WHITE)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                        cache.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 90, it) }
                        return bitmap
                    } catch (e: Throwable) {
                        bitmap.recycle()
                        throw e
                    }
                } finally { page.close() }
            }
        }
    }

    private fun trimCache(dir: File) {
        val files = dir.listFiles()?.filter { it.isFile } ?: return
        var total = files.sumOf { it.length() }
        if (total <= MAX_CACHE_BYTES) return
        files.sortedBy { it.lastModified() }.forEach { f ->
            if (total <= MAX_CACHE_BYTES) return@forEach
            val len = f.length(); if (f.delete()) total -= len
        }
    }
}


data class OpenPdfRequest(val document: PdfDocumentEntity, val pageNumber: Int)
data class ActiveQuiz(val attempt: QuizAttemptEntity, val questions: List<QuestionEntity>)

object PdfPermissionHelper {
    fun retain(context: Context, uri: Uri): Boolean = try {
        context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        true
    } catch (e: Exception) {
        false
    }
}

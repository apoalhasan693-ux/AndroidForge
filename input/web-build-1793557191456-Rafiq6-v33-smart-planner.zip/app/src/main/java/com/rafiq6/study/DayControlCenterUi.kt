package com.rafiq6.study

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

/** مركز التحكم الذكي: نظرة أسبوعية + إدارة اليوم. يقرأ bundle الحقيقي نفسه فأي تغيير ينعكس فورًا. */
@Composable
fun DayControlCenterScreen(vm: MainVm, date: LocalDate, onPickDate: (LocalDate) -> Unit = {}) {
    val bundle by vm.bundle.collectAsState(initial = ScheduleBundle())
    val overrides by vm.dayOverridesMap.collectAsState()
    val plan by vm.pendingPlan.collectAsState()
    val undo by vm.undoAvailable.collectAsState()
    val caps by vm.caps.collectAsState()
    val weekPlan = remember(bundle.schedule?.weekPlanJson) { WeekPlanSnapshot.fromJson(bundle.schedule?.weekPlanJson) }
    val snap = remember(bundle, overrides, caps, date) { buildDaySnapshot(date, bundle.tasks, overrides, weekPlan, caps) }
    val weekStart = remember(date) { date.minusDays((date.dayOfWeek.value % 7).toLong()) } // الأحد بداية الأسبوع

    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("🧭 مركز التحكم الذكي", style = MaterialTheme.typography.headlineSmall) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items((0..6).toList()) { i ->
                        val d = weekStart.plusDays(i.toLong())
                        WeekDayCard(buildDaySnapshot(d, bundle.tasks, overrides, weekPlan, caps), d == date) { onPickDate(d) }
                    }
                }
            }
            item { HeaderCard(snap) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(DayKind.entries.toList()) { k ->
                        FilterChip(selected = k == snap.kind, onClick = { vm.setDayKind(date, k) }, label = { Text(k.label) })
                    }
                }
            }
            if (snap.newLectures.isNotEmpty()) item {
                TaskSection("المحاضرات الجديدة", snap.newLectures, false, { vm.markWatchedOutside(it) },
                    { vm.previewDefer(listOf(it.id), DeferMode.NEXT_DAY) })
            }
            if (snap.backlog.isNotEmpty()) item {
                TaskSection("التراكمات القديمة", snap.backlog, true, { vm.markWatchedOutside(it) },
                    { vm.previewDefer(listOf(it.id), DeferMode.NEAREST_FREE) })
            }
            if (snap.exams.isNotEmpty()) item { InfoSection("📝 الامتحانات", snap.exams) }
            if (snap.commitments.isNotEmpty()) item { InfoSection("الالتزامات", snap.commitments) }
            if (snap.others.isNotEmpty()) item { InfoSection("مراجعات ومهام مرنة", snap.others) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.previewEvacuate(date) }, modifier = Modifier.weight(1f)) { Text("إخلاء اليوم من التراكمات") }
                    OutlinedButton(onClick = { vm.scanMissed() }, modifier = Modifier.weight(1f)) { Text("فحص الفائتات") }
                }
            }
            if (undo) item { TextButton(onClick = { vm.undoOuting() }) { Text("↩ تراجع عن آخر إعادة جدولة") } }
        }
        plan?.let { PlanPreviewDialog(it, vm) }
    }
}

@Composable private fun HeaderCard(s: DaySnapshot) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("${s.dayName} — ${s.date}", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("نوع اليوم: ${s.kind.label}")
            LinearProgressIndicator(progress = { s.completionPct / 100f }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
            Text("الإنجاز: ${s.completionPct}% — الدراسة: ${s.usedMin} من ${s.capMin} د — المتبقي: ${s.remainingMin} د")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).background(Color(s.level.argb), RoundedCornerShape(6.dp)))
                Spacer(Modifier.width(6.dp))
                Text("ضغط اليوم: ${s.level.label}")
            }
        }
    }
}

@Composable private fun WeekDayCard(s: DaySnapshot, selected: Boolean, onClick: () -> Unit) {
    val kindColor = when (s.kind) {
        DayKind.REST_DAY -> 0xFF90A4AE; DayKind.EXAM_DAY -> 0xFFE53935; DayKind.BUSY_DAY -> 0xFF8E24AA
        DayKind.LIGHT_DAY -> 0xFF43A047; DayKind.BACKLOG_FREE_DAY -> 0xFF4FC3F7; DayKind.NORMAL_DAY -> 0xFF607D8B
    }
    Card(onClick = onClick, modifier = Modifier.width(130.dp),
        colors = if (selected) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer) else CardDefaults.cardColors()) {
        Column(Modifier.padding(8.dp)) {
            Text("${s.dayName}\n${s.date}", fontSize = 12.sp)
            Box(Modifier.fillMaxWidth().height(4.dp).background(Color(kindColor), RoundedCornerShape(2.dp)))
            Spacer(Modifier.height(4.dp))
            Chip("جديد", s.newLectures.size, 0xFF2E6FB7)
            Chip("تراكمات", s.backlog.size, 0xFFF4842B)
            Chip("امتحانات", s.exams.size, 0xFFE53935)
            Chip("مراجعة/مرنة", s.others.size, 0xFF7E57C2)
            Chip("التزامات", s.commitments.size, 0xFF795548)
            Text("${s.usedMin}/${s.capMin} د — ${s.level.label}", fontSize = 11.sp)
            Text("الإنجاز ${s.completionPct}%", fontSize = 11.sp)
        }
    }
}

@Composable private fun Chip(label: String, count: Int, color: Long) {
    if (count <= 0) return
    Row(Modifier.padding(vertical = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(Color(color), RoundedCornerShape(4.dp)))
        Spacer(Modifier.width(4.dp))
        Text("$label: $count", fontSize = 11.sp)
    }
}

@Composable private fun TaskSection(
    title: String, tasks: List<UiTask>, showOriginal: Boolean,
    onDone: (UiTask) -> Unit, onMissed: (UiTask) -> Unit
) {
    val nowMin = Subjects.now().let { it.hour * 60 + it.minute }
    val today = Subjects.now().toLocalDate()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            tasks.forEach { t ->
                val st = when (SmartStatus.of(t.task, t.done, today, nowMin)) {
                    TaskStatus.COMPLETED -> "مكتملة"; TaskStatus.MISSED -> "فائتة"
                    TaskStatus.DEFERRED -> "مؤجلة"; TaskStatus.PENDING -> "قيد الانتظار"
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${t.subject} — ${t.title}" + (t.lectureNo?.let { " (محاضرة $it)" } ?: ""))
                        Text("${t.durationMin} د — $st" +
                            (if (showOriginal && t.originalDate != null) " — الأصلي: ${t.originalDate}" else "") +
                            (t.startMin?.let { " — ${Subjects.fmt12(it)}" } ?: ""), fontSize = 12.sp)
                    }
                    TextButton(onClick = { onDone(t) }, enabled = !t.done) { Text("شاهدتها") }
                    TextButton(onClick = { onMissed(t) }, enabled = !t.done) { Text("أجّل") }
                }
            }
        }
    }
}

@Composable private fun InfoSection(title: String, tasks: List<UiTask>) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            tasks.forEach { t ->
                Text("${t.subject} — ${t.title}" + (t.startMin?.let { " — ${Subjects.fmt12(it)}" } ?: "") +
                    (t.note?.let { " — $it" } ?: ""), fontSize = 13.sp)
            }
        }
    }
}

@Composable private fun PlanPreviewDialog(plan: SmartPlan, vm: MainVm) {
    val bundle by vm.bundle.collectAsState(initial = ScheduleBundle())
    val titles = remember(bundle) { bundle.tasks.associate { it.id to "${it.subject} — ${it.title}" } }
    AlertDialog(
        onDismissRequest = { vm.discardPlan() },
        title = { Text(plan.reason) },
        text = {
            LazyColumn {
                item { Text(if (plan.moves.isEmpty()) "لا توجد مهام تحتاج نقلًا." else "ستنتقل ${plan.movedTasks} مهمة (${plan.totalMovedMin} دقيقة):") }
                items(plan.moves.take(20)) { m ->
                    Text("• ${titles[m.taskId] ?: m.taskId}: ${m.fromDate} ← ${m.toDate} (${m.toDayName})", fontSize = 13.sp)
                }
                if (plan.moves.size > 20) item { Text("… و${plan.moves.size - 20} أخرى") }
                if (plan.addedMinByDate.isNotEmpty()) {
                    item { Text("الحمل المضاف:", fontWeight = FontWeight.Bold) }
                    items(plan.addedMinByDate.toList().sortedBy { it.first }) { (d, min) -> Text("  $d: +$min د", fontSize = 12.sp) }
                }
                if (plan.violations.isNotEmpty()) {
                    item { Text("تحذيرات:", color = MaterialTheme.colorScheme.error) }
                    items(plan.violations) { Text("⚠ $it", fontSize = 12.sp) }
                }
            }
        },
        confirmButton = { Button(onClick = { vm.applySmartPlan() }, enabled = plan.moves.isNotEmpty()) { Text("تطبيق") } },
        dismissButton = { TextButton(onClick = { vm.discardPlan() }) { Text("إلغاء") } }
    )
}

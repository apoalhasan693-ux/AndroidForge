package com.rafiq6.study

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONObject

// ===== تخزين المسودة =====

val Context.wizardDs by preferencesDataStore("rafiq6_wizard")
private val DRAFT_KEY = stringPreferencesKey("draft_v2")

suspend fun saveWizardDraft(c: Context, d: WizardDraft) {
    c.wizardDs.edit { it[DRAFT_KEY] = WizardDraftCodec.toJson(d).toString() }
}
suspend fun loadWizardDraft(c: Context): WizardDraft? {
    val raw = c.wizardDs.data.first()[DRAFT_KEY] ?: return null
    return try { WizardDraftCodec.fromJson(JSONObject(raw)) } catch (e: Exception) { null }
}
suspend fun clearWizardDraft(c: Context) { c.wizardDs.edit { it.remove(DRAFT_KEY) } }

// ===== الشاشة الرئيسية =====

@Composable fun ScheduleBuilderHubScreen(vm: MainVm) {
    var stage by remember { mutableStateOf("intro") }
    var draft by remember { mutableStateOf(WizardDraft()) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var loaded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (!loaded) { loaded = true; loadWizardDraft(ctx)?.let { draft = it } }
    }
    val commit: (WizardDraft) -> Unit = { d -> draft = d; scope.launch { saveWizardDraft(ctx, d) }; Unit }

    when (stage) {
        "intro" -> WizardIntro(
            hasDraft = draft.subjects.isNotEmpty() || draft.backlogs.isNotEmpty(),
            onNew = { commit(WizardDraft(mode = "new")); stage = "wizard" },
            onReplan = { commit(draft.copy(mode = "replan")); stage = "wizard" })
        "wizard" -> ScheduleWizardFlow(
            vm = vm, draft = draft, onCommit = commit,
            onCancel = { stage = "intro" },
            onDone = { stage = "prompt" })
        "prompt" -> WizardPromptScreen(
            vm = vm, draft = draft,
            onBack = { stage = "wizard" },
            onGoImport = { stage = "import" },
            onGoLocal = { stage = "local" })
        "local" -> WizardLocalGenScreen(
            vm = vm, draft = draft,
            onEdit = { stage = "wizard" },
            onBack = { stage = "prompt" },
            onCancel = { stage = "intro" })
        "import" -> WizardImportScreen(
            vm = vm, draft = draft,
            onBack = { stage = "prompt" },
            onCancel = { stage = "intro" })
    }
}

@Composable private fun WizardIntro(hasDraft: Boolean, onNew: () -> Unit, onReplan: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("📅 إنشاء / تغيير الجدول السنوي", style = MaterialTheme.typography.headlineSmall)
        Text("أجب عن أسئلة قليلة ومركزة — اختيار المواد، أعداد التراكمات، وتوزيع المواد على أيام الأسبوع — ثم ننشئ برومبتًا ترسله لأي أداة ذكاء اصطناعي، وتستورد ملف الجدول الناتج بعد فحصه ومعاينته. جدولك الحالي لا يتغير قبل أن تعتمد أنت الجديد، وتستطيع استعادته في أي وقت.")
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("١) إنشاء جدول سنوي جديد", style = MaterialTheme.typography.titleMedium)
            Text("يبدأ بمسودة فارغة: موادك، تراكماتك، وأيامك.")
            Button(onClick = onNew, modifier = Modifier.fillMaxWidth()) { Text("ابدأ جدولًا جديدًا") }
        } }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("٢) تعديل / إعادة تنظيم الجدول الحالي", style = MaterialTheme.typography.titleMedium)
            Text("عندما تتغير الظروف: تراكمات جديدة، تأخر أيام، تغيّر النوم أو الدوام. يبقى إنجازك محفوظًا.")
            OutlinedButton(onClick = onReplan, modifier = Modifier.fillMaxWidth()) { Text("أعد تنظيم جدولي") }
        } }
        if (hasDraft) Text("توجد مسودة محفوظة — اختر أحد الخيارين لتعديلها أو البدء من جديد.", style = MaterialTheme.typography.bodySmall)
    }
}

// ===== المعالج =====

private val WIZARD_STEPS = listOf("المواد", "التراكمات", "توزيع الأسبوع", "الوقت والفترة", "الملخص")

@Composable fun ScheduleWizardFlow(
    vm: MainVm, draft: WizardDraft, onCommit: (WizardDraft) -> Unit,
    onCancel: () -> Unit, onDone: () -> Unit
) {
    var step by remember { mutableStateOf(0) }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { if (step == 0) onCancel() else step-- }) { Text(if (step == 0) "إلغاء" else "‹ السابق") }
            Text("الخطوة ${step + 1} من ${WIZARD_STEPS.size}: ${WIZARD_STEPS[step]}", style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            TextButton(onClick = onDone, enabled = step == WIZARD_STEPS.size - 1) { Text("التالي ›") }
        }
        LinearProgressIndicator(progress = { (step + 1).toFloat() / WIZARD_STEPS.size }, modifier = Modifier.fillMaxWidth())

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (step) {
                0 -> SubjectsStep(draft, onCommit)
                1 -> BacklogsStep(draft, onCommit)
                2 -> WeekPlanStep(draft, onCommit)
                3 -> TimeSettingsStep(draft, onCommit)
                4 -> SummaryStep(draft, onEdit = { step = it })
            }
        }

        if (step < WIZARD_STEPS.size - 1) {
            val problems = stepProblems(draft, step)
            Button(onClick = { if (problems.isEmpty()) step++ },
                enabled = problems.isEmpty(), modifier = Modifier.fillMaxWidth()) {
                Text("التالي: ${WIZARD_STEPS[step + 1]} ›")
            }
            problems.firstOrNull()?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        } else {
            val problems = draft.readyForSummary()
            Button(onClick = onDone, enabled = problems.isEmpty(), modifier = Modifier.fillMaxWidth()) { Text("إنشاء البرومبت ✨") }
            problems.firstOrNull()?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

private fun stepProblems(d: WizardDraft, step: Int): List<String> = when (step) {
    0 -> if (d.subjects.isEmpty()) listOf("اختر مادة واحدة على الأقل للمتابعة.") else emptyList()
    1 -> d.missingBacklogs().map { "حدد عدد تراكم «$it» أو أكّد أنها صفر." } +
        d.subjects.filter { (d.backlogs[it] ?: 0) > 0 && (d.firstOldNo[it] ?: 0) < 1 }
            .map { "أدخل رقم أول محاضرة قديمة متبقية في «$it»." }
    2 -> if (d.weekPlan.isEmpty() || d.weekPlan.values.all { it.isEmpty() })
        listOf("وزّع مادة واحدة على الأقل على أيام الأسبوع.")
    else d.subjects.filter { (d.backlogs[it] ?: 0) > 0 && d.usableDays(it).isEmpty() }
        .map { "«$it» لها تراكم لكن لا يوم دراسة لها — اختر لها يومًا واحدًا على الأقل (لن نختار عنك)." }
    3 -> listOfNotNull(d.validateDates())
    else -> emptyList()
}

// ===== الخطوة 1: اختيار المواد =====

@Composable private fun SubjectsStep(d: WizardDraft, onCommit: (WizardDraft) -> Unit) {
    var custom by remember { mutableStateOf("") }
    Text("شنو المواد اللي تدرسها؟", style = MaterialTheme.typography.titleMedium)
    Text("اختر من المواد المعروفة أو أضف مادة خاصة بك.", style = MaterialTheme.typography.bodySmall)

    WizardConst.DEFAULT_SUBJECTS.forEach { s ->
        val checked = s in d.subjects
        Card(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = checked, onCheckedChange = {
                    onCommit(if (checked) WeekOps.removeSubject(d, s) else WeekOps.addSubject(d, s))
                })
                Text(s, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
    val customs = d.subjects.filter { it !in WizardConst.DEFAULT_SUBJECTS }
    if (customs.isNotEmpty()) {
        Text("مواد مخصصة:", style = MaterialTheme.typography.titleSmall)
        customs.forEach { s ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = true, onCheckedChange = { onCommit(WeekOps.removeSubject(d, s)) })
                    Text(s, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                    TextButton(onClick = { onCommit(WeekOps.removeSubject(d, s)) }) { Text("حذف") }
                }
            }
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(value = custom, onValueChange = { custom = it }, modifier = Modifier.weight(1f),
            label = { Text("مادة مخصصة (مثال: الفرنسي)") })
        Button(onClick = {
            if (custom.isNotBlank() && custom.trim() !in d.subjects) {
                onCommit(WeekOps.addSubject(d, custom)); custom = ""
            }
        }, enabled = custom.isNotBlank()) { Text("إضافة") }
    }
    if (d.subjects.isNotEmpty()) Text("المختارة (${d.subjects.size}): ${d.subjects.joinToString("، ")}", style = MaterialTheme.typography.bodySmall)
}

// ===== الخطوة 2: التراكمات =====

@Composable private fun BacklogsStep(d: WizardDraft, onCommit: (WizardDraft) -> Unit) {
    // نصوص الحقول المحلية: فارغ = غير مؤكد بعد
    var texts by remember(d.subjects) {
        mutableStateOf(d.subjects.associateWith { s -> d.backlogs[s]?.toString() ?: "" })
    }
    fun commitAll(t: Map<String, String>) {
        texts = t
        onCommit(d.copy(backlogs = d.subjects.mapNotNull { s ->
            t[s]?.toIntOrNull()?.let { s to it }
        }.toMap()))
    }
    var nos by remember(d.subjects) {
        mutableStateOf(d.subjects.associateWith { s -> d.firstOldNo[s]?.toString() ?: "" })
    }
    fun commitNos(t: Map<String, String>) {
        nos = t
        onCommit(d.copy(firstOldNo = d.subjects.mapNotNull { s ->
            t[s]?.toIntOrNull()?.takeIf { it >= 1 }?.let { s to it }
        }.toMap()))
    }
    Text("كم محاضرة متراكمة عندك بكل مادة؟", style = MaterialTheme.typography.titleMedium)
    Text("اترك الحقل فارغًا إذا لم تحسم العدد بعد — لن نعتبره صفرًا.", style = MaterialTheme.typography.bodySmall)

    d.subjects.forEach { s ->
        val txt = texts[s] ?: ""
        val noBacklog = d.backlogs[s] == 0 && txt == "0"
        Card(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(s, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = txt, onValueChange = { v ->
                        val digits = v.filter { it.isDigit() }.take(4)
                        commitAll(texts + (s to digits))
                    },
                    modifier = Modifier.padding(vertical = 8.dp), enabled = !noBacklog,
                    label = { Text("عدد") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = noBacklog, onCheckedChange = { on ->
                        if (on) commitAll(texts + (s to "0"))
                        else commitAll(texts + (s to ""))
                    })
                    Text("ما عندي تراكم", style = MaterialTheme.typography.bodySmall)
                }
            }
            if (d.backlogs.containsKey(s)) Text("الحالية: ${d.backlogs[s]} محاضرة", Modifier.padding(start = 12.dp, bottom = 8.dp), style = MaterialTheme.typography.bodySmall)
            if ((d.backlogs[s] ?: 0) > 0) {
                OutlinedTextField(
                    value = nos[s] ?: "",
                    onValueChange = { v -> commitNos(nos + (s to v.filter { c -> c.isDigit() }.take(4))) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    label = { Text("رقم أول محاضرة قديمة متبقية في $s") })
                Text("تُرقَّم المحاضرات القديمة تسلسليًا من هذا الرقم. لا يُخمَّن الرقم.",
                    Modifier.padding(start = 12.dp, bottom = 8.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    Card(Modifier.fillMaxWidth()) {
        Text("مجموع التراكمات: ${d.totalBacklog()} محاضرة (محسوب من الحقول الحالية)",
            Modifier.padding(12.dp), style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary)
    }
    d.missingBacklogs().takeIf { it.isNotEmpty() }?.let {
        Text("لم تُحدد بعد: ${it.joinToString("، ")}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    }
}

// ===== الخطوة 3: توزيع الأسبوع =====

@Composable private fun WeekPlanStep(d: WizardDraft, onCommit: (WizardDraft) -> Unit) {
    var copyFrom by remember { mutableStateOf<String?>(null) }
    val targets = remember { mutableStateOf(setOf<String>()) }
    var examEdit by remember { mutableStateOf<ExamEntry?>(null) }
    // تقدير من نفس مُخصص الجدول (يتطلب تاريخي الفترة من الخطوة التالية)
    // الفترة تُدخل في الخطوة التالية: بدونها نقدّر من أسبوع نموذجي حتى يرى الطالب الأثر الآن
    val estimated = d.startDate.isBlank() || d.endDate.isBlank()
    val estD = if (estimated) d.copy(startDate = "2026-01-03", endDate = "2026-01-09") else d
    val rep = remember(estD) { PlanAllocator.allocate(estD) }
    val perDay = remember(rep) {
        rep?.days?.filter { !it.isRest }?.groupBy { it.dayName }
            ?.mapValues { (_, l) -> l.sumOf { it.newMin + it.examMin + it.oldMin } / l.size }
    }
    Text("وزّع موادك على أيام الأسبوع", style = MaterialTheme.typography.titleMedium)
    Text("اختيار مادة يومًا معينًا يعني: لها محاضرة جديدة (واختبارات) في هذا اليوم، فتُحجز أولًا. التراكم القديم يُوزَّع تلقائيًا بالتساوي على كل أيام الدراسة دون تجاوز حدك اليومي.", style = MaterialTheme.typography.bodySmall)

    WizardConst.DAYS.forEach { day ->
        val rest = day in d.restDays
        val selected = d.weekPlan[day] ?: emptySet()
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(day, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                    Text("يوم راحة", style = MaterialTheme.typography.bodySmall)
                    Switch(checked = rest, onCheckedChange = { onCommit(WeekOps.setRest(d, day, it)) })
                }
                if (rest) Text("يوم راحة — لا يمكن إضافة مواد إليه. ألغِ حالة الراحة أولًا لتعديله.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                else {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        d.subjects.forEach { s ->
                            FilterChip(selected = s in selected, onClick = { onCommit(WeekOps.toggle(d, day, s)) }, label = { Text(s) })
                        }
                    }
                    perDay?.get(day)?.let { m ->
                        Text("الدراسة المتوقعة: ${m / 60}س ${m % 60}د من حد ${d.dailyStudyMin / 60}س ${d.dailyStudyMin % 60}د",
                            style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = {
                        examEdit = ExamEntry(day = day, kind = "daily", subjects = emptyList())
                    }) { Text("＋ إضافة اختبار لهذا اليوم") }
                    d.examsOf(day).forEach { e ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("📝 ${if (e.kind == "daily") "يومي" else "تراكمي"}: ${e.subjects.joinToString("، ")}" +
                                    (e.time.takeIf { it.isNotBlank() }?.let { " · $it" } ?: "") +
                                    (e.durationMin?.let { " · $it د" } ?: " · بدون مدة"),
                                    Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                TextButton(onClick = { examEdit = e }) { Text("تعديل") }
                                TextButton(onClick = { onCommit(d.copy(exams = d.exams - e)) }) { Text("حذف") }
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { onCommit(WeekOps.setAll(d, day)) }) { Text("تحديد الكل") }
                        TextButton(onClick = { onCommit(WeekOps.clearDay(d, day)) }) { Text("إلغاء الكل") }
                        TextButton(onClick = { targets.value = emptySet(); copyFrom = day }) { Text("نسخ إلى يوم آخر") }
                    }
                }
            }
        }
    }

    // ملخص أسبوعي: الأيام لكل مادة
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("الملخص الأسبوعي — الأيام المختارة لكل مادة:", style = MaterialTheme.typography.titleSmall)
            d.subjects.forEach { s ->
                val days = d.daysFor(s)
                Text("• $s: ${if (days.isEmpty()) "غير موزعة ⚠" else days.joinToString("، ")}",
                    color = if (days.isEmpty()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("التوزيع الذكي وتمديد الجدول", style = MaterialTheme.typography.titleSmall)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = d.autoExtend, onCheckedChange = { onCommit(d.copy(autoExtend = it)) })
                Text(if (d.autoExtend) "تمديد الجدول تلقائيًا إذا لم تكفِ الفترة" else "بدون تمديد: ما لا يتسع في الفترة يُعرض كعجز",
                    style = MaterialTheme.typography.bodySmall)
            }
            Text("أيام الجديد وأيام الراحة والحد اليومي تبقى كما اخترتها حتى في الأسابيع الممدّدة.",
                style = MaterialTheme.typography.bodySmall)
            if (rep == null) Text("تعذّر حساب التقدير — راجع المدخلات.", style = MaterialTheme.typography.bodySmall)
            else {
                if (estimated) Text("تقدير تقريبي من أسبوع نموذجي؛ يُضبط بدقة بعد تحديد الفترة في الخطوة التالية.", style = MaterialTheme.typography.bodySmall)
                if (rep.extendedDays > 0 && !rep.extensionBlocked)
                    Text(if (estimated) "التراكم يحتاج تقريبًا ${(7 + rep.extendedDays + 6) / 7} أسبوعًا حسب أيامك وحدك اليومي."
                         else "سيمتد الجدول ≈ ${rep.extendedWeeks} أسبوعًا (${rep.extendedDays} يومًا) حتى ${rep.effectiveEnd} لإكمال التراكم.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                if (rep.extensionBlocked)
                    Text("⚠ " + PlanAllocator.BLOCKED_MSG, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                else if (rep.totalOldLeftover > 0)
                    Text("⚠ يتبقى ${rep.totalOldLeftover} محاضرة قديمة بلا تمديد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                else if (rep.extendedDays == 0 && d.backlogs.isNotEmpty())
                    Text("✅ تكفي الفترة الحالية لإكمال التراكم.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    copyFrom?.let { from ->
        AlertDialog(onDismissRequest = { copyFrom = null },
            title = { Text("نسخ توزيع يوم $from إلى…") },
            text = { Column { WizardConst.DAYS.filter { it != from }.forEach { t ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = t in targets.value, onCheckedChange = { on ->
                        targets.value = if (on) targets.value + t else targets.value - t })
                    Text(t)
                } } } },
            confirmButton = { TextButton(onClick = {
                onCommit(WeekOps.copyDay(d, from, targets.value)); copyFrom = null
            }) { Text("نسخ") } },
            dismissButton = { TextButton(onClick = { copyFrom = null }) { Text("إلغاء") } })
    }

    examEdit?.let { e0 ->
        var e by remember { mutableStateOf(e0) }
        AlertDialog(onDismissRequest = { examEdit = null },
            title = { Text("اختبار يوم ${e.day}") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = e.kind == "daily", onClick = { e = e.copy(kind = "daily") }, label = { Text("يومي") })
                    FilterChip(selected = e.kind == "cumulative", onClick = { e = e.copy(kind = "cumulative") }, label = { Text("تراكمي") })
                }
                Text("المواد (يمكن اختيار أكثر من واحدة):", style = MaterialTheme.typography.bodySmall)
                d.subjects.forEach { s2 ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = s2 in e.subjects, onCheckedChange = { on ->
                            e = e.copy(subjects = if (on) e.subjects + s2 else e.subjects - s2)
                        })
                        Text(s2)
                    }
                }
                OutlinedTextField(value = e.title, onValueChange = { e = e.copy(title = it) }, label = { Text("عنوان اختياري") })
                OutlinedTextField(value = e.time, onValueChange = { v -> e = e.copy(time = v.filter { c -> c.isDigit() || c == ':' }.take(5)) },
                    label = { Text("الوقت HH:MM (اختياري)") })
                OutlinedTextField(
                    value = e.durationMin?.toString() ?: "",
                    onValueChange = { v -> e = e.copy(durationMin = v.filter { it.isDigit() }.take(3).toIntOrNull()) },
                    label = { Text("المدة بالدقائق (اختياري — اتركها فارغة إن لم تُحدد)") })
                OutlinedTextField(value = e.notes, onValueChange = { e = e.copy(notes = it) }, label = { Text("ملاحظات (اختياري)") })
            } },
            confirmButton = { TextButton(onClick = {
                if (e.subjects.isNotEmpty()) {
                    onCommit(d.copy(exams = d.exams - e0 + e)); examEdit = null
                }
            }, enabled = e.subjects.isNotEmpty()) { Text("حفظ") } },
            dismissButton = { TextButton(onClick = { examEdit = null }) { Text("إلغاء") } })
    }
}

// ===== الخطوة 4: الوقت والفترة =====

@Composable private fun TimeSettingsStep(d: WizardDraft, onCommit: (WizardDraft) -> Unit) {
    var newText by remember { mutableStateOf(d.newWeekly.mapValues { it.value.toString() }) }
    var newNos by remember { mutableStateOf(d.firstNewNo.mapValues { it.value.toString() }) }
    Text("الوقت والفترة", style = MaterialTheme.typography.titleMedium)

    OutlinedTextField(value = d.startDate, onValueChange = { onCommit(d.copy(startDate = it.filter { c -> c.isDigit() || c == '-' }.take(10))) },
        modifier = Modifier.fillMaxWidth(), label = { Text("تاريخ بداية الجدول YYYY-MM-DD") })
    OutlinedTextField(value = d.endDate, onValueChange = { onCommit(d.copy(endDate = it.filter { c -> c.isDigit() || c == '-' }.take(10))) },
        modifier = Modifier.fillMaxWidth(), label = { Text("تاريخ نهاية الجدول YYYY-MM-DD") })
    d.daysCount()?.let { Text("مدة الجدول: $it يومًا تقريبًا", style = MaterialTheme.typography.bodySmall) }
    d.validateDates()?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("ساعات الدراسة المتاحة يوميًا: ${d.dailyStudyMin / 60}")
        Slider(value = d.dailyStudyMin.toFloat(), onValueChange = { onCommit(d.copy(dailyStudyMin = it.toInt())) },
            valueRange = 60f..840f, modifier = Modifier.fillMaxWidth())
    }

    Text("أيام الدوام المدرسي (اختياري):", style = MaterialTheme.typography.titleSmall)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        WizardConst.DAYS.forEach { day ->
            FilterChip(selected = day in d.schoolDays, onClick = {
                onCommit(d.copy(schoolDays = if (day in d.schoolDays) d.schoolDays - day else d.schoolDays + day))
            }, label = { Text(day) })
        }
    }

    Text("ماذا يشمل الجدول؟", style = MaterialTheme.typography.titleSmall)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(checked = !d.oldOnly, onCheckedChange = { on -> onCommit(d.copy(oldOnly = !on)) })
        Text(if (d.oldOnly) "التراكمات فقط" else "التراكمات + المحاضرات الجديدة")
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("مدة المحاضرة الواحدة: ${d.lectureDur} دقيقة")
        Slider(value = d.lectureDur.toFloat(), onValueChange = { onCommit(d.copy(lectureDur = it.toInt())) },
            valueRange = 20f..120f, modifier = Modifier.fillMaxWidth())
    }
    Text("مدة مخصصة لمادة (اختياري — الفارغ = المدة العامة):", style = MaterialTheme.typography.bodySmall)
    d.subjects.forEach { s ->
        OutlinedTextField(
            value = d.lectureDurBy[s]?.toString() ?: "",
            onValueChange = { v ->
                val n = v.filter { it.isDigit() }.take(3).toIntOrNull()
                onCommit(d.copy(lectureDurBy = if (n == null || n <= 0) d.lectureDurBy - s else d.lectureDurBy + (s to n)))
            },
            label = { Text("$s — دقيقة (الحالية ${d.durOf(s)})") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
    }

    if (!d.oldOnly) {
        Text("أيام نشر المحاضرات الجديدة لكل مادة:", style = MaterialTheme.typography.titleSmall)
        Text("اختياري: إن تركت مادة فارغة تُستخدم أيامها من الخطوة 3 كأيام للمحاضرات الجديدة.", style = MaterialTheme.typography.bodySmall)
        d.subjects.forEach { s ->
            val pub = d.newLectureDays[s] ?: emptySet()
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(s, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    if (pub.isNotEmpty()) TextButton(onClick = {
                        onCommit(d.copy(newLectureDays = d.newLectureDays + (s to emptySet())))
                    }) { Text("مسح الأيام") }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    WizardConst.DAYS.forEach { day ->
                        FilterChip(selected = day in pub, onClick = {
                            val next = if (day in pub) pub - day else pub + day
                            onCommit(d.copy(newLectureDays = d.newLectureDays + (s to next)))
                        }, label = { Text(day) })
                    }
                }
                if (pub.isNotEmpty()) {
                    val t = d.newLectureTime[s] ?: ""
                    OutlinedTextField(
                        value = t,
                        onValueChange = { v ->
                            val clean = v.filter { c -> c.isDigit() || c == ':' }.take(5)
                            onCommit(d.copy(newLectureTime =
                                if (clean.isBlank()) d.newLectureTime - s
                                else d.newLectureTime + (s to clean)))
                        },
                        label = { Text("وقت نشر المحاضرة HH:MM (اختياري — اتركه فارغًا إن لم يُحدد)") })
                    OutlinedTextField(
                        value = newNos[s] ?: "",
                        onValueChange = { v ->
                            val digits = v.filter { c -> c.isDigit() }.take(4)
                            newNos = newNos + (s to digits)
                            onCommit(d.copy(firstNewNo = d.subjects.mapNotNull { s2 ->
                                newNos[s2]?.toIntOrNull()?.takeIf { it >= 1 }?.let { s2 to it }
                            }.toMap()))
                        },
                        label = { Text("رقم أول محاضرة جديدة قادمة (اختياري — بدونه تُنشأ بلا رقم)") })
                    Text("وقت المحاضرة يُضاف للجدول والتنبيهات عند اعتماده.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Text("عدد المحاضرات الجديدة المتوقعة أسبوعيًا (اختياري):", style = MaterialTheme.typography.bodySmall)
        d.subjects.forEach { s ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(s, Modifier.weight(1f))
                OutlinedTextField(value = newText[s] ?: "", onValueChange = { v ->
                    val digits = v.filter { it.isDigit() }.take(2)
                    newText = newText + (s to digits)
                    onCommit(d.copy(newWeekly = d.subjects.mapNotNull { s2 ->
                        newText[s2]?.toIntOrNull()?.let { s2 to it }
                    }.toMap()))
                }, modifier = Modifier.padding(vertical = 4.dp), label = { Text("عدد/أسبوع") })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("هل لديك جدول محاضرات جديدة جاهز؟")
            FilterChip(selected = d.hasNewScheduleReady, onClick = { onCommit(d.copy(hasNewScheduleReady = true)) }, label = { Text("نعم") })
            FilterChip(selected = !d.hasNewScheduleReady, onClick = { onCommit(d.copy(hasNewScheduleReady = false)) }, label = { Text("لا") })
        }
    }
}

// ===== الخطوة 5: الملخص =====

@Composable private fun SummaryStep(d: WizardDraft, onEdit: (Int) -> Unit) {
    Text("مراجعة مسودتك قبل إنشاء البرومبت", style = MaterialTheme.typography.titleMedium)
    @Composable fun section(title: String, body: String, step: Int) = Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                TextButton(onClick = { onEdit(step) }) { Text("تعديل") }
            }
            Text(body, style = MaterialTheme.typography.bodySmall)
        }
    }
    section("المواد (${d.subjects.size})", d.subjects.joinToString("، ").ifBlank { "—" }, 0)
    section("التراكمات — المجموع ${d.totalBacklog()}",
        d.subjects.joinToString("\n") { "• $it: ${d.backlogs[it] ?: "غير محدد"} محاضرة" }, 1)
    section("توزيع الأسبوع",
        d.subjects.joinToString("\n") { "• $it: ${d.daysFor(it).joinToString("، ").ifBlank { "غير موزعة ⚠" }}" } +
            (if (d.restDays.isNotEmpty()) "\nأيام الراحة: ${d.restDays.joinToString("، ")}" else ""), 2)
    if (d.newLectureTime.isNotEmpty()) section("أوقات المحاضرات",
        d.newLectureTime.entries.joinToString("\n") { "• ${it.key}: الساعة ${it.value}" }, 3)
    PlanAllocator.allocate(d)?.let { r ->
        section("الحسابات (وقت متاح ${r.totalStudyMin / 60}س · جديد محمي ${r.totalNewMin}د · قديم موزع ${r.totalOldFittedMin}د/${r.totalOldNeededMin}د)",
            r.subjects.joinToString("\n") { sa -> "• ${sa.subject}: قديم ${sa.oldCount} · جديد ${sa.expectedNew}" +
                if (sa.oldLeftover > 0) " · ⚠ يتبقى ${sa.oldLeftover}" else "" } +
                "\n" + r.notes.joinToString("\n"), 3)
    }
    if (d.exams.isNotEmpty()) section("الاختبارات (${d.exams.size})",
        d.exams.joinToString("\n") { ex -> "• ${if (ex.kind == "daily") "يومي" else "تراكمي"} ${ex.day}: ${ex.subjects.joinToString("، ")}" }, 2)
    section("الوقت والفترة",
        "من ${d.startDate.ifBlank { "؟" }} إلى ${d.endDate.ifBlank { "؟" }}" +
            (d.daysCount()?.let { " ($it يوم)" } ?: "") +
            "\nالحد اليومي: ${d.dailyStudyMin / 60} ساعات" +
            (if (d.schoolDays.isNotEmpty()) "\nدوام مدرسي: ${d.schoolDays.joinToString("، ")}" else "") +
            "\nالنوع: ${if (d.oldOnly) "تراكمات فقط" else "تراكمات + جديد"}", 3)
    if (!d.oldOnly) d.subjects.filter { d.newDaysOf(it).isEmpty() }.takeIf { it.isNotEmpty() }?.let {
        Text("⚠ لا أيام جديد لـ: ${it.joinToString("، ")} — اخترها في «توزيع الأسبوع» وإلا فالجديد 0 لها.",
            color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    }
    d.undistributed().takeIf { it.isNotEmpty() }?.let {
        Text("⚠ غير موزعة على أيام الأسبوع: ${it.joinToString("، ")}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    }
}

// ===== شاشة البرومبت =====

@Composable fun WizardPromptScreen(vm: MainVm, draft: WizardDraft, onBack: () -> Unit, onGoImport: () -> Unit, onGoLocal: () -> Unit) {
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf("") }
    val prompt = remember(draft) { WizardPromptBuilder.build(draft) }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) try {
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(prompt.toByteArray()) }
            msg = "تم حفظ البرومبت كملف نصي ✅"
        } catch (e: Exception) { msg = "تعذر الحفظ: ${e.message ?: "خطأ"}" }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(onClick = onGoLocal, modifier = Modifier.fillMaxWidth()) { Text("⚙ توليد الجدول داخل التطبيق (بدون ذكاء اصطناعي)") }
        Text("البرومبت الجاهز", style = MaterialTheme.typography.headlineSmall)
        Text("١) انسخه أو شاركه أو احفظه ٢) أرسله لأداة الذكاء الاصطناعي ٣) نزّل ملف JSON ٤) عد واضغط «استيراد الجدول».")
        Card(Modifier.weight(1f)) {
            Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
                Text(prompt, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (msg.isNotBlank()) Text(msg, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        Button(onClick = {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("rafiq-wizard-prompt", prompt))
            msg = "تم نسخ البرومبت ✅"
        }, modifier = Modifier.fillMaxWidth()) { Text("📋 نسخ البرومبت") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, prompt) }
                ctx.startActivity(Intent.createChooser(send, "مشاركة البرومبت مع…"))
            }, modifier = Modifier.weight(1f)) { Text("📤 مشاركة") }
            OutlinedButton(onClick = {
                val pkgs = listOf("com.openai.chat", "com.google.android.apps.gemini.canary",
                    "com.google.android.apps.bard", "com.microsoft.copilot", "com.meta.ai", "com.deepseek.chat")
                val pm = ctx.packageManager
                val target = pkgs.firstOrNull { pm.getLaunchIntentForPackage(it) != null }
                if (target != null) try { ctx.startActivity(pm.getLaunchIntentForPackage(target)) }
                    catch (e: ActivityNotFoundException) { msg = "تعذر فتح التطبيق — استخدم «مشاركة»." }
                else msg = "لم يُعثر على تطبيق ذكاء اصطناعي مثبت — استخدم «مشاركة» لإرسال البرومبت لأي تطبيق أو موقع."
            }, modifier = Modifier.weight(1f)) { Text("🤖 فتح أداة AI") }
        }
        OutlinedButton(onClick = { saveLauncher.launch("rafiq-schedule-prompt.txt") }, modifier = Modifier.fillMaxWidth()) { Text("💾 حفظ البرومبت كملف نصي") }
        Button(onClick = onGoImport, modifier = Modifier.fillMaxWidth()) { Text("⬇ استيراد ملف الجدول الجديد") }
        TextButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("‹ الرجوع للمسودة") }
    }
}

// ===== الاستيراد والفحص والمعاينة والاعتماد =====

@Composable fun WizardImportScreen(vm: MainVm, draft: WizardDraft, onBack: () -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val bundle by vm.bundle.collectAsState(initial = ScheduleBundle())
    var parts by remember { mutableStateOf(listOf<String>()) }
    var parsed by remember { mutableStateOf<ScheduleParseResult?>(null) }
    var stats by remember { mutableStateOf<PlanStats?>(null) }
    var violations by remember { mutableStateOf(listOf<String>()) }
    var fileText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var adopted by remember { mutableStateOf(false) }
    var prevScheduleId by remember { mutableStateOf<String?>(null) }
    var showAdoptConfirm by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var dupOf by remember { mutableStateOf<ScheduleEntity?>(null) }

    val openDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            try {
                val text = (ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: "").trim()
                if (text.isEmpty()) { message = "الملف فارغ."; busy = false; return@launch }
                if ("\"rafiq_part\"" in text && "\"rafiq_schedule\"" !in text) {
                    parts = parts + text
                    message = "أُضيف جزء ${parts.size}. أضف بقية الأجزاء ثم اضغط «تحقق وتجميع»."
                    parsed = null; stats = null; violations = emptyList()
                } else {
                    fileText = text
                    val r = ScheduleParser.parse(text)
                    parsed = r
                    stats = r.file?.let { WizardVerify.stats(it, draft) }
                    violations = r.file?.let { WizardVerify.compliance(it, draft) } ?: emptyList()
                    parts = emptyList()
                    message = if (!r.ok) "يوجد أخطاء بنيوية — راجعها أدناه."
                    else if (violations.isNotEmpty()) "الملف سليم بنيويًا لكن يخالف خطتك (راجع المخالفات)."
                    else "الملف صالح ومطابق لخطتك ✅"
                }
            } catch (e: Exception) { message = "تعذر قراءة الملف: ${e.message ?: "خطأ"}" }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("استيراد الجدول الجديد", style = MaterialTheme.typography.headlineSmall)
        Text("اختر ملف JSON من مدير الملفات. لن يُمسّ جدولك الحالي قبل أن تعتمد أنت بعد المعاينة.")
        Button(onClick = { openDoc.launch(arrayOf("application/json", "text/plain", "*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "جارٍ الفحص…" else "اختيار ملف الجدول") }
        if (parts.isNotEmpty()) {
            Text("الأجزاء المستلمة: ${parts.size}")
            Button(onClick = {
                val asm = PartAssembler.assemble(parts)
                if (asm.text != null) {
                    fileText = asm.text
                    val r = ScheduleParser.parse(asm.text)
                    parsed = r; stats = r.file?.let { WizardVerify.stats(it, draft) }
                    violations = r.file?.let { WizardVerify.compliance(it, draft) } ?: emptyList()
                    message = if (!r.ok) "اكتمل التجميع لكن توجد أخطاء بنيوية."
                    else if (violations.isNotEmpty()) "اكتمل التجميع — الملف يخالف خطتك (راجع المخالفات)."
                    else "اكتمل التجميع والملف مطابق لخطتك ✅"
                } else message = asm.errors.joinToString("\n")
            }, modifier = Modifier.fillMaxWidth()) { Text("تحقق وتجميع الأجزاء") }
        }
        if (message.isNotBlank()) Text(message, style = MaterialTheme.typography.bodySmall)

        parsed?.let { r ->
            if (!r.ok) Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("أخطاء بنيوية يجب إصلاحها في الملف:", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.titleSmall)
                Text(r.errorText(), style = MaterialTheme.typography.bodySmall)
            } }
            violations.takeIf { it.isNotEmpty() }?.let { vs -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("مخالفات لخطتك (${vs.size}):", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.titleSmall)
                vs.take(12).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                if (vs.size > 12) Text("… و${vs.size - 12} أخرى", style = MaterialTheme.typography.bodySmall)
            } } }
            r.file?.let { f -> stats?.let { st ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("معاينة الجدول", style = MaterialTheme.typography.titleMedium)
                    Text("الأيام: ${st.dayCount} · المهام: ${st.taskCount} · مجموع الدراسة: ${st.totalMin / 60}س ${st.totalMin % 60}د")
                    Text("تراكمات موزعة: ${st.oldLectures} · جديدة: ${st.newLectures}" +
                        (if (st.expectedNew.isNotEmpty()) " · المتوقع جديدًا: " +
                            st.expectedNew.entries.joinToString("، ") { "${it.key}: ${it.value}" } else ""))
                    if (st.missingNew.isNotEmpty()) Text("⚠ نقص محاضرات جديدة: " +
                        st.missingNew.entries.joinToString("، ") { "${it.key}: ${it.value}" },
                        color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    if (bundle.tasks.isNotEmpty()) Text("مقارنة بالحالي: ${bundle.tasks.size} مهمة حاليًا ← ${st.taskCount} في الجديد.")
                    if (st.perSubject.isNotEmpty()) { Text("التوزيع على المواد:", style = MaterialTheme.typography.titleSmall)
                        st.perSubject.forEach { (s, n) -> Text("• $s: $n مهام") } }
                    if (st.highLoadDays.isNotEmpty()) { Text("أيام تتجاوز حدك اليومي (${draft.dailyStudyMin / 60}س):", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.titleSmall)
                        st.highLoadDays.take(5).forEach { (dd, m) -> Text("⚠ $dd: ${m / 60}س ${m % 60}د") } }
                    if (st.warnings.isNotEmpty()) { Text("تحذيرات:", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.titleSmall)
                        st.warnings.take(6).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) } }
                } }
            } }
        }

        if (adopted) {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("✅ تم اعتماد الجدول الجديد", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
                parsed?.file?.let { Text("النطاق: ${it.startDate ?: "؟"} → ${it.endDate ?: "؟"} · ${it.taskCount()} مهمة") }
                Text("الجدول السابق محفوظ داخل التطبيق (قسم الجداول) ولم تُمس إنجازاته.")
                prevScheduleId?.let { pid ->
                    OutlinedButton(onClick = {
                        scope.launch { vm.activateSchedule(pid) }
                        message = "تمت استعادة الجدول السابق."
                        adopted = false
                    }, modifier = Modifier.fillMaxWidth()) { Text("↩ استعادة الجدول السابق") }
                }
                OutlinedButton(onClick = { scope.launch { clearWizardDraft(ctx) }; onCancel() }, modifier = Modifier.fillMaxWidth()) { Text("إنهاء") }
            } }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    parts = emptyList(); parsed = null; stats = null; violations = emptyList(); message = ""
                    openDoc.launch(arrayOf("application/json", "text/plain", "*/*"))
                }, modifier = Modifier.weight(1f)) { Text("ملف آخر") }
                OutlinedButton(onClick = { parts = emptyList(); parsed = null; stats = null; violations = emptyList(); message = "" },
                    modifier = Modifier.weight(1f)) { Text("مسح") }
                TextButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("إلغاء") }
            }
            val adoptable = parsed?.ok == true
            Button(onClick = { showAdoptConfirm = true }, enabled = adoptable, modifier = Modifier.fillMaxWidth()) {
                Text(if (adoptable && violations.isNotEmpty()) "اعتماد رغم المخالفات ⚠" else "اعتماد الجدول الجديد ✓")
            }
        }
    }

    dupOf?.let { d -> AlertDialog(onDismissRequest = { dupOf = null },
        title = { Text("هذا الجدول مستورد سابقًا") },
        text = { Text("محتوى الملف مطابق تمامًا للجدول «${d.name}». يمكنك إلغاء الاستيراد، أو المتابعة كنسخة مستقلة (إنجازاتها منفصلة).") },
        confirmButton = { TextButton(onClick = {
            dupOf = null
            scope.launch {
                busy = true
                prevScheduleId = bundle.schedule?.scheduleId
                val r = vm.importSchedule(fileText, null, true, WeekPlanSnapshot.fromDraft(draft))
                if (r.ok) { adopted = true; message = "" }
                else message = "فشل الاعتماد — لم يُحفظ شيء:\n" + r.errorText()
                busy = false
            }
        }) { Text("متابعة كنسخة مستقلة") } },
        dismissButton = { TextButton(onClick = { dupOf = null; message = "أُلغي الاستيراد: الجدول مكرر." }) { Text("إلغاء الاستيراد") } }) }

    if (showAdoptConfirm) {
        val f = parsed?.file
        AlertDialog(onDismissRequest = { showAdoptConfirm = false },
            title = { Text("تأكيد اعتماد الجدول الجديد") },
            text = { Text("سيصبح «${f?.meta?.name ?: "الجدول الجديد"}» هو الجدول الفعّال ابتداءً من اليوم، وتُعاد جدولة التنبيهات عليه، ويبقى جدولك الحالي محفوظًا للاستعادة." +
                (if (violations.isNotEmpty()) "\n\nتحذير: يوجد ${violations.size} مخالفة لخطتك (مواد في أيام غير مسموحة أو أيام راحة). اعتمادك يعني قبولها." else "")) },
            confirmButton = { TextButton(onClick = {
                showAdoptConfirm = false
                scope.launch {
                    busy = true
                    val d = vm.duplicateOf(fileText)
                    if (d != null) { dupOf = d; busy = false; return@launch }
                    prevScheduleId = bundle.schedule?.scheduleId
                    val r = vm.importSchedule(fileText, null, false, WeekPlanSnapshot.fromDraft(draft))
                    if (r.ok) { adopted = true; message = "" }
                    else message = "فشل الاعتماد — لم يُحفظ شيء:\n" + r.errorText()
                    busy = false
                }
            }) { Text("نعم، اعتمد الجدول") } },
            dismissButton = { TextButton(onClick = { showAdoptConfirm = false }) { Text("تراجع") } })
    }
}


// ===== التوليد المحلي: معاينة ثم اعتماد =====

@Composable fun WizardLocalGenScreen(
    vm: MainVm, draft: WizardDraft, onEdit: () -> Unit, onBack: () -> Unit, onCancel: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val bundle by vm.bundle.collectAsState(initial = ScheduleBundle())
    val plan = remember(draft) { ScheduleGenerator.generate(draft) }
    var adopted by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var prevScheduleId by remember { mutableStateOf<String?>(null) }
    var showConfirm by remember { mutableStateOf(false) }
    var dupOf by remember { mutableStateOf<ScheduleEntity?>(null) }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val text = plan.json
        if (uri != null && text != null) try {
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
            message = "تم حفظ ملف الجدول ✅"
        } catch (e: Exception) { message = "تعذر الحفظ: ${e.message ?: "خطأ"}" }
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("توليد الجدول داخل التطبيق", style = MaterialTheme.typography.headlineSmall)

        if (plan.missingInputs.isNotEmpty()) {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("معلومات ناقصة — لن نخترعها:", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.titleSmall)
                plan.missingInputs.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            } }
            Button(onClick = onEdit, modifier = Modifier.fillMaxWidth()) { Text("‹ الرجوع لإكمال البيانات") }
        }
        if (plan.errors.isNotEmpty()) {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("تعذر إنتاج ملف صالح:", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.titleSmall)
                plan.errors.take(10).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            } }
        }
        plan.summary?.let { sm ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("معاينة قبل الاعتماد", style = MaterialTheme.typography.titleMedium)
                Text("الفترة: ${draft.startDate} → ${sm.effectiveEnd.ifBlank { draft.endDate }} (${sm.dayCount} يومًا، منها ${sm.studyDayCount} يوم دراسة)")
                if (sm.extraDays > 0) Text("↔ تمدّد الجدول ${sm.extraDays} يومًا (≈ ${sm.extraWeeks} أسبوعًا) بعد ${draft.endDate} لإكمال التراكم.",
                    color = MaterialTheme.colorScheme.primary)
                if (sm.extensionBlocked) Text("⚠ التمديد لا يُنهي التراكم ضمن قيودك — راجع التنبيهات أدناه.", color = MaterialTheme.colorScheme.error)
                Text("محاضرات جديدة: ${sm.newCount} (${sm.newMin} د) · قديمة: ${sm.oldCount} (${sm.oldMin} د)" +
                    if (sm.examCount > 0) " · اختبارات: ${sm.examCount} (${sm.examMin} د)" else "")
                Text("الوقت المتاح: ${sm.totalAvailableMin} د · غير مستخدم: ${sm.unusedMinAtEnd} د")
                if (sm.dailyMin.isNotEmpty()) {
                    val avg = sm.dailyMin.values.sum() / sm.dailyMin.size
                    val top = sm.dailyMin.entries.maxByOrNull { it.value }
                    Text("المعدل اليومي: $avg د" + (top?.let { " · أثقل يوم ${it.key}: ${it.value} د" } ?: ""))
                }
                if (sm.leftoverOld > 0) Text("⚠ المتبقي في نهاية الفترة: ${sm.leftoverOld} محاضرة قديمة لم تتسع", color = MaterialTheme.colorScheme.error)
                else Text("✅ كل التراكم يُنجز ضمن الفترة")
                Text("حسب المادة:", style = MaterialTheme.typography.titleSmall)
                sm.perSubject.forEach { ps ->
                    Text("• ${ps.subject}: قديم ${ps.oldPlaced}" + (if (ps.oldLeftover > 0) " (يتبقى ${ps.oldLeftover} من رقم ${ps.firstLeftoverNo})" else "") +
                        " · جديد ${ps.newPlaced}", style = MaterialTheme.typography.bodySmall)
                }
            } }
        }
        plan.warnings.takeIf { it.isNotEmpty() }?.let { ws ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("تنبيهات:", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.titleSmall)
                ws.take(8).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                if (ws.size > 8) Text("… و${ws.size - 8} أخرى", style = MaterialTheme.typography.bodySmall)
            } }
        }
        if (message.isNotBlank()) Text(message, style = MaterialTheme.typography.bodySmall)

        if (adopted) {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("✅ تم اعتماد الجدول", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
                Text("الجدول السابق محفوظ في قسم الجداول ولم تُمس إنجازاته.")
                prevScheduleId?.let { pid ->
                    OutlinedButton(onClick = {
                        scope.launch { vm.activateSchedule(pid) }
                        message = "تمت استعادة الجدول السابق."; adopted = false
                    }, modifier = Modifier.fillMaxWidth()) { Text("↩ استعادة الجدول السابق") }
                }
                OutlinedButton(onClick = { scope.launch { clearWizardDraft(ctx) }; onCancel() }, modifier = Modifier.fillMaxWidth()) { Text("إنهاء") }
            } }
        } else {
            Button(onClick = { showConfirm = true }, enabled = plan.ok && !busy, modifier = Modifier.fillMaxWidth()) { Text("اعتماد الجدول ✓") }
            OutlinedButton(onClick = { saveLauncher.launch("rafiq-schedule.json") }, enabled = plan.ok, modifier = Modifier.fillMaxWidth()) { Text("💾 حفظ كملف JSON") }
            TextButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("‹ رجوع") }
        }
    }

    if (showConfirm) AlertDialog(onDismissRequest = { showConfirm = false },
        title = { Text("تأكيد اعتماد الجدول") },
        text = { Text("سيصبح هذا الجدول فعّالًا وتُعاد جدولة التنبيهات، ويبقى جدولك الحالي محفوظًا للاستعادة.") },
        confirmButton = { TextButton(onClick = {
            showConfirm = false
            val text = plan.json ?: return@TextButton
            scope.launch {
                busy = true
                val d = vm.duplicateOf(text)
                if (d != null) { dupOf = d; busy = false; return@launch }
                prevScheduleId = bundle.schedule?.scheduleId
                val r = vm.importSchedule(text, null, false, WeekPlanSnapshot.fromDraft(draft))
                if (r.ok) { adopted = true; message = "" }
                else message = "فشل الاعتماد — لم يُحفظ شيء:\n" + r.errorText()
                busy = false
            }
        }) { Text("نعم، اعتمد") } },
        dismissButton = { TextButton(onClick = { showConfirm = false }) { Text("تراجع") } })

    dupOf?.let { d -> AlertDialog(onDismissRequest = { dupOf = null },
        title = { Text("جدول مطابق موجود") },
        text = { Text("الجدول المولَّد مطابق تمامًا لـ «${d.name}». ألغِ الاعتماد أو تابع كنسخة مستقلة.") },
        confirmButton = { TextButton(onClick = {
            dupOf = null
            val text = plan.json ?: return@TextButton
            scope.launch {
                busy = true
                prevScheduleId = bundle.schedule?.scheduleId
                val r = vm.importSchedule(text, null, true, WeekPlanSnapshot.fromDraft(draft))
                if (r.ok) { adopted = true; message = "" }
                else message = "فشل الاعتماد — لم يُحفظ شيء:\n" + r.errorText()
                busy = false
            }
        }) { Text("متابعة كنسخة مستقلة") } },
        dismissButton = { TextButton(onClick = { dupOf = null; message = "أُلغي الاعتماد: الجدول مكرر." }) { Text("إلغاء") } }) }
}

package com.rafiq6.study

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

val Context.timerDs by preferencesDataStore("rafiq6_timer")

data class TimerState(val taskId: String = "", val startEpoch: Long = 0,
                      val accumMs: Long = 0, val running: Boolean = false) {
    fun elapsedMs(): Long = if (running) accumMs + (System.currentTimeMillis() - startEpoch) else accumMs
}

object StudyTimer {
    private val TID = stringPreferencesKey("tid"); private val ST = longPreferencesKey("st")
    private val AC = longPreferencesKey("ac"); private val RN = booleanPreferencesKey("rn")
    suspend fun state(c: Context): TimerState { val p = c.timerDs.data.first()
        return TimerState(p[TID] ?: "", p[ST] ?: 0, p[AC] ?: 0, p[RN] ?: false) }
    suspend fun start(c: Context, taskId: String) { c.timerDs.edit {
        it[TID] = taskId; it[ST] = System.currentTimeMillis(); it[RN] = true } }
    suspend fun pause(c: Context) { val s = state(c); if (s.running) c.timerDs.edit {
        it[AC] = s.elapsedMs(); it[RN] = false } }
    suspend fun resume(c: Context) { c.timerDs.edit { it[ST] = System.currentTimeMillis(); it[RN] = true } }
    suspend fun finish(c: Context): Pair<String, Int>? { val s = state(c); if (s.taskId.isEmpty()) return null
        val mins = (s.elapsedMs() / 60_000).toInt(); c.timerDs.edit { it.clear() }; return s.taskId to mins }
    suspend fun cancel(c: Context) { c.timerDs.edit { it.clear() } }
}

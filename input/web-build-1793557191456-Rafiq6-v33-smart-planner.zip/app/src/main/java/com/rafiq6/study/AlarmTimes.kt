package com.rafiq6.study

import java.time.LocalDate
import java.time.ZoneId

/** حساب مواعيد تنبيهات المهمة — منطق نقي قابل للاختبار على JVM. النوع: 0 قبل، 1 عند البدء، 2 متأخرة بعد النهاية بـ15 د. */
object AlarmTimes {
    fun compute(date: String, startMin: Int, endMin: Int?, remindBeforeMin: Int, nowMs: Long, zone: ZoneId): List<Pair<Int, Long>> {
        val base = LocalDate.parse(date).atStartOfDay(zone).plusMinutes(startMin.toLong()).toInstant().toEpochMilli()
        val out = mutableListOf<Pair<Int, Long>>()
        val pre = base - remindBeforeMin * 60_000L
        if (pre > nowMs) out += 0 to pre
        if (base > nowMs) out += 1 to base
        if (endMin != null) {
            val late = base + (endMin - startMin) * 60_000L + 15 * 60_000L
            if (late > nowMs) out += 2 to late
        }
        return out
    }
}

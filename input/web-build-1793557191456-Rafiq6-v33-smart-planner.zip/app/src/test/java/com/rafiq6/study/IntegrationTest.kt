package com.rafiq6.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/**
 * اختبارات التكامل بين الميزات الخمس — تغطي بنود «التكامل بين الميزات» في الطلب الأصلي:
 * (1) مهمة غير منجزة تدخل تلقائيًا ضمن اقتراح إعادة الجدولة أيًا كان نوعها (بما فيها المراجعات)،
 * (5) مهام المراجعة تظهر وتُحسب في الإحصائيات ككل باقي المهام دون ميزة منفصلة لها،
 * (6) مجموع وقت المهام في أي يوم يبقى ضمن الحد الذي أدخله المستخدم عبر كل الميزات معًا،
 * (7) لا ميزة تحذف الجدول الأصلي أو تفقد بيانات مهام مكتملة.
 */
class IntegrationTest {
    private fun settings(dailyGoalMin: Int = 180) = Settings(
        wakeMin = 6 * 60, schoolStart = 8 * 60, schoolEnd = 14 * 60,
        sleepMin = 22 * 60, breakMin = 15, dailyGoalMin = dailyGoalMin, maxPostponeDays = 7
    )

    private val today = LocalDate.of(2026, 10, 27)

    private fun task(
        id: String, date: String, start: Int?, duration: Int = 60,
        subject: String = "رياضيات", type: String = TaskTypes.NEW, done: Boolean = false, flexible: Boolean = true
    ) = UiTask(
        TaskEntity(
            id = "s::$id", scheduleId = "s", sourceId = id, date = date,
            dayName = ScheduleParser.weekday(LocalDate.parse(date)), subject = subject, type = type,
            title = "م $id", lectureNo = null, durationMin = duration, startMin = start,
            endMin = start?.plus(duration), flexible = flexible
        ),
        ProgressEntity("s::$id", done = done)
    )

    @Test fun `a missed review task is detected as overdue exactly like a missed lecture`() {
        val tasks = listOf(
            task("lec", today.minusDays(2).toString(), 16 * 60, type = TaskTypes.NEW),
            task("rev", today.minusDays(2).toString(), 17 * 60, type = TaskTypes.REVIEW)
        )
        val overdue = AdaptiveScheduleEngine.findOverdue(tasks, today)
        assertEquals(setOf("lec", "rev"), overdue.map { it.sourceId }.toSet())
    }

    @Test fun `rescheduling an overdue task never changes the count of completed tasks`() {
        val tasks = listOf(
            task("doneNew", today.minusDays(1).toString(), 9 * 60, done = true),
            task("lateNew", today.minusDays(1).toString(), 16 * 60)
        )
        val before = tasks.count { it.done }
        val plan = AdaptiveScheduleEngine.plan(tasks, today, settings(), null)
        // بعد تطبيق النقل (محاكاة ما يفعله Vm.applyAdaptiveSchedule): المنجزة تبقى كما هي، والمتأخرة تُستبدل بموضع جديد فقط.
        val resolvedIds = plan.moves.map { it.task.id }.toSet()
        val after = tasks.filter { it.id !in resolvedIds } + plan.moves.map { UiTask(it.resolvedTask(), ProgressEntity(it.task.id, done = false)) }
        assertEquals(before, after.count { it.done })
        assertEquals(tasks.size, after.size)   // لا حذف ولا تكرار لأي مهمة
    }

    @Test fun `total minutes on any single day never exceeds the user's daily limit across adaptive, emergency and review placements`() {
        val limit = 180
        // يوم اليوم فيه مهمة واحدة تستهلك نصف الحد (90 دقيقة)، وعدة مهام متأخرة ومراجعة يجب ألا تُحشر فيه.
        val existingToday = task("existing", today.toString(), 9 * 60, duration = 90)
        val lateTasks = (1..3).map { i -> task("late$i", today.minusDays(2).toString(), null, duration = 60) }
        val reviewItem = ReviewItemEntity(id = "r1", scheduleId = "s", subject = "رياضيات", title = "موضوع", studyDate = today.minusDays(5).toString())

        val allBefore = listOf(existingToday) + lateTasks
        val adaptivePlan = AdaptiveScheduleEngine.plan(allBefore, today, settings(dailyGoalMin = limit), null, horizonDays = 10)
        val afterAdaptive = allBefore.filter { it.id !in adaptivePlan.moves.map { m -> m.task.id } } +
            adaptivePlan.moves.map { UiTask(it.resolvedTask()) }

        val reviewTask = SpacedRepetitionEngine.scheduleNext(reviewItem, ReviewRating.MEDIUM, today, afterAdaptive, settings(dailyGoalMin = limit))
        val finalTasks = if (reviewTask != null) afterAdaptive + UiTask(reviewTask) else afterAdaptive

        val byDate = finalTasks.groupBy { it.date }
        byDate.forEach { (_, dayTasks) -> assertTrue(dayTasks.sumOf { it.durationMin } <= limit) }
    }

    @Test fun `review tasks are counted in overall analytics without a separate double count`() {
        val tasks = listOf(
            task("n1", today.toString(), 9 * 60, type = TaskTypes.NEW, done = true),
            task("r1", today.toString(), 10 * 60, type = TaskTypes.REVIEW, done = true)
        )
        val a = StudyAnalytics.analyze(tasks, null, StatsPeriod.ALL, today)
        assertEquals(2, a.totalCompleted)   // المحاضرة والمراجعة كلاهما يُحسب مرة واحدة فقط
        // لا تدخل مهمة المراجعة ضمن عدّاد "محاضرات جديدة" للمادة حتى لا تُضخّم نسبة إنجاز المحاضرات
        val subj = a.perSubject.single()
        assertEquals(1, subj.newTotal)
    }

    @Test fun `no engine ever deletes a task row, only relocates or leaves it unplaced`() {
        val tasks = (1..4).map { i -> task("t$i", today.minusDays(1).toString(), null, duration = 60) }
        val plan = AdaptiveScheduleEngine.plan(tasks, today, settings(dailyGoalMin = 60), null, horizonDays = 2)
        // كل مهمة إما نُقلت أو ظهرت في unplaced — لا تختفي بصمت.
        val accounted = plan.moves.map { it.task.id }.toSet() + plan.unplaced.map { it.task.id }.toSet()
        assertEquals(tasks.map { it.id }.toSet(), accounted)
    }
}

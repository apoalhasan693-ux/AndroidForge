package com.rafiq6.study

import org.junit.Assert.*
import org.junit.Test

class ScheduleFingerprintTest {
    private fun task(id: String, dur: Int = 45, title: String = "تراكم 1") =
        """{"id":"$id","subject":"الفيزياء","type":"oldLecture","title":"$title","lectureNo":1,"durationMin":$dur}"""

    private fun file(name: String, d1: String, d2: String, order: Boolean = true, dur2: Int = 45): String {
        val a = """{"date":"2026-01-03","tasks":[${task(d1)}]}"""
        val b = """{"date":"2026-01-04","tasks":[${task(d2, dur2, "تراكم 2")}]}"""
        return """{"format":"rafiq_schedule","formatVersion":1,"metadata":{"scheduleName":"$name"},
            "startDate":"2026-01-03","endDate":"2026-01-04","days":[${if (order) "$a,$b" else "$b,$a"}]}"""
    }

    private fun hash(text: String): String {
        val r = ScheduleParser.parse(text); assertTrue(r.errorText(), r.ok)
        return ScheduleFingerprint.ofFile(r.file!!)
    }

    @Test fun sameContentGivesSameHashRegardlessOfNameOrDayOrder() {
        assertEquals(hash(file("اسم أول", "a", "b")), hash(file("اسم ثانٍ تمامًا", "a", "b", order = false)))
    }

    @Test fun sameNameAndDatesButDifferentTasksGiveDifferentHash() {
        assertNotEquals(hash(file("نفس الاسم", "a", "b")), hash(file("نفس الاسم", "a", "b", dur2 = 60)))
        assertNotEquals(hash(file("نفس الاسم", "a", "b")), hash(file("نفس الاسم", "a", "c")))
    }

    @Test fun hashIsStable64HexSha256() {
        val h = hash(file("x", "a", "b"))
        assertTrue(Regex("^[0-9a-f]{64}$").matches(h))
        assertEquals(h, hash(file("x", "a", "b")))
    }

    @Test fun legacyEntitiesFingerprintMatchesFileUntilUserEditsContent() {
        val f = ScheduleParser.parse(file("x", "a", "b")).file!!
        val ents = ScheduleParser.toEntities("s1", f)
        assertEquals(ScheduleFingerprint.ofFile(f), ScheduleFingerprint.ofEntities(ents))
        // نقل المهمة (طلعة/تعديل وقت) يحافظ على original* فتبقى البصمة نفسها
        val moved = ents.map { if (it.sourceId == "a") it.copy(date = "2026-01-09", dayName = "الجمعة", startMin = 600, endMin = 645) else it }
        assertEquals(ScheduleFingerprint.ofFile(f), ScheduleFingerprint.ofEntities(moved))
        // تغيير المحتوى نفسه يغيّرها
        assertNotEquals(ScheduleFingerprint.ofFile(f), ScheduleFingerprint.ofEntities(ents.map { it.copy(title = "عنوان آخر") }))
    }

    @Test fun generatedScheduleHasStableFingerprint() {
        val d = WizardDraft(subjects = listOf("الفيزياء"), backlogs = mapOf("الفيزياء" to 3), firstOldNo = mapOf("الفيزياء" to 1),
            startDate = "2026-01-03", endDate = "2026-01-10", dailyStudyMin = 240)
        val a = ScheduleGenerator.generate(d); val b = ScheduleGenerator.generate(d)
        assertTrue(a.ok && b.ok)
        assertEquals(ScheduleFingerprint.ofFile(a.file!!), ScheduleFingerprint.ofFile(b.file!!))
    }
}

package com.rafiq6.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class QuestionBankLogicTest {
    private fun question(id: String = "q1", doc: String = "doc", page: Int = 3) = QuestionEntity(
        id = id, documentId = doc, documentName = "فيزياء.pdf", pageNumber = page,
        subject = "فيزياء", topic = "الحرارة", question = "عرّف الحرارة؟",
        correctAnswer = "إجابة موثقة"
    )

    @Test fun `question keeps document and page identity`() {
        val q = question()
        assertEquals("doc", q.documentId)
        assertEquals("فيزياء.pdf", q.documentName)
        assertEquals(3, q.pageNumber)
        val encoded = BankJsonCodec.question(q)
        val decoded = BankJsonCodec.question(encoded)
        assertEquals(q, decoded)
    }

    @Test fun `question survives entity update without losing source`() {
        val q = question()
        val updated = QuestionStateUpdater.applyResult(q, false, LocalDate.of(2026, 10, 18), 123L)
        assertEquals("doc", updated.documentId)
        assertEquals(3, updated.pageNumber)
        assertEquals(1, updated.errorCount)
        assertEquals("خاطئ", updated.lastResult)
        assertEquals("2026-10-19", updated.nextReviewAt)
    }

    @Test fun `pdf validator accepts real header and rejects garbage`() {
        assertTrue(PdfValidator.isPdf("%PDF-1.7\n".toByteArray()))
        assertFalse(PdfValidator.isPdf("not a pdf".toByteArray()))
        assertFalse(PdfValidator.isPdf(byteArrayOf(0, 1, 2)))
    }

    @Test fun `quiz selector refuses to invent questions`() {
        val selection = QuizSelector.select(emptyList(), "فيزياء", "الحرارة", 10)
        assertFalse(selection.hasQuestions)
        assertTrue(selection.message.contains("لا توجد أسئلة"))
    }

    @Test fun `quiz selector prefers errors and due reviews`() {
        val normal = question("n")
        val error = question("e").copy(errorCount = 2)
        val due = question("d").copy(nextReviewAt = "2020-01-01")
        val selected = QuizSelector.select(listOf(normal, error, due), "فيزياء", "الحرارة", 2)
        assertEquals(listOf("e", "d"), selected.questions.map { it.id })
    }
}

class QuizRecordingAndReviewTest {
    private fun attempt(total: Int = 3, answered: Int = 0, correct: Int = 0) =
        QuizAttemptEntity("a1", "رياضيات", "الدوال", total, answered, correct)

    @Test fun `quiz result is recorded and finishes at total`() {
        val first = QuizResultRecorder.update(attempt(), true, 100L)
        assertFalse(first.finished)
        assertEquals(1, first.attempt.answered)
        assertEquals(1, first.attempt.correct)
        assertEquals(QuizStatus.ACTIVE, first.attempt.status)
        val second = QuizResultRecorder.update(first.attempt, false, 200L)
        val third = QuizResultRecorder.update(second.attempt, true, 300L)
        assertTrue(third.finished)
        assertEquals(3, third.attempt.answered)
        assertEquals(2, third.attempt.correct)
        assertEquals(QuizStatus.DONE, third.attempt.status)
        assertEquals(300L, third.attempt.finishedAt)
    }

    @Test fun `wrong answer moves review closer and increases error count`() {
        val q = QuestionEntity("q", "d", "ملف", 1, "كيمياء", "الأملاح", "س", reviewStage = 3)
        val wrong = QuestionStateUpdater.applyResult(q, false, LocalDate.of(2026, 10, 18), 1L)
        assertEquals(1, wrong.errorCount)
        assertEquals(2, wrong.reviewStage)
        assertEquals("2026-10-19", wrong.nextReviewAt)
    }

    @Test fun `correct answers gradually postpone review then stop infinite repetition`() {
        var q = QuestionEntity("q", "d", "ملف", 1, "كيمياء", "الأملاح", "س")
        val first = QuestionStateUpdater.applyResult(q, true, LocalDate.of(2026, 10, 18), 1L)
        assertEquals(1, first.reviewStage)
        assertEquals("2026-10-19", first.nextReviewAt)
        q = first
        for (i in 2 until ReviewScheduler.MAX_STAGE) {
            q = QuestionStateUpdater.applyResult(q, true, LocalDate.parse(q.nextReviewAt), i.toLong())
            assertTrue(q.nextReviewAt == null || LocalDate.parse(q.nextReviewAt!!) > LocalDate.of(2026, 10, 18))
        }
        val completed = QuestionStateUpdater.applyResult(q, true, LocalDate.of(2026, 12, 1), 99L)
        assertEquals(ReviewScheduler.MAX_STAGE, completed.reviewStage)
        assertNull(completed.nextReviewAt)
    }

    @Test fun `review date remains editable by user`() {
        val q = QuestionEntity("q", "d", "ملف", 1, "أحياء", "الخلية", "س", nextReviewAt = "2026-10-18")
        val edited = q.copy(nextReviewAt = "2026-11-01")
        assertEquals("2026-11-01", edited.nextReviewAt)
    }
}

class MasteryLogicTest {
    private fun task(id: String, done: Boolean) = UiTask(
        TaskEntity("s::$id", "s", id, "2026-10-18", "الأحد", "رياضيات", TaskTypes.NEW, "مهمة $id",
            null, 30, 10 * 60, 10 * 60 + 30),
        ProgressEntity("s::$id", done)
    )

    @Test fun `mastery separates schedule quiz and retention bases`() {
        val answers = listOf(
            AttemptAnswerEntity("a", "at", "q1", "x", true, previousStage = 0, nextStage = 1, nextReviewAt = "2026-10-19"),
            AttemptAnswerEntity("b", "at", "q2", "y", false, previousStage = 1, nextStage = 0, nextReviewAt = "2026-10-19"),
            AttemptAnswerEntity("c", "at", "q3", "z", true, previousStage = 2, nextStage = 3, nextReviewAt = "2026-10-29")
        )
        val m = MasteryCalculator.calculate(listOf(task("1", true), task("2", false), task("3", false)), answers)
        assertEquals(33, m.schedulePct); assertEquals(3, m.scheduleBase)
        assertEquals(66, m.quizPct); assertEquals(3, m.quizBase)
        assertEquals(50, m.retentionPct); assertEquals(2, m.retentionBase)
        assertTrue(m.enoughSchedule && m.enoughQuiz && m.enoughRetention)
    }

    @Test fun `insufficient data is explicit`() {
        val m = MasteryCalculator.calculate(emptyList(), emptyList())
        assertEquals(0, m.schedulePct); assertEquals(0, m.scheduleBase)
        assertEquals(0, m.quizPct); assertEquals(0, m.quizBase)
        assertEquals(0, m.retentionPct); assertEquals(0, m.retentionBase)
        assertFalse(m.enoughSchedule); assertFalse(m.enoughQuiz); assertFalse(m.enoughRetention)
    }
}

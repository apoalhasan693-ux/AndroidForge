package com.rafiq6.study

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** اختبارات منطق اختيار الألوان الديناميكية (Material You) — الجزء القابل للاختبار على JVM
 * بمعزل عن dynamicDarkColorScheme/dynamicLightColorScheme التي تحتاج Context أندرويد حيّ. */
class ThemeLogicTest {
    @Test fun `dynamic color is used only on Android 12 and above when the setting is on`() {
        assertTrue(ThemeLogic.shouldUseDynamicColor(dynamicColorSetting = true, sdkInt = 31))
        assertTrue(ThemeLogic.shouldUseDynamicColor(dynamicColorSetting = true, sdkInt = 34))
    }

    @Test fun `dynamic color falls back to the brand palette on older Android versions`() {
        assertFalse(ThemeLogic.shouldUseDynamicColor(dynamicColorSetting = true, sdkInt = 30))
        assertFalse(ThemeLogic.shouldUseDynamicColor(dynamicColorSetting = true, sdkInt = 26))
    }

    @Test fun `dynamic color is off when the user disables it, even on a supporting device`() {
        assertFalse(ThemeLogic.shouldUseDynamicColor(dynamicColorSetting = false, sdkInt = 34))
    }

    @Test fun `default settings enable dynamic color so modern devices get it without any action`() {
        assertTrue(Settings().dynamicColor)
    }
}

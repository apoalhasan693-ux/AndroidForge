package com.rafiq6.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/** اختبارات الميزة 4 (وضع الطوارئ) — تغطي البند 9 من قائمة الاختبارات: وضع الطوارئ والتراجع عن التعديل
 * (التراجع نفسه مغطى عبر نفس آلية RescheduleSnapshotEntity المختبرة أصلًا؛ هنا نختبر بناء الخطة). */
class EmergencyRescheduleTest {
    private fun settings(dailyGoalMin: Int = 900) = Settings(
        wakeMin = 6 * 60, schoolStart = 8 * 60, schoolEnd = 14 * 60,
        sleepMin = 22 * 60, breakMin = 15, dailyGoalMin = dailyGoalMin, maxPostponeDays = 7
    )

    private fun task(
        id: String, date: String, start: Int?, duration: Int = 60,
        subject: String = "رياضيات", type: String = TaskTypes.NEW,
        flexible: Boolean = true, fixed: Boolean = false, done: Boolean = false
    ): UiTask {
        val row = TaskEntity(
            id = "s::$id", scheduleId = "s", sourceId = id, date = date,
            dayName = ScheduleParser.weekday(LocalDate.parse(date)), subject = subject,
            type = type, title = "مهمة $id", lectureNo = null, durationMin = duration,
            startMin = start, endMin = start?.plus(duration), flexible = flexible, fixed = fixed
        )
        return UiTask(row, ProgressEntity(row.id, done = done))
    }

    private val today = LocalDate.of(2026, 10, 27)

    @Test fun `full day outing moves all its unfinished tasks away`() {
        val tasks = listOf(
            task("a", today.toString(), 16 * 60),
            task("b", today.toString(), 18 * 60)
        )
        val plan = EmergencyReplanEngine.plan(tasks, today, isFullDay = true, partialFromMin = null,
            scope = EmergencyScope.OUTING_ONLY, today = today, settings = settings())
        assertEquals(2, plan.disruptedCount)
        assertEquals(2, plan.movedCount)
        plan.moves.forEach { assertTrue(LocalDate.parse(it.toDate).isAfter(today)) }
    }

    @Test fun `partial day only disturbs tasks after the stated cutoff hour`() {
        val tasks = listOf(
            task("morning", today.toString(), 9 * 60),   // قبل الساعة 16 — لا يتأثر
            task("evening", today.toString(), 17 * 60)    // بعد الساعة 16 — يتأثر
        )
        val plan = EmergencyReplanEngine.plan(tasks, today, isFullDay = false, partialFromMin = 16 * 60,
            scope = EmergencyScope.OUTING_ONLY, today = today, settings = settings())
        assertEquals(1, plan.disruptedCount)
        assertEquals("evening", plan.moves.single().task.sourceId)
    }

    @Test fun `scope OUTING_ONLY never touches overdue tasks from other days`() {
        val tasks = listOf(
            task("today1", today.toString(), 16 * 60),
            task("oldLate", today.minusDays(2).toString(), 16 * 60)
        )
        val plan = EmergencyReplanEngine.plan(tasks, today, isFullDay = true, partialFromMin = null,
            scope = EmergencyScope.OUTING_ONLY, today = today, settings = settings())
        assertEquals(1, plan.moves.size)
        assertEquals("today1", plan.moves.single().task.sourceId)
    }

    @Test fun `scope OUTING_PLUS_ALL_OVERDUE also redistributes other overdue tasks`() {
        val tasks = listOf(
            task("today1", today.toString(), 16 * 60),
            task("oldLate", today.minusDays(2).toString(), 16 * 60)
        )
        val plan = EmergencyReplanEngine.plan(tasks, today, isFullDay = true, partialFromMin = null,
            scope = EmergencyScope.OUTING_PLUS_ALL_OVERDUE, today = today, settings = settings())
        assertEquals(2, plan.moves.size)
        assertTrue(plan.moves.any { it.task.sourceId == "oldLate" })
    }

    @Test fun `completed tasks on the outing day are never touched`() {
        val tasks = listOf(task("done1", today.toString(), 16 * 60, done = true))
        val plan = EmergencyReplanEngine.plan(tasks, today, isFullDay = true, partialFromMin = null,
            scope = EmergencyScope.OUTING_ONLY, today = today, settings = settings())
        assertEquals(0, plan.disruptedCount)
        assertEquals(0, plan.movedCount)
    }

    @Test fun `fixed lectures on the outing day are never moved without permission`() {
        val tasks = listOf(task("fixed1", today.toString(), 16 * 60, fixed = true))
        val plan = EmergencyReplanEngine.plan(tasks, today, isFullDay = true, partialFromMin = null,
            scope = EmergencyScope.OUTING_ONLY, today = today, settings = settings())
        assertEquals(0, plan.disruptedCount)
    }

    @Test fun `temporary daily limit only applies to upcoming days, never permanently`() {
        val tasks = listOf(task("a", today.toString(), 16 * 60, duration = 400))
        val tightTemp = 60 // ساعة واحدة فقط لليوم القادم مؤقتًا — غير كافٍ لمدة 400 دقيقة
        val plan = EmergencyReplanEngine.plan(tasks, today, isFullDay = true, partialFromMin = null,
            scope = EmergencyScope.OUTING_ONLY, today = today, settings = settings(dailyGoalMin = 900),
            tempDailyLimitForUpcomingDays = tightTemp, horizonDays = 3)
        // الحد المؤقت الضيق يجعل المهمة غير قابلة للجدولة ضمن 3 أيام فقط رغم أن الحد الدائم (900) كان يسمح بها بسهولة.
        assertTrue(plan.unplaced.isNotEmpty())
    }

    @Test fun `plan never duplicates a task id across moves`() {
        val tasks = (1..5).map { i -> task("t$i", today.toString(), null, duration = 60) }
        val plan = EmergencyReplanEngine.plan(tasks, today, isFullDay = true, partialFromMin = null,
            scope = EmergencyScope.OUTING_ONLY, today = today, settings = settings())
        assertEquals(plan.moves.map { it.task.id }.distinct().size, plan.moves.size)
    }

    @Test fun `unexecutable plan is clearly reported instead of silently dropping tasks`() {
        val tasks = listOf(task("stuck", today.toString(), null, duration = 90))
        val tight = Settings(wakeMin = 6 * 60, schoolStart = 6 * 60 + 30, schoolEnd = 6 * 60 + 60,
            sleepMin = 7 * 60, breakMin = 15, dailyGoalMin = 30, maxPostponeDays = 2)
        val plan = EmergencyReplanEngine.plan(tasks, today, isFullDay = true, partialFromMin = null,
            scope = EmergencyScope.OUTING_ONLY, today = today, settings = tight, horizonDays = 5)
        assertFalse(plan.isFullyExecutable)
        assertEquals("stuck", plan.unplaced.single().task.sourceId)
    }
}

package com.rafiq6.study

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class SmartScheduleTest {
    private val cap = StudyCaps(dailyCapMin = 360, maxScanDays = 42)
    private val engine = SmartEngine(cap)
    private val today = LocalDate.of(2026, 11, 1)

    private fun t(
        id: String, date: LocalDate, type: String = TaskTypes.NEW, dur: Int = 60,
        subject: String = "فيزياء", fixed: Boolean = false, st: Int? = null, en: Int? = null,
        orig: String? = null
    ) = TaskEntity(
        id = id, scheduleId = "s", sourceId = id, date = date.toString(),
        dayName = ScheduleParser.weekday(date), subject = subject, type = type, title = "مهمة $id",
        lectureNo = 1, durationMin = dur, startMin = st, endMin = en, fixed = fixed, originalDate = orig
    )

    private fun plan(tasks: List<TaskEntity>, done: Set<String> = emptySet(), wp: WeekPlanSnapshot? = null,
                     ov: Map<String, DayOverrideEntity> = emptyMap()) =
        engine.planMissedRelocation("s", tasks, done, today, 23 * 60, ov, wp)

    @Test fun relocateMissedPrefersNextDay() {
        val missed = t("a", today, st = 600, en = 660)
        val m = engine.planMove(missed, today, listOf(missed), emptySet(), emptyMap(), null,
            mutableMapOf(), mutableSetOf(), reason = "x")
        assertNotNull(m); assertEquals(today.plusDays(1).toString(), m!!.toDate)
    }

    @Test fun oldMissedNeverMovedIntoThePast() {
        val old = t("old", today.minusDays(10))
        val p = plan(listOf(old))
        assertEquals(1, p.moves.size)
        assertTrue(LocalDate.parse(p.moves[0].toDate).isAfter(today))
    }

    @Test fun multipleMissedNoDuplicatesNoOverflow() {
        val tasks = (1..5).map { t("m$it", today.minusDays(it.toLong()), dur = 120) }
        val p = plan(tasks)
        assertEquals(5, p.moves.size)
        assertEquals(5, p.moves.map { it.taskId }.toSet().size)
        p.addedMinByDate.forEach { (_, v) -> assertTrue(v <= cap.dailyCapMin) }
    }

    @Test fun evacuateMovesOnlyBacklog() {
        val d = today.plusDays(2)
        val all = listOf(
            t("b1", d, TaskTypes.OLD), t("b2", d, TaskTypes.COMPENSATION, fixed = true),
            t("n1", d, TaskTypes.NEW), t("e1", d, TaskTypes.DAILY_EXAM, fixed = true),
            t("c1", d, TaskTypes.COMMITMENT, fixed = true))
        val p = engine.planEvacuateDay("s", d, all, emptySet(), emptyMap(), null)
        assertEquals(listOf("b1"), p.moves.map { it.taskId })
        assertTrue(p.moves.none { it.toDate == d.toString() })
    }

    @Test fun neverExceedsDailyCap() {
        val missed = t("x", today.minusDays(1), dur = 300)
        val fillers = (1..10).map { t("f$it", today.plusDays(it.toLong()), dur = 300) }
        val p = plan(listOf(missed) + fillers)
        p.moves.forEach { m ->
            val existing = fillers.filter { it.date == m.toDate }.sumOf { it.durationMin }
            assertTrue(existing + m.durationMin <= cap.dailyCapMin)
        }
    }

    @Test fun neverOnRestDay() {
        val restName = ScheduleParser.weekday(today.plusDays(1))
        val p = plan(listOf(t("r", today.minusDays(1))), wp = WeekPlanSnapshot(restDays = setOf(restName)))
        assertTrue(p.moves.none { ScheduleParser.weekday(LocalDate.parse(it.toDate)) == restName })
    }

    @Test fun neverOnDisallowedSubjectDay() {
        val allowed = ScheduleParser.weekday(today.plusDays(3))
        val wp = WeekPlanSnapshot(oldDays = mapOf("فيزياء" to setOf(allowed)))
        val p = plan(listOf(t("d", today.minusDays(1), TaskTypes.OLD)), wp = wp)
        assertEquals(1, p.moves.size)
        assertEquals(allowed, p.moves[0].toDayName)
    }

    @Test fun backlogSkipsBacklogFreeDay() {
        val ov = mapOf(today.plusDays(1).toString() to DayOverrideEntity("s", today.plusDays(1).toString(), DayKind.BACKLOG_FREE_DAY.name))
        val p = plan(listOf(t("bk", today.minusDays(1), TaskTypes.OLD)), ov = ov)
        assertTrue(p.moves.none { it.toDate == today.plusDays(1).toString() })
    }

    @Test fun busyDayHasReducedCapacity() {
        val ov = mapOf(today.plusDays(1).toString() to DayOverrideEntity("s", today.plusDays(1).toString(), DayKind.BUSY_DAY.name))
        val p = plan(listOf(t("big", today.minusDays(1), dur = 120)), ov = ov)
        assertTrue(p.moves.none { it.toDate == today.plusDays(1).toString() }) // 120 > 25% من 360
    }

    @Test fun detectsTimedOverlap() {
        val a = t("o1", today, st = 600, en = 660); val b = t("o2", today, st = 630, en = 700)
        assertTrue(engine.validateResult(listOf(a, b), emptySet(), emptyMap(), null).any { it.contains("تداخل") })
    }

    @Test fun extendsToFollowingWeeksWhenFull() {
        val full = (1..20).map { t("fill$it", today.plusDays(it.toLong()), dur = 360) }
        val p = plan(listOf(t("far", today.minusDays(1), dur = 60)) + full)
        assertEquals(1, p.moves.size)
        assertTrue(LocalDate.parse(p.moves[0].toDate).isAfter(today.plusDays(20)))
    }

    @Test fun noDuplicateTasksInPlan() {
        val a = t("dup", today.minusDays(1)); val b = a.copy(id = "dup2", sourceId = "dup2")
        val p = plan(listOf(a, b))
        assertEquals(p.moves.size, p.moves.map { it.taskId }.toSet().size)
    }

    @Test fun completedTasksNeverMissedNorMoved() {
        val d = t("done1", today.minusDays(2))
        assertFalse(engine.isMissedNow(d, true, today, 1380))
        assertTrue(plan(listOf(d), done = setOf("done1")).moves.isEmpty())
    }

    @Test fun examsAndFixedNeverMoved() {
        val e = t("ex", today.minusDays(1), TaskTypes.DAILY_EXAM, fixed = true)
        val c = t("cm", today.minusDays(1), TaskTypes.COMMITMENT)
        assertTrue(plan(listOf(e, c)).moves.isEmpty())
    }

    @Test fun deterministicAndStableAfterApply() {
        val tasks = (0..3).map { t("s$it", today.minusDays(it.toLong() + 1), dur = 90) }
        val p1 = plan(tasks); val p2 = plan(tasks)
        assertEquals(p1.moves, p2.moves)
        val moved = tasks.map { tk -> p1.moves.firstOrNull { it.taskId == tk.id }?.let { tk.copy(date = it.toDate) } ?: tk }
        assertTrue(engine.detectMissed(moved, emptySet(), today, 1380).isEmpty())
        assertTrue(plan(moved).moves.isEmpty())
    }

    @Test fun deferNextDayAndPickDate() {
        val x = t("x", today.plusDays(1))
        val next = engine.planDefer("s", listOf("x"), DeferMode.NEXT_DAY, null, listOf(x), emptySet(), emptyMap(), null)
        assertEquals(today.plusDays(2).toString(), next.moves.single().toDate)
        val pick = today.plusDays(5)
        val p = engine.planDefer("s", listOf("x"), DeferMode.PICK_DATE, pick, listOf(x), emptySet(), emptyMap(), null)
        assertEquals(pick.toString(), p.moves.single().toDate)
        val bad = engine.planDefer("s", listOf("x"), DeferMode.PICK_DATE, today, listOf(x), emptySet(), emptyMap(), null)
        assertTrue(bad.moves.isEmpty() && bad.violations.isNotEmpty())
    }

    @Test fun statusDerivation() {
        val past = t("p1", today.minusDays(1))
        assertEquals(TaskStatus.MISSED, SmartStatus.of(past, false, today, 0))
        assertEquals(TaskStatus.COMPLETED, SmartStatus.of(past, true, today, 0))
        val moved = t("p2", today.plusDays(2), orig = today.toString())
        assertEquals(TaskStatus.DEFERRED, SmartStatus.of(moved, false, today, 0))
        val timed = t("p3", today, st = 1200, en = 1260)
        assertEquals(TaskStatus.PENDING, SmartStatus.of(timed, false, today, 720))
        assertEquals(TaskStatus.MISSED, SmartStatus.of(timed, false, today, 1320))
    }

    @Test fun loadLevels() {
        assertEquals(LoadLevel.LIGHT, engine.levelOf(100, 360))
        assertEquals(LoadLevel.MEDIUM, engine.levelOf(200, 360))
        assertEquals(LoadLevel.HIGH, engine.levelOf(320, 360))
        assertEquals(LoadLevel.OVER, engine.levelOf(400, 360))
    }
}

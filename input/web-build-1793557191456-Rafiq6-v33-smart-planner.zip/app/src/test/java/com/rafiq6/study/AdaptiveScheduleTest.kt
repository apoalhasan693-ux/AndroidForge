package com.rafiq6.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/**
 * اختبارات الميزة 1 (الجدول الذكي المتكيّف). تغطي البنود الإلزامية 1-5 و15 من قائمة الاختبارات:
 * إعادة جدولة بلا تكرار، الحفاظ على المهام المنجزة، عدم تجاوز الحد اليومي، عدم تغيير المحاضرات
 * الثابتة دون إذن، كشف المهام غير القابلة للجدولة.
 */
class AdaptiveScheduleTest {
    private fun settings(dailyGoalMin: Int = 900) = Settings(
        wakeMin = 6 * 60, schoolStart = 8 * 60, schoolEnd = 14 * 60,
        sleepMin = 22 * 60, breakMin = 15, dailyGoalMin = dailyGoalMin, maxPostponeDays = 7
    )

    private fun task(
        id: String, date: String, start: Int?, duration: Int = 60,
        subject: String = "رياضيات", type: String = TaskTypes.NEW,
        flexible: Boolean = false, fixed: Boolean = false, done: Boolean = false
    ): UiTask {
        val row = TaskEntity(
            id = "s::$id", scheduleId = "s", sourceId = id, date = date,
            dayName = ScheduleParser.weekday(LocalDate.parse(date)), subject = subject,
            type = type, title = "مهمة $id", lectureNo = null, durationMin = duration,
            startMin = start, endMin = start?.plus(duration), flexible = flexible, fixed = fixed
        )
        return UiTask(row, ProgressEntity(row.id, done = done))
    }

    private val today = LocalDate.of(2026, 10, 27)

    @Test fun `future tasks are never treated as overdue`() {
        val tasks = listOf(
            task("past", "2026-10-25", 16 * 60, flexible = true),
            task("today", today.toString(), 16 * 60, flexible = true),
            task("future", "2026-10-30", 16 * 60, flexible = true)
        )
        val overdue = AdaptiveScheduleEngine.findOverdue(tasks, today)
        assertEquals(listOf("past"), overdue.map { it.sourceId })
    }

    @Test fun `overdue task is rescheduled exactly once without duplicate ids`() {
        val tasks = listOf(task("late1", "2026-10-25", 16 * 60, flexible = true))
        val plan = AdaptiveScheduleEngine.plan(tasks, today, settings(), null)
        assertEquals(1, plan.movedCount)
        val move = plan.moves.single()
        assertTrue(LocalDate.parse(move.toDate) >= today)
        // لا تكرار: معرّف المهمة الناتجة يطابق معرّف الأصل، ولا يظهر مرتين في الخطة
        assertEquals(1, plan.moves.count { it.task.id == move.task.id })
        assertEquals("s::late1", move.resolvedTask().id)
    }

    @Test fun `completed overdue tasks are left untouched`() {
        val tasks = listOf(task("done1", "2026-10-20", 16 * 60, flexible = true, done = true))
        val overdue = AdaptiveScheduleEngine.findOverdue(tasks, today)
        assertTrue(overdue.isEmpty())
        val plan = AdaptiveScheduleEngine.plan(tasks, today, settings(), null)
        assertEquals(0, plan.movedCount)
        assertEquals(0, plan.overdueTotal)
    }

    @Test fun `daily goal is never exceeded after redistribution`() {
        // ثلاث مهام متأخرة من 5 ساعات كل واحدة، والحد اليومي 6 ساعات فقط — يجب ألا يتجمع أكثر من مهمة بنفس اليوم.
        val tasks = (1..3).map { i -> task("t$i", "2026-10-2$i", null, duration = 300, flexible = true) }
        val plan = AdaptiveScheduleEngine.plan(tasks, today, settings(dailyGoalMin = 6 * 60), null, horizonDays = 10)
        assertTrue(plan.dayLoads.all { it.plannedMin <= 6 * 60 })
        assertTrue(plan.passesFinalValidation(settings(dailyGoalMin = 6 * 60)))
    }

    @Test fun `fixed overdue tasks are not moved without explicit permission`() {
        val tasks = listOf(task("fixedLate", "2026-10-20", 16 * 60, fixed = true))
        val plan = AdaptiveScheduleEngine.plan(tasks, today, settings(), null)
        assertEquals(0, plan.movedCount)
        assertEquals(1, plan.lockedCount)
        assertEquals(1, plan.overdueTotal)
    }

    @Test fun `fixed overdue tasks can be moved when explicitly allowed`() {
        val tasks = listOf(task("fixedLate", "2026-10-20", 16 * 60, fixed = true))
        val plan = AdaptiveScheduleEngine.plan(tasks, today, settings(), null, allowLocked = true)
        assertEquals(1, plan.movedCount)
    }

    @Test fun `task that cannot fit anywhere is reported as unplaced, not silently dropped`() {
        val tight = Settings(wakeMin = 6 * 60, schoolStart = 6 * 60 + 30, schoolEnd = 6 * 60 + 60,
            sleepMin = 7 * 60, breakMin = 15, dailyGoalMin = 30, maxPostponeDays = 2)
        val tasks = listOf(task("stuck", "2026-10-20", null, duration = 90, flexible = true))
        val plan = AdaptiveScheduleEngine.plan(tasks, today, tight, null, horizonDays = 5)
        assertTrue(plan.hasDeficit)
        assertEquals("stuck", plan.unplaced.single().task.sourceId)
        assertEquals(0, plan.movedCount)
    }

    @Test fun `redistribution respects the saved week plan's allowed days`() {
        val tasks = listOf(task("move", "2026-10-20", 16 * 60, flexible = true, subject = "رياضيات"))
        val allowedDay = ScheduleParser.weekday(today.plusDays(3))
        val constraints = WeekPlanSnapshot(newDays = mapOf("رياضيات" to setOf(allowedDay)))
        val plan = AdaptiveScheduleEngine.plan(tasks, today, settings(), constraints, horizonDays = 10)
        val moved = plan.moves.single()
        assertEquals(allowedDay, ScheduleParser.weekday(LocalDate.parse(moved.toDate)))
    }

    @Test fun `redistribution never lands on a saved rest day`() {
        val tasks = listOf(task("move", "2026-10-20", 16 * 60, flexible = true))
        val restDay = ScheduleParser.weekday(today)
        val constraints = WeekPlanSnapshot(restDays = setOf(restDay))
        val plan = AdaptiveScheduleEngine.plan(tasks, today, settings(), constraints, horizonDays = 10)
        plan.moves.forEach { m -> assertFalse(ScheduleParser.weekday(LocalDate.parse(m.toDate)) == restDay) }
    }

    @Test fun `balancing spreads overdue tasks across multiple days instead of stacking one day`() {
        val tasks = (1..4).map { i -> task("w$i", "2026-10-2$i", null, duration = 120, flexible = true) }
        val plan = AdaptiveScheduleEngine.plan(tasks, today, settings(dailyGoalMin = 240), null, horizonDays = 10)
        // بحد يومي 4 ساعات ومهام ساعتين، يجب أن تتوزع على يومين مختلفين على الأقل بدل تكديسها كلها بيوم واحد.
        val distinctDays = plan.moves.map { it.toDate }.toSet()
        assertTrue(distinctDays.size >= 2)
    }
}

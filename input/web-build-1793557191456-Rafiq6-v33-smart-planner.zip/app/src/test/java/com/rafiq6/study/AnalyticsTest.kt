package com.rafiq6.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/** اختبارات الميزة 2 (الإحصائيات). تغطي البند 6 و14 من قائمة الاختبارات: صحة حساب إحصائيات
 * كل مادة، وتطابق الإحصائيات مع المهام المسجلة فعليًا دون مضاعفة أو عدّ مزدوج. */
class AnalyticsTest {
    private fun task(
        id: String, date: String, subject: String, type: String,
        duration: Int = 60, done: Boolean = false, actualMin: Int? = null
    ): UiTask {
        val row = TaskEntity(
            id = "s::$id", scheduleId = "s", sourceId = id, date = date,
            dayName = ScheduleParser.weekday(LocalDate.parse(date)), subject = subject,
            type = type, title = "م $id", lectureNo = null, durationMin = duration,
            startMin = null, endMin = null
        )
        return UiTask(row, ProgressEntity(row.id, done = done, actualMin = actualMin))
    }

    private val today = LocalDate.of(2026, 10, 27)

    @Test fun `subject breakdown separates new lectures from cumulative without double counting`() {
        val tasks = listOf(
            task("n1", "2026-10-26", "رياضيات", TaskTypes.NEW, done = true, actualMin = 70),
            task("n2", "2026-10-25", "رياضيات", TaskTypes.NEW, done = false),
            task("o1", "2026-10-24", "رياضيات", TaskTypes.OLD, done = true, actualMin = 40),
            task("o2", "2026-10-23", "رياضيات", TaskTypes.OLD, done = false)
        )
        val a = StudyAnalytics.analyze(tasks, subjectFilter = null, period = StatsPeriod.ALL, today = today)
        val math = a.perSubject.single { it.subject == "رياضيات" }
        assertEquals(2, math.newTotal); assertEquals(1, math.newDone)
        assertEquals(2, math.oldTotal); assertEquals(1, math.oldDone)
        assertEquals(2, math.completedCount)   // n1 + o1 فقط، لا مضاعفة
        assertEquals(110, math.actualMin)      // 70 + 40
    }

    @Test fun `overdue counts exclude done and future tasks`() {
        val tasks = listOf(
            task("late", "2026-10-20", "فيزياء", TaskTypes.NEW, done = false),
            task("lateDone", "2026-10-21", "فيزياء", TaskTypes.NEW, done = true, actualMin = 50),
            task("future", "2026-10-30", "فيزياء", TaskTypes.NEW, done = false)
        )
        val a = StudyAnalytics.analyze(tasks, null, StatsPeriod.ALL, today)
        assertEquals(1, a.overdueCount)
    }

    @Test fun `subject filter scopes every number to that subject only`() {
        val tasks = listOf(
            task("m1", "2026-10-20", "رياضيات", TaskTypes.NEW, done = true, actualMin = 60),
            task("p1", "2026-10-20", "فيزياء", TaskTypes.NEW, done = true, actualMin = 60)
        )
        val a = StudyAnalytics.analyze(tasks, subjectFilter = "رياضيات", period = StatsPeriod.ALL, today = today)
        assertEquals(1, a.totalCompleted)
        assertEquals(1, a.perSubject.size)
        assertEquals("رياضيات", a.perSubject.single().subject)
    }

    @Test fun `opening a lecture without marking it done is never counted as completed`() {
        // لا توجد علاقة بين "فتح المحاضرة" وUiTask.done — المهمة هنا done=false رغم وجود مدة/وقت.
        val tasks = listOf(task("x", "2026-10-20", "أحياء", TaskTypes.NEW, done = false))
        val a = StudyAnalytics.analyze(tasks, null, StatsPeriod.ALL, today)
        assertEquals(0, a.totalCompleted)
        assertEquals(0, a.perSubject.single().completedCount)
    }

    @Test fun `week comparison reports no data instead of fabricating a zero for a schedule with no history`() {
        // كل المهام هذا الأسبوع فقط — لا بيانات قبل ذلك إطلاقًا.
        val tasks = listOf(task("w1", today.toString(), "عربي", TaskTypes.NEW, done = true, actualMin = 30))
        val a = StudyAnalytics.analyze(tasks, null, StatsPeriod.ALL, today)
        assertFalse(a.weekComparison.hasLastWeekData)
    }

    @Test fun `week comparison uses real data when it exists for last week`() {
        val tasks = listOf(
            task("thisW", today.toString(), "عربي", TaskTypes.NEW, done = true, actualMin = 30),
            task("lastW", today.minusDays(10).toString(), "عربي", TaskTypes.NEW, done = true, actualMin = 20)
        )
        val a = StudyAnalytics.analyze(tasks, null, StatsPeriod.ALL, today)
        assertTrue(a.weekComparison.hasLastWeekData)
        assertEquals(1, a.weekComparison.lastWeekDone)
    }

    @Test fun `period filter WEEK only includes the last 7 days`() {
        val tasks = listOf(
            task("in", today.minusDays(3).toString(), "كيمياء", TaskTypes.NEW, done = true, actualMin = 10),
            task("out", today.minusDays(20).toString(), "كيمياء", TaskTypes.NEW, done = true, actualMin = 10)
        )
        val a = StudyAnalytics.analyze(tasks, null, StatsPeriod.WEEK, today)
        assertEquals(1, a.totalCompleted)
    }

    @Test fun `empty scope reports no data rather than a misleading zero percent`() {
        val a = StudyAnalytics.analyze(emptyList(), null, StatsPeriod.ALL, today)
        assertFalse(a.hasAnyData)
    }
}

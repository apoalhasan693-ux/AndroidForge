package com.rafiq6.study

import java.time.LocalDate
import java.time.format.DateTimeFormatter

/** Read-only snapshot of the real local schedule, passed to Gemini as grounding context. */
object RafiqAiContext {
    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm")

    fun build(bundle: ScheduleBundle, today: LocalDate): String {
        val schedule = bundle.schedule
            ?: return "لا يوجد جدول دراسي نشط حالياً في قاعدة البيانات المحلية. لا تفترض وجود جدول أو مهام."
        val tasks = bundle.tasks
        val end = today.plusDays(60)
        val relevant = tasks.filter { task ->
            val date = runCatching { LocalDate.parse(task.date) }.getOrNull() ?: return@filter false
            (!task.done && date.isBefore(today)) || (!date.isBefore(today) && !date.isAfter(end))
        }.sortedWith(compareBy<UiTask>({ it.date }, { it.startMin ?: Int.MAX_VALUE }))
        val doneCount = tasks.count { it.done }
        val pendingCount = tasks.size - doneCount
        val overdue = tasks.filter { task ->
            !task.done && runCatching { LocalDate.parse(task.date).isBefore(today) }.getOrDefault(false)
        }
        val exams = relevant.filter { TaskTypes.isAssessment(it.type) }
        return buildString {
            appendLine("الجدول النشط: ${schedule.name}")
            appendLine("المرحلة: ${schedule.stage ?: "غير محددة"}")
            appendLine("تاريخ اليوم: $today")
            appendLine("الفترة المسجلة: ${schedule.startDate ?: "غير محدد"} إلى ${schedule.endDate ?: "غير محدد"}")
            appendLine("إجمالي المهام المسجلة: ${tasks.size}؛ المنجزة: $doneCount؛ غير المنجزة: $pendingCount")
            appendLine("المهام المتأخرة غير المنجزة: ${overdue.size}")
            appendLine("الامتحانات الظاهرة خلال الفترة: ${exams.size}")
            appendLine()
            appendLine("المهام المتأخرة والمهام من اليوم إلى 60 يوماً قادمة (حد أقصى 140 مهمة):")
            if (relevant.isEmpty()) appendLine("لا توجد مهام ضمن هذه الفترة.")
            relevant.take(140).forEach { task ->
                val status = if (task.done) "منجزة" else "غير منجزة"
                val time = task.startMin?.let { "، ${timeFormatter.format(java.time.LocalTime.of(it / 60, it % 60))}" } ?: ""
                val lecture = task.lectureNo?.let { "، محاضرة رقم $it" } ?: ""
                appendLine("- ${task.date} (${task.dayName})$time | ${task.subject} | ${task.type} | ${task.title}$lecture | ${task.durationMin} دقيقة | $status")
            }
            if (relevant.size > 140) appendLine("ملاحظة: عُرضت أول 140 مهمة فقط من الفترة.")
            appendLine()
            appendLine("تنبيه: هذه لقطة قراءة فقط من الجدول المحلي وقت السؤال؛ لا تنفّذ أي تعديل من نفسك.")
        }.take(18000)
    }
}

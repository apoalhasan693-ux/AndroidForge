package com.rafiq6.study

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlinx.coroutines.CancellationException

private data class ChatMessage(
    val fromUser: Boolean, val text: String,
    val plan: SmartPlan? = null,   // غير null فقط لرسالة المساعد التي تحمل معاينة تحتاج تأكيد/إلغاء
    val resolved: Boolean = false
)

private val WELCOME_MESSAGE = ChatMessage(
    fromUser = false,
    text = "أهلًا! أني رفيق، أگدر أساعدك بالدراسة وتنظيم وقتك والإجابة عن أسئلتك.\n" +
        "وإذا عندك تراكم اليوم، أگدر أجهّز معاينة لإعادة توزيعه حتى توافق عليها قبل أي تغيير.\n" +
        "جرّب مثلًا: «اشرح لي الاتزان الكيميائي» أو «رحّل تراكم اليوم»."
)

/**
 * المساعد الذكي: يرسل الأسئلة العامة إلى Firebase AI Logic، بينما طلب ترحيل التراكم المعروف
 * يمر محليًا عبر SmartEngine ومعاينة موافقة موجودتين أصلًا. لا يسمح للنموذج بكتابة بيانات الجدول.
 */
@Composable fun SmartAssistantScreen(vm: MainVm) {
    val messages = remember { mutableStateListOf(WELCOME_MESSAGE) }
    var input by remember { mutableStateOf("") }
    var awaitingPlan by remember { mutableStateOf(false) }
    var isSending by remember { mutableStateOf(false) }
    val aiService = remember { FirebaseAiService() }
    val pendingPlan by vm.pendingPlan.collectAsState()
    val liveBundle by vm.bundle.collectAsState(initial = ScheduleBundle())
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // عندما تصل الخطة من المحرك (بعد previewEvacuate) أثناء انتظارنا لها، نضيفها كرسالة رد من المساعد.
    LaunchedEffect(pendingPlan) {
        val p = pendingPlan
        if (awaitingPlan && p != null) {
            messages.add(ChatMessage(fromUser = false, text = AssistantMessageBuilder.describe(p), plan = p))
            awaitingPlan = false
            scope.launch { listState.animateScrollToItem((messages.size - 1).coerceAtLeast(0)) }
        }
    }

    fun send() {
        val text = input.trim()
        if (text.isBlank()) return
        input = ""
        messages.add(ChatMessage(fromUser = true, text = text))
        if (AssistantIntentParser.isBacklogRedistributionRequest(text)) {
            awaitingPlan = true
            vm.previewEvacuate(Subjects.now().toLocalDate())
        } else {
            isSending = true
            scope.launch {
                try {
                    val history = messages.takeLast(12).map { message ->
                        (if (message.fromUser) "user" else "assistant") to message.text
                    }
                    val liveContext = RafiqAiContext.build(liveBundle, Subjects.now().toLocalDate())
                    val reply = aiService.generateReply(history, liveContext)
                    messages.add(ChatMessage(fromUser = false, text = reply))
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    messages.add(ChatMessage(
                        fromUser = false,
                        text = "صار خطأ بالاتصال بالمساعد الذكي. تأكد من الإنترنت وإعداد Firebase App Check، وبعدها جرّب مرة ثانية."
                    ))
                } finally {
                    isSending = false
                    listState.animateScrollToItem((messages.size - 1).coerceAtLeast(0))
                }
            }
        }
        scope.launch { listState.animateScrollToItem((messages.size - 1).coerceAtLeast(0)) }
    }

    Column(Modifier.fillMaxSize()) {
        Text("🤖 المساعد الذكي", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(12.dp))
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(messages) { idx, m ->
                ChatBubble(
                    m = m,
                    onConfirm = {
                        vm.applySmartPlan()
                        messages[idx] = m.copy(resolved = true)
                        messages.add(ChatMessage(fromUser = false, text = "تم ✅ رحّلت تراكم اليوم بنجاح. إذا غيّرت رأيك تقدر تتراجع من زر التراجع في مركز التحكم."))
                    },
                    onCancel = {
                        vm.discardPlan()
                        messages[idx] = m.copy(resolved = true)
                        messages.add(ChatMessage(fromUser = false, text = "تمام، ألغيت الترحيل ولم يتغيّر شيء في جدولك."))
                    }
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("اسأل رفيق عن جدولك أو دراستك…") },
                enabled = !isSending
            )
            Button(onClick = { send() }, enabled = input.isNotBlank() && !isSending) {
                if (isSending) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                else Text("إرسال")
            }
        }
    }
}

@Composable private fun ChatBubble(m: ChatMessage, onConfirm: () -> Unit, onCancel: () -> Unit) {
    val bg = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Card(
            modifier = Modifier.fillMaxWidth(0.88f),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = bg)
        ) {
            Column(Modifier.padding(12.dp)) {
                Text(m.text, style = MaterialTheme.typography.bodyMedium)
                if (m.plan != null && !m.resolved && m.plan.moves.isNotEmpty()) {
                    Row(Modifier.padding(top = 10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onConfirm, modifier = Modifier.weight(1f)) { Text("تأكيد الترحيل") }
                        OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("إلغاء") }
                    }
                }
                if (m.resolved) Text("✓ تمت المعالجة", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
        }
    }
}

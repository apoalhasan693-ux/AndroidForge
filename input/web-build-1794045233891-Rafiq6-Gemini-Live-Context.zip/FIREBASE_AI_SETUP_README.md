# Rafiq6 — Firebase AI Logic integration

This update connects the existing Smart Assistant chat to Firebase AI Logic using the Gemini Developer API.

## Included
- Firebase Android configuration for package `com.rafiq6.study`.
- Google Services Gradle plugin and Firebase AI Logic SDK.
- Internet permission.
- App Check initialization: Debug provider for debuggable builds; Play Integrity provider for release builds.
- Chat requests sent to `gemini-3.8-flash` with the recent conversation transcript.
- Existing backlog redistribution remains local: `AssistantIntentParser` routes the request to the existing `MainVm.previewEvacuate` preview flow. The user must explicitly confirm before `applySmartPlan` changes the timetable.

## Important limits
- The model chat currently does not read Room data or the student's timetable. It is a general study/planning conversation only.
- The model cannot write to Room or apply timetable changes. Do not remove this separation when extending the assistant.
- This archive has not been compiled or instrumented-tested in this environment because Gradle and an Android SDK are unavailable here. Run a Gradle sync/build in an Android build environment before installing it.

## First debug run
1. Build and install the **debug** variant with package `com.rafiq6.study`.
2. In Logcat, find the `DebugAppCheckProvider` message that prints the debug token.
3. In Firebase Console, open **App Check → Apps → your Android app → Manage debug tokens**, and register that token.
4. Open Rafiq and ask a simple question in the Smart Assistant screen. Confirm that a response arrives.
5. If it fails, check that **Firebase AI Logic** is enabled and App Check is configured/enforced for the project.

## Before production release
- Configure and verify Play Integrity for the release signing certificate.
- Do not ship a debug build or debug App Check token.
- Test the release variant and review Firebase usage/quotas. Gemini Developer API has free-tier limits; it is not unlimited free usage.


## Live schedule context integration
- The assistant now reads a fresh, read-only snapshot from the active Room-backed `MainVm.bundle` before each Gemini request.
- The snapshot includes schedule name/range, task completion counts, overdue tasks, and tasks/exams from today through the next 60 days (up to 140 task rows).
- Gemini can answer schedule questions from this snapshot, but cannot write to Room or change tasks.
- Backlog redistribution still uses the app's deterministic `SmartEngine` preview and requires the student's confirmation.
- App Check is variant-specific: debug builds use the debug provider; release builds use Play Integrity. Never register or ship a debug token in a release build.
- `gemini-3.8-flash` is the configured Gemini Developer API model.

Build status: not compiled in this environment because Android SDK/Gradle wrapper tooling is unavailable. Run Gradle Sync and `assembleDebug` in an Android build environment before installing.
